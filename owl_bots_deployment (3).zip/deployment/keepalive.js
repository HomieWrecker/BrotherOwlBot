// Advanced keep-alive script for Replit to maintain 24/7 uptime
const https = require('https');
const http = require('http');
const express = require('express');
const { log, logError } = require('./src/utils/logger');
const { spawn } = require('child_process');
const path = require('path');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

// Create an Express server to keep the application running
const app = express();
const PORT = 5002; // Use a different port than the main app

// URLs to ping - includes both your Replit URL and multiple fallbacks
const urls = [
  // Only use reliable external sites for pings to avoid DNS errors
  "https://www.google.com",
  "https://discord.com",
  "https://www.cloudflare.com"
];

// More frequent ping interval (every 30 seconds for Replit)
const PING_INTERVAL = 30 * 1000;

// More frequent bot health check interval (every 10 seconds)
const HEALTH_CHECK_INTERVAL = 10 * 1000;

// URLs for UptimeRobot to ping (primary monitor should hit this)
const UPTIME_ROBOT_PING_URL = "https://uptimerobot.com/api/getMonitors";

// Track consecutive failed pings
let failedPings = 0;
const MAX_FAILED_PINGS = 3;

// Bot process info for monitoring
let lastActivity = Date.now();
let isHealthy = true;

// Create a health check endpoint - optimized for UptimeRobot
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Brother Owl Bot - Status</title>
        <meta http-equiv="refresh" content="30">
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
          .status { padding: 20px; border-radius: 5px; margin-bottom: 20px; }
          .online { background-color: #d4edda; color: #155724; }
          .offline { background-color: #f8d7da; color: #721c24; }
          h1 { color: #333; }
          .info { background-color: #e9ecef; padding: 15px; border-radius: 5px; }
        </style>
      </head>
      <body>
        <div class="status ${isHealthy ? 'online' : 'offline'}">
          <h1>Brother Owl Bot Status: ${isHealthy ? 'ONLINE' : 'RECONNECTING'}</h1>
          <p>Uptime: ${Math.floor(process.uptime() / 60)} minutes</p>
          <p>Last Activity: ${Math.floor((Date.now() - lastActivity) / 1000)}s ago</p>
        </div>
        <div class="info">
          <p>This page is used by UptimeRobot to monitor the bot's status. The bot is currently running and being monitored.</p>
          <p>Last checked: ${new Date().toLocaleString()}</p>
        </div>
      </body>
    </html>
  `);
});

// Create a plain text status endpoint for monitoring services
app.get('/status', (req, res) => {
  res.send(isHealthy ? 'OK' : 'RECONNECTING');
});

// Create a heartbeat endpoint
app.post('/heartbeat', (req, res) => {
  lastActivity = Date.now();
  isHealthy = true;
  res.send({ status: 'received' });
});

// Create a wake endpoint (for UptimeRobot)
app.get('/wake', (req, res) => {
  log('Received wake request');
  lastActivity = Date.now();
  isHealthy = true;
  pingUrls(); // Force a self-ping when wake is called
  res.send('Bot awakened');
});

// Start the Express server
const server = app.listen(PORT, () => {
  log(`Web server running on port ${PORT} to keep the bot alive`);
});

// Function to ping URLs to keep alive
function pingUrls() {
  log('Performing self-ping to maintain uptime...');
  
  let successCount = 0;
  
  // Try multiple URLs to ensure at least one is successful
  const pingMultipleUrls = async () => {
    // Only ping 2 random URLs to avoid excessive network traffic
    const urlsToTry = [...urls].sort(() => 0.5 - Math.random()).slice(0, 2);
    
    for (const url of urlsToTry) {
      try {
        await new Promise((resolve, reject) => {
          const requester = url.startsWith('https') ? https : http;
          const req = requester.get(url, (res) => {
            if (res.statusCode >= 200 && res.statusCode < 400) {
              log(`Ping to ${url} successful, status: ${res.statusCode}`);
              successCount++;
              lastActivity = Date.now();
              resolve();
            } else {
              reject(new Error(`Received status code ${res.statusCode}`));
            }
          });
          
          req.on('error', (err) => {
            reject(err);
          });
          
          req.on('timeout', () => {
            req.destroy();
            reject(new Error('Connection timed out'));
          });
          
          req.setTimeout(5000); // 5 second timeout
        });
        
        // If we get here, we had a successful ping, so we can stop trying URLs
        break;
      } catch (err) {
        logError(`Ping to ${url} failed: ${err.message}`);
      }
    }
    
    // If no URLs were successful, increment failed ping counter
    if (successCount === 0) {
      failedPings++;
      
      if (failedPings >= MAX_FAILED_PINGS) {
        logError(`${MAX_FAILED_PINGS} consecutive ping failures detected. Refreshing connection...`);
        failedPings = 0; // Reset counter
        
        // Force reconnection but with a slight delay
        setTimeout(forceReconnect, 2000);
      }
    } else {
      // Reset failed ping counter if we had a successful ping
      failedPings = 0;
    }
  };
  
  // Execute the ping function
  pingMultipleUrls().catch(err => {
    logError('Error in ping system:', err);
  });
}

// Force reconnection function
function forceReconnect() {
  isHealthy = false;
  logError('Forcing reconnection due to connectivity issues...');
  
  // Send reconnect signal to main process
  if (process.send) {
    process.send('reconnect');
  }
  
  // If we're in the main process, try to restart by triggering the index file
  try {
    const botProcess = spawn('node', ['index.js'], {
      detached: true,
      stdio: 'ignore'
    });
    
    botProcess.unref();
    log('Spawned recovery process');
  } catch (error) {
    logError('Failed to spawn recovery process:', error);
  }
  
  // Update status after reconnection attempt
  setTimeout(() => {
    isHealthy = true;
    lastActivity = Date.now();
  }, 30000);
}

// Function to check bot health
function checkBotHealth() {
  const timeSinceActivity = Date.now() - lastActivity;
  
  // Much lower threshold - if no activity for more than 20 seconds, ping to keep alive
  if (timeSinceActivity > 20 * 1000) {
    log(`Activity check: Last activity ${Math.floor(timeSinceActivity / 1000)}s ago - refreshing connection`);
    
    // Update timestamp to prevent multiple reconnects
    lastActivity = Date.now();
    
    // Instead of reconnecting, just ping to keep alive
    pingUrls();
    
    // Every 5 minutes, do a more thorough check
    if (Math.random() < 0.1) { // ~10% chance to perform deeper check
      fetch('https://discord.com/api/v10/gateway')
        .then(res => {
          if (res.ok) {
            log('Discord gateway check: OK');
          } else {
            logError('Discord gateway check failed');
            forceReconnect();
          }
        })
        .catch(err => {
          logError('Discord gateway fetch error:', err);
        });
    }
  }
}

// Start monitoring system with enhanced reliability
function startMonitoring() {
  // Perform initial ping immediately
  pingUrls();
  
  // Use more frequent pings to keep the bot alive
  // Set ping interval to 15 seconds
  setInterval(pingUrls, 15000);
  
  // Set up more aggressive health checks every 5 seconds
  setInterval(checkBotHealth, 5000);
  
  // Add additional rapid pings when we haven't seen activity
  setInterval(() => {
    if (Date.now() - lastActivity > 20000) {
      pingUrls();
    }
  }, 20000);
  
  // Add deep health check every 2 minutes
  setInterval(() => {
    log('Performing deep health check...');
    try {
      // Signal bot process we're still running
      lastActivity = Date.now();
      
      // Force a health check on DNS resolution by pinging multiple domains
      Promise.all([
        fetch('https://discord.com').then(r => r.ok),
        fetch('https://google.com').then(r => r.ok)
      ]).then(() => {
        log('Deep health check passed');
      }).catch(err => {
        logError('Deep health check failed, refreshing connection');
        pingUrls();
      });
    } catch (e) {
      logError('Error in deep health check:', e);
    }
  }, 120000);
  
  log('Enhanced keep-alive and monitoring system activated');
}

// Handle process shutdown gracefully
process.on('SIGTERM', () => {
  log('SIGTERM received. Shutting down gracefully.');
  server.close(() => {
    log('HTTP server closed.');
    process.exit(0);
  });
});

module.exports = {
  activate: () => {
    log('Keep-alive module loaded');
    // Start monitoring after a short delay to let the server initialize
    setTimeout(startMonitoring, 10000);
  },
  
  // Register a heartbeat from the bot
  heartbeat: () => {
    lastActivity = Date.now();
    isHealthy = true;
  }
};