/**
 * Test command for Brother Owl
 * Simple test to check if the bot is responding to commands
 */

const { 
  SlashCommandBuilder, 
  EmbedBuilder,
  Colors
} = require('discord.js');
const { BOT_CONFIG } = require('../config');
const { log, logError } = require('../utils/logger');

// Command creation
const testCommand = {
  data: new SlashCommandBuilder()
    .setName('test')
    .setDescription('Simple test command to check if the bot is responding'),

  /**
   * Execute command
   * @param {CommandInteraction} interaction - Discord interaction
   * @param {Client} client - Discord client
   */
  async execute(interaction, client) {
    try {
      log(`Test command executed by ${interaction.user.tag}`);
      
      // Acknowledge the interaction immediately with a defer
      await interaction.deferReply();
      
      // Simple response embed
      const responseEmbed = new EmbedBuilder()
        .setTitle('✅ Bot Test')
        .setDescription('The bot is working correctly and responding to commands!')
        .setColor(Colors.Green)
        .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
        .setTimestamp();
      
      // Add connection details
      const connectionStatus = client.ws.status === 0 ? 'Connected' : 'Reconnecting';
      responseEmbed.addFields(
        { name: 'Connection Status', value: connectionStatus, inline: true },
        { name: 'API Latency', value: `${Math.round(client.ws.ping)}ms`, inline: true },
        { name: 'Server Count', value: `${client.guilds.cache.size}`, inline: true }
      );

      // Edit the deferred reply
      await interaction.editReply({ 
        embeds: [responseEmbed]
      });
      
      // Update bot status to show it's active
      client.user.setActivity(`Torn Factions | ${BOT_CONFIG.name}`, { type: 3 }); // 3 = Watching
      
    } catch (error) {
      logError('Error executing test command:', error);
      
      try {
        // More robust error handling
        if (interaction.deferred) {
          await interaction.editReply({
            content: '❌ There was an error processing the test command.',
            embeds: []
          }).catch(e => logError('Failed to edit reply:', e));
        } else if (!interaction.replied) {
          await interaction.reply({
            content: '❌ There was an error processing the test command.',
            ephemeral: true
          }).catch(e => logError('Failed to send error reply:', e));
        }
      } catch (secondError) {
        logError('Error in error handler:', secondError);
      }
    }
  }
};

module.exports = testCommand;