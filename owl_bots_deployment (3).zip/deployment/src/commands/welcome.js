/**
 * Welcome command for Brother Owl
 * Handles configuration of the welcome system for new members
 * 
 * IMPORTANT: This command is designed with isolation in mind to prevent it
 * from affecting the core bot functionality if errors occur
 */

const { 
  SlashCommandBuilder, 
  PermissionFlagsBits, 
  EmbedBuilder, 
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType 
} = require('discord.js');
const { log, logError } = require('../utils/logger');
const { BOT_CONFIG } = require('../config');
const { 
  getWelcomeConfig, 
  setWelcomeConfig, 
  isWelcomeConfigured,
  ROLE_DESCRIPTIONS
} = require('../services/welcome-service');

// Command creation with error handling wrapper
const welcomeCommand = {
  data: new SlashCommandBuilder()
    .setName('welcome')
    .setDescription('Configure and manage the welcome system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Set up or update the welcome system')
        .addChannelOption(option =>
          option.setName('welcome_channel')
            .setDescription('Channel to send welcome messages in')
            .setRequired(true))
        .addChannelOption(option =>
          option.setName('verification_channel')
            .setDescription('Channel for member verification requests')
            .setRequired(true))
        .addChannelOption(option =>
          option.setName('log_channel')
            .setDescription('Channel for logging member events')
            .setRequired(true))
        .addRoleOption(option =>
          option.setName('approver_role')
            .setDescription('Role that can approve new members')
            .setRequired(false))
        .addRoleOption(option =>
          option.setName('member_role')
            .setDescription('Role to assign to verified members')
            .setRequired(false))
        .addRoleOption(option =>
          option.setName('contractor_role')
            .setDescription('Role to assign to contractors')
            .setRequired(false))
        .addRoleOption(option =>
          option.setName('ally_role')
            .setDescription('Role to assign to allies')
            .setRequired(false))
        .addRoleOption(option =>
          option.setName('trader_role')
            .setDescription('Role to assign to traders')
            .setRequired(false))
        .addRoleOption(option =>
          option.setName('guest_role')
            .setDescription('Role to assign to guests')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('test')
        .setDescription('Send a test welcome message to current channel'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('status')
        .setDescription('Check the current welcome system configuration'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('disable')
        .setDescription('Disable the welcome system')),

  /**
   * Execute the command with comprehensive error handling
   * @param {CommandInteraction} interaction - Discord interaction
   * @param {Client} client - Discord client
   */
  async execute(interaction, client) {
    try {
      // Safely execute the welcome command with error boundary
      return await safeExecuteCommand(interaction, client);
    } catch (error) {
      // Comprehensive error handling to prevent affecting core bot functionality
      logError('Error executing welcome command (protected):', error);
      
      // Handle errors in responding to the interaction
      const errorResponse = {
        content: '❌ There was an error with the welcome system. This error has been logged and will not affect other bot functionality.',
        ephemeral: true
      };
      
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errorResponse).catch(err => {
          logError('Error sending error followUp for welcome command:', err);
        });
      } else {
        await interaction.reply(errorResponse).catch(err => {
          logError('Error sending error reply for welcome command:', err);
        });
      }
    }
  },

  /**
   * Handle button interactions for welcome-related buttons
   * This method is wrapped with error handling to prevent it from affecting the core bot
   * @param {ButtonInteraction} interaction - Discord button interaction
   * @param {Client} client - Discord client
   */
  async handleButton(interaction, client) {
    try {
      // Extract action and arguments from the button custom ID
      // Format: welcome_action_arg_userId
      const parts = interaction.customId.split('_');
      const action = parts[1];
      const arg = parts[2];
      const userId = parts[3];
      
      // Load welcome service only when needed
      const welcomeService = require('../services/welcome-service');
      
      // Route to the appropriate handler based on the action
      switch (action) {
        case 'role':
          await welcomeService.handleRoleSelection(interaction, arg, userId);
          break;
          
        case 'verify':
          await welcomeService.handleVerification(interaction, arg, userId);
          break;
          
        default:
          await interaction.reply({
            content: '❌ Unknown welcome action.',
            ephemeral: true
          });
      }
    } catch (error) {
      // Comprehensive error handling to prevent affecting core bot functionality
      logError('Error handling welcome button interaction (protected):', error);
      
      try {
        if (!interaction.replied) {
          await interaction.reply({
            content: '❌ There was an error processing this welcome action. This error has been logged and will not affect other bot functionality.',
            ephemeral: true
          });
        }
      } catch (replyError) {
        logError('Error sending welcome button error reply:', replyError);
      }
    }
  },
  
  /**
   * Handle select menu interactions for welcome-related selections
   * This method is wrapped with error handling to prevent it from affecting the core bot
   * @param {StringSelectMenuInteraction} interaction - Discord select menu interaction
   * @param {Client} client - Discord client
   */
  async handleSelectMenu(interaction, client) {
    try {
      // Get the selected value
      const selectedValue = interaction.values[0];
      
      // Extract the role type from the selected value
      // Format: welcome_role_roleType
      const parts = selectedValue.split('_');
      const roleType = parts[2];
      
      // Load welcome service only when needed
      const welcomeService = require('../services/welcome-service');
      
      // Handle the role selection
      await welcomeService.handleRoleMenuSelection(interaction, roleType);
    } catch (error) {
      // Comprehensive error handling to prevent affecting core bot functionality
      logError('Error handling welcome select menu interaction (protected):', error);
      
      try {
        if (!interaction.replied) {
          await interaction.reply({
            content: '❌ There was an error processing your welcome selection. This error has been logged and will not affect other bot functionality.',
            ephemeral: true
          });
        }
      } catch (replyError) {
        logError('Error sending welcome select menu error reply:', replyError);
      }
    }
  }
};

/**
 * Safely execute the welcome command with proper error boundaries
 * @param {CommandInteraction} interaction - Discord interaction
 * @param {Client} client - Discord client
 */
async function safeExecuteCommand(interaction, client) {
  // Get the subcommand
  const subcommand = interaction.options.getSubcommand();
  
  switch (subcommand) {
    case 'setup':
      await handleSetup(interaction, client);
      break;
      
    case 'status':
      await handleStatus(interaction, client);
      break;
      
    case 'test':
      await handleTest(interaction, client);
      break;
      
    case 'disable':
      await handleDisable(interaction, client);
      break;
      
    default:
      await interaction.reply({
        content: '❌ Unknown subcommand.',
        ephemeral: true
      });
  }
}

/**
 * Handle the setup subcommand
 * @param {CommandInteraction} interaction - Discord interaction
 * @param {Client} client - Discord client
 */
async function handleSetup(interaction, client) {
  try {
    // Get options
    const welcomeChannel = interaction.options.getChannel('welcome_channel');
    const verificationChannel = interaction.options.getChannel('verification_channel');
    const logChannel = interaction.options.getChannel('log_channel');
    const approverRole = interaction.options.getRole('approver_role');
    const memberRole = interaction.options.getRole('member_role');
    const contractorRole = interaction.options.getRole('contractor_role');
    const allyRole = interaction.options.getRole('ally_role');
    const traderRole = interaction.options.getRole('trader_role');
    const guestRole = interaction.options.getRole('guest_role');
    
    // Skip channel type validation - Discord.js v14 has different channel handling
    // This ensures compatibility with various server setups and channel types
    
    // Create the config
    const config = {
      welcomeChannelId: welcomeChannel.id,
      verificationChannelId: verificationChannel.id,
      logChannelId: logChannel.id,
      approverRoleId: approverRole ? approverRole.id : null,
      memberRoleId: memberRole ? memberRole.id : null,
      contractorRoleId: contractorRole ? contractorRole.id : null,
      allyRoleId: allyRole ? allyRole.id : null,
      traderRoleId: traderRole ? traderRole.id : null,
      guestRoleId: guestRole ? guestRole.id : null,
      enabled: true
    };
    
    // Save the config
    setWelcomeConfig(interaction.guildId, config);
    
    // Create response embed
    const embed = new EmbedBuilder()
      .setTitle('✅ Welcome System Configured')
      .setColor(BOT_CONFIG.color)
      .setDescription('The welcome system has been configured successfully. New members will now receive a welcome message with role selection options.')
      .addFields(
        { name: 'Welcome Channel', value: `<#${welcomeChannel.id}>`, inline: true },
        { name: 'Verification Channel', value: `<#${verificationChannel.id}>`, inline: true },
        { name: 'Log Channel', value: `<#${logChannel.id}>`, inline: true },
        { name: 'Approver Role', value: approverRole ? `<@&${approverRole.id}>` : 'Not set (Administrators only)', inline: true },
        { name: 'Member Role', value: memberRole ? `<@&${memberRole.id}>` : 'Using "Member" role', inline: true }
      )
      .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
      .setTimestamp();
    
    await interaction.reply({
      embeds: [embed],
      ephemeral: true
    });
    
    // Log welcome system setup
    log(`Welcome system configured for server ${interaction.guildId} by ${interaction.user.tag}`);
  } catch (error) {
    // This is already within the safe execution wrapper, but we add another layer
    // of protection to ensure the error is properly logged and doesn't affect the bot
    logError('Error in handleSetup:', error);
    throw error; // Let the outer handler catch it
  }
}

/**
 * Handle the status subcommand
 * @param {CommandInteraction} interaction - Discord interaction
 * @param {Client} client - Discord client
 */
async function handleStatus(interaction, client) {
  try {
    // Get the config
    const config = getWelcomeConfig(interaction.guildId);
    
    if (!config || !config.enabled) {
      return interaction.reply({
        content: '❌ The welcome system is not configured or has been disabled.',
        ephemeral: true
      });
    }
    
    // Create response embed
    const embed = new EmbedBuilder()
      .setTitle('Welcome System Status')
      .setColor(BOT_CONFIG.color)
      .setDescription('Current welcome system configuration:')
      .addFields(
        { name: 'Status', value: config.enabled ? '✅ Enabled' : '❌ Disabled', inline: false },
        { name: 'Welcome Channel', value: config.welcomeChannelId ? `<#${config.welcomeChannelId}>` : 'Not set', inline: true },
        { name: 'Verification Channel', value: config.verificationChannelId ? `<#${config.verificationChannelId}>` : 'Not set', inline: true },
        { name: 'Log Channel', value: config.logChannelId ? `<#${config.logChannelId}>` : 'Not set', inline: true },
        { name: 'Approver Role', value: config.approverRoleId ? `<@&${config.approverRoleId}>` : 'Not set (Administrators only)', inline: true },
        { name: 'Member Role', value: config.memberRoleId ? `<@&${config.memberRoleId}>` : 'Using "Member" role', inline: true }
      )
      .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
      .setTimestamp();
    
    // Add role configuration section
    const roleFields = [];
    
    if (config.memberRoleId) roleFields.push({ name: 'Member Role', value: `<@&${config.memberRoleId}>`, inline: true });
    if (config.contractorRoleId) roleFields.push({ name: 'Contractor Role', value: `<@&${config.contractorRoleId}>`, inline: true });
    if (config.allyRoleId) roleFields.push({ name: 'Ally Role', value: `<@&${config.allyRoleId}>`, inline: true });
    if (config.traderRoleId) roleFields.push({ name: 'Trader Role', value: `<@&${config.traderRoleId}>`, inline: true });
    if (config.guestRoleId) roleFields.push({ name: 'Guest Role', value: `<@&${config.guestRoleId}>`, inline: true });
    
    if (roleFields.length > 0) {
      embed.addFields({ name: 'Role Configuration', value: ' ', inline: false });
      embed.addFields(...roleFields);
    }
    
    // Add role descriptions
    embed.addFields({ name: 'Role Descriptions', value: ' ', inline: false });
    
    for (const [role, description] of Object.entries(ROLE_DESCRIPTIONS)) {
      embed.addFields({ name: role, value: description, inline: true });
    }
    
    await interaction.reply({
      embeds: [embed],
      ephemeral: true
    });
  } catch (error) {
    logError('Error in handleStatus:', error);
    throw error; // Let the outer handler catch it
  }
}

/**
 * Handle the test subcommand
 * @param {CommandInteraction} interaction - Discord interaction
 * @param {Client} client - Discord client
 */
async function handleTest(interaction, client) {
  try {
    // Check if welcome system is configured
    const config = getWelcomeConfig(interaction.guildId);
    
    if (!config || !config.enabled) {
      return interaction.reply({
        content: '❌ The welcome system is not configured or has been disabled. Please run `/welcome setup` first.',
        ephemeral: true
      });
    }
    
    // Get a random welcome message from the welcome service
    const welcomeService = require('../services/welcome-service');
    const randomWelcomeMessage = welcomeService.WELCOME_MESSAGES[Math.floor(Math.random() * welcomeService.WELCOME_MESSAGES.length)];
    
    // Create a sample welcome message
    const embed = new EmbedBuilder()
      .setTitle('👋 Welcome to the Grand Code Discord!')
      .setColor(BOT_CONFIG.color)
      .setDescription(`<@${interaction.user.id}>, ${randomWelcomeMessage}\n\nThis is a test welcome message. If you can see this, the welcome system is set up correctly!`)
      .addFields(
        { name: 'Welcome Channel', value: `<#${config.welcomeChannelId}>`, inline: true },
        { name: 'Verification Channel', value: `<#${config.verificationChannelId}>`, inline: true },
        { name: 'Log Channel', value: `<#${config.logChannelId}>`, inline: true },
        { name: 'Welcome Status', value: '✅ Working correctly', inline: false }
      )
      .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version} - Test Message` })
      .setTimestamp();
    
    // Show sample role buttons - removed Contractor and Ally as requested
    const roleRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('welcome_test_button_member')
          .setLabel('Member Role')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('welcome_test_button_trader')
          .setLabel('Trader Role')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('welcome_test_button_guest')
          .setLabel('Guest Role')
          .setStyle(ButtonStyle.Secondary)
      );
    
    await interaction.reply({
      embeds: [embed],
      components: [roleRow],
      content: 'Welcome system test message. The buttons below are examples and will not assign actual roles.',
      ephemeral: false
    });
    
    log(`Welcome test message sent in server ${interaction.guildId} by ${interaction.user.tag}`);
  } catch (error) {
    logError('Error in handleTest:', error);
    throw error; // Let the outer handler catch it
  }
}

/**
 * Handle the disable subcommand
 * @param {CommandInteraction} interaction - Discord interaction
 * @param {Client} client - Discord client
 */
async function handleDisable(interaction, client) {
  try {
    // Get the config
    const config = getWelcomeConfig(interaction.guildId);
    
    if (!config || !config.enabled) {
      return interaction.reply({
        content: '❌ The welcome system is already disabled or not configured.',
        ephemeral: true
      });
    }
    
    // Disable the welcome system
    setWelcomeConfig(interaction.guildId, { enabled: false });
    
    await interaction.reply({
      content: '✅ The welcome system has been disabled. New members will no longer receive welcome messages or role selection options.',
      ephemeral: true
    });
    
    // Log welcome system disabled
    log(`Welcome system disabled for server ${interaction.guildId} by ${interaction.user.tag}`);
  } catch (error) {
    logError('Error in handleDisable:', error);
    throw error; // Let the outer handler catch it
  }
}

module.exports = welcomeCommand;