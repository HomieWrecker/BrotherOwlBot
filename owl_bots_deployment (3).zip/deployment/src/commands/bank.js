const { 
  SlashCommandBuilder, 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle,
  StringSelectMenuBuilder,
  PermissionFlagsBits 
} = require('discord.js');
const { log, logError } = require('../utils/logger');
const { formatNumber } = require('../utils/formatting');
const { BOT_CONFIG } = require('../config');
const { getServerConfig, hasRequiredConfig } = require('../services/server-config');
const { 
  getPlayerBalance, 
  createBankRequest, 
  updateBankRequest, 
  markBankRequestNotified, 
  getBankRequest,
  getPendingBankRequests,
  getFulfilledNotNotifiedRequests,
  setBankConfig,
  generateBankURL,
  hasBankConfig
} = require('../services/bank-service');
const statTrackerService = require('../services/stat-tracker-service');
const keyStorageService = require('../services/key-storage-service');
const crypto = require('crypto');

// Bank command for faction banking operations
const bankCommand = {
  data: new SlashCommandBuilder()
    .setName('bank')
    .setDescription('Faction banking operations')
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Configure faction bank settings (Admin only)')
        .addChannelOption(option =>
          option
            .setName('bank_channel')
            .setDescription('Channel for bank operations')
            .setRequired(true))
        .addRoleOption(option =>
          option
            .setName('banker_role')
            .setDescription('Role for faction bankers')
            .setRequired(true))
        .addStringOption(option =>
          option
            .setName('bank_message')
            .setDescription('Custom message for bank embed')))
    .addSubcommand(subcommand =>
      subcommand
        .setName('balance')
        .setDescription('Check your faction bank balance and manage requests'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('fulfill')
        .setDescription('Mark a bank request as fulfilled (Banker only)')
        .addStringOption(option =>
          option
            .setName('request_id')
            .setDescription('ID of the bank request to fulfill')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('cancel')
        .setDescription('Cancel a bank request (Banker or requester only)')
        .addStringOption(option =>
          option
            .setName('request_id')
            .setDescription('ID of the bank request to cancel')
            .setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages),
  
  /**
   * Execute command
   * @param {CommandInteraction} interaction - Discord interaction
   * @param {Client} client - Discord client
   */
  async execute(interaction, client) {
    const subcommand = interaction.options.getSubcommand();
    const { guildId, user } = interaction;
    
    // Handle bank setup (admin only)
    if (subcommand === 'setup') {
      // Check if user has admin permissions
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({
          content: '❌ Only administrators can set up the faction bank.',
          ephemeral: true
        });
      }
      
      // Check if faction is registered first
      try {
        const factions = await statTrackerService.getFactionInfoByServerId(guildId);
        if (!factions || factions.length === 0) {
          return interaction.reply({
            content: '❌ You need to register your faction first with `/factionregister` before setting up the bank.',
            ephemeral: true
          });
        }
      } catch (error) {
        logError('Error checking faction registration:', error);
      }
      
      // Get options
      const bankChannel = interaction.options.getChannel('bank_channel');
      const bankerRole = interaction.options.getRole('banker_role');
      const bankMessage = interaction.options.getString('bank_message') || 
                         'Welcome to the faction bank! Use the dropdown menu below to access banking features.';
      
      // Create bank config
      const bankConfig = {
        channelId: bankChannel.id,
        bankerRoleId: bankerRole.id,
        message: bankMessage,
        setupDate: new Date().toISOString()
      };
      
      // Save bank config
      try {
        log(`Attempting to set bank config for server ${guildId}`);
        const success = setBankConfig(guildId, bankConfig);
        
        if (!success) {
          return interaction.reply({
            content: '❌ Error setting up faction bank. Please try again later.',
            ephemeral: true
          });
        }
        
        // Create bank embed in the specified channel
        try {
          // Build the bank embed
          const embed = new EmbedBuilder()
            .setTitle('💰 Faction Bank')
            .setColor(BOT_CONFIG.color)
            .setDescription(bankMessage)
            .addFields(
              { name: 'How to Withdraw', value: 'Click the button below to request a withdrawal.' },
              { name: 'Banker Role', value: `<@&${bankerRole.id}>` }
            )
            .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
            .setTimestamp();
          
          // Create bank options with different access levels
          const bankOptions = [
            {
              label: 'Request Withdrawal',
              description: 'Request money from the faction bank',
              value: 'bank_withdraw',
              emoji: '💸',
            },
            {
              label: 'View My Balance',
              description: 'Check your bank and point balance',
              value: 'bank_mybalance',
              emoji: '💰',
            }
          ];
          
          // Add banker-only options
          const bankerOptions = [
            {
              label: 'View Member Balance',
              description: 'Check another member\'s balance',
              value: 'bank_memberbalance',
              emoji: '🔍',
            },
            {
              label: 'View All Requests',
              description: 'View all pending withdrawal requests',
              value: 'bank_allrequests',
              emoji: '📋',
            }
          ];
          
          // Add a dropdown menu with bank options
          const selectMenu = new ActionRowBuilder()
            .addComponents(
              new StringSelectMenuBuilder()
                .setCustomId('bank_options')
                .setPlaceholder('Select a bank option')
                .addOptions([...bankOptions, ...bankerOptions])
            );
          
          // Send the embed to the specified channel
          const sentMessage = await bankChannel.send({
            embeds: [embed],
            components: [selectMenu]
          });
          
          // Respond to the interaction
          await interaction.reply({
            content: `✅ Faction bank has been set up in ${bankChannel}!`,
            ephemeral: true
          });
          
          log(`Faction bank set up in guild ${guildId} by ${user.tag} [${user.id}]`);
        } catch (error) {
          logError(`Error setting up faction bank in channel ${bankChannel.id}:`, error);
          return interaction.reply({
            content: `❌ Error setting up faction bank in ${bankChannel}. Make sure the bot has permission to send messages and embeds in that channel.`,
            ephemeral: true
          });
        }
      } catch (error) {
        logError(`Error in bank setup:`, error);
        return interaction.reply({
          content: '❌ An error occurred during bank setup. Please try again later.',
          ephemeral: true
        });
      }
    }
    
    // All other commands require faction registration or bank setup
    else {
      // Check if faction is registered or bank is configured
      const isBankConfigured = await hasBankConfig(guildId);
      if (!isBankConfigured) {
        return interaction.reply({
          content: '❌ Faction not registered. Please ask an administrator to use `/factionregister` first.',
          ephemeral: true
        });
      }
      
      // Get server config for any traditional bank settings
      const serverConfig = getServerConfig(guildId);
      
      // Default channel and role values
      let channelId = null;
      let bankerRoleId = null;
      
      // Use traditional bank config if available
      if (serverConfig && serverConfig.bankConfig) {
        channelId = serverConfig.bankConfig.channelId;
        bankerRoleId = serverConfig.bankConfig.bankerRoleId;
      }
      
      // Handle bank balance command
      if (subcommand === 'balance') {
        // Get API key
        const apiKey = await keyStorageService.getApiKey(user.id, 'torn');
        if (!apiKey) {
          return interaction.reply({
            content: '❌ You need to set up your API key first with `/apikey`.',
            ephemeral: true
          });
        }
        
        // Check if there are any fulfilled requests that need to be notified
        const fulfilledRequests = getFulfilledNotNotifiedRequests(guildId, user.id);
        if (fulfilledRequests.length > 0) {
          // Mark all as notified
          fulfilledRequests.forEach(request => {
            markBankRequestNotified(guildId, request.id);
          });
          
          // Calculate total amount
          const totalAmount = fulfilledRequests.reduce((total, request) => total + request.amount, 0);
          
          // Notify user
          await interaction.reply({
            content: `✅ Your bank withdrawal request${fulfilledRequests.length > 1 ? 's' : ''} for a total of $${formatNumber(totalAmount)} ${fulfilledRequests.length > 1 ? 'have' : 'has'} been fulfilled!`,
            ephemeral: true
          });
          return;
        }
        
        // Defer reply while we fetch data
        await interaction.deferReply({ ephemeral: true });
        
        try {
          // Fetch user information to get their Torn ID
          const userResponse = await fetch(`https://api.torn.com/user/?selections=basic&key=${apiKey}`);
          const userData = await userResponse.json();
          
          if (userData.error) {
            return interaction.editReply(`❌ API Error: ${userData.error.error}`);
          }
          
          const tornId = userData.player_id;
          const tornName = userData.name;
          
          // Fetch player's bank balance
          const balance = await getPlayerBalance(tornId, apiKey);
          
          if (balance === null) {
            return interaction.editReply('❌ Could not fetch your faction bank balance. Make sure your API key has the correct permissions.');
          }
          
          // Check if there are any pending requests from this user
          const pendingRequests = getPendingBankRequests(guildId).filter(req => req.tornId === tornId.toString());
          
          // Create an embed with the player's bank information
          const embed = new EmbedBuilder()
            .setTitle('💰 Your Faction Bank Information')
            .setColor(BOT_CONFIG.color)
            .setDescription(`Here's your faction bank information, ${tornName}.`)
            .addFields(
              { name: 'Your Balance', value: `$${formatNumber(balance)}`, inline: true }
            )
            .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
            .setTimestamp();
          
          // Add bank channel info if available
          if (channelId) {
            embed.addFields({ name: 'Bank Channel', value: `<#${channelId}>`, inline: true });
          }
          
          // Add banker role info if available
          if (bankerRoleId) {
            embed.addFields({ name: 'Banker Role', value: `<@&${bankerRoleId}>`, inline: true });
          }
          
          // Add pending requests if any
          if (pendingRequests.length > 0) {
            const requestsText = pendingRequests.map(req => 
              `Request #${req.id.substring(0, 6)}: $${formatNumber(req.amount)} (${req.status})`
            ).join('\n');
            
            embed.addFields({ name: 'Your Pending Requests', value: requestsText });
          }
          
          // Check if user is a banker or admin
          const hasBankerRole = bankerRoleId ? interaction.member.roles.cache.has(bankerRoleId) : false;
          const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
          const isBanker = hasBankerRole || isAdmin;
          
          // Create bank options with different access levels
          const bankOptions = [
            {
              label: 'Request Withdrawal',
              description: 'Request money from the faction bank',
              value: 'bank_withdraw',
              emoji: '💸',
            },
            {
              label: 'View My Balance',
              description: 'Check your bank and point balance',
              value: 'bank_mybalance',
              emoji: '💰',
            }
          ];
          
          // Add banker-only options if the user is a banker
          if (isBanker) {
            bankOptions.push(
              {
                label: 'View Member Balance',
                description: 'Check another member\'s balance',
                value: 'bank_memberbalance',
                emoji: '🔍',
              },
              {
                label: 'View All Requests',
                description: 'View all pending withdrawal requests',
                value: 'bank_allrequests',
                emoji: '📋',
              }
            );
          }
          
          // Create a dropdown menu with bank options
          const selectMenu = new ActionRowBuilder()
            .addComponents(
              new StringSelectMenuBuilder()
                .setCustomId('bank_options')
                .setPlaceholder('Select a bank option')
                .addOptions(bankOptions)
            );
          
          await interaction.editReply({
            embeds: [embed],
            components: [selectMenu]
          });
          
          log(`Bank balance checked by ${user.tag} [${user.id}]`);
        } catch (error) {
          logError(`Error checking bank balance:`, error);
          await interaction.editReply('❌ An error occurred while checking your bank balance. Please try again later.');
        }
      }
      
      // Handle bank fulfill command (banker only)
      else if (subcommand === 'fulfill') {
        // Check if user has the banker role
        const hasBankerRole = interaction.member.roles.cache.has(bankerRoleId);
        if (!hasBankerRole && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return interaction.reply({
            content: `❌ Only members with the <@&${bankerRoleId}> role can fulfill bank requests.`,
            ephemeral: true
          });
        }
        
        // Get the request ID
        const requestId = interaction.options.getString('request_id');
        
        // Check if the request exists
        const request = getBankRequest(guildId, requestId);
        if (!request) {
          return interaction.reply({
            content: `❌ Bank request #${requestId} not found.`,
            ephemeral: true
          });
        }
        
        // Check if the request is already fulfilled or cancelled
        if (request.status !== 'pending') {
          return interaction.reply({
            content: `❌ Bank request #${requestId} is already ${request.status}.`,
            ephemeral: true
          });
        }
        
        // Mark the request as fulfilled
        const success = updateBankRequest(guildId, requestId, 'fulfilled', user.id);
        
        if (!success) {
          return interaction.reply({
            content: '❌ Error fulfilling bank request. Please try again later.',
            ephemeral: true
          });
        }
        
        // Confirmation message
        await interaction.reply({
          content: `✅ Bank request #${requestId} has been marked as fulfilled. The user will be notified the next time they use a bank command.`,
          ephemeral: true
        });
        
        log(`Bank request ${requestId} fulfilled by ${user.tag} [${user.id}]`);
      }
      
      // Handle request cancellation (banker or requester only)
      else if (subcommand === 'cancel') {
        // Get the request ID
        const requestId = interaction.options.getString('request_id');
        
        // Check if the request exists
        const request = getBankRequest(guildId, requestId);
        if (!request) {
          return interaction.reply({
            content: `❌ Bank request #${requestId} not found.`,
            ephemeral: true
          });
        }
        
        // Check if the request is already fulfilled or cancelled
        if (request.status !== 'pending') {
          return interaction.reply({
            content: `❌ Bank request #${requestId} is already ${request.status}.`,
            ephemeral: true
          });
        }
        
        // Check if user is the requester or has banker role
        const isRequester = request.requesterId === user.id;
        const hasBankerRole = interaction.member.roles.cache.has(bankerRoleId);
        const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
        
        if (!isRequester && !hasBankerRole && !isAdmin) {
          return interaction.reply({
            content: '❌ You can only cancel your own requests or use the banker role.',
            ephemeral: true
          });
        }
        
        // Mark the request as cancelled
        const success = updateBankRequest(guildId, requestId, 'cancelled', user.id);
        
        if (!success) {
          return interaction.reply({
            content: '❌ Error cancelling bank request. Please try again later.',
            ephemeral: true
          });
        }
        
        // Confirmation message
        await interaction.reply({
          content: `✅ Bank request #${requestId} has been cancelled.`,
          ephemeral: true
        });
        
        log(`Bank request ${requestId} cancelled by ${user.tag} [${user.id}]`);
      }
    }
  },
  
  /**
   * Handle select menu interactions
   * @param {SelectMenuInteraction} interaction - Select menu interaction
   * @param {Client} client - Discord client
   */
  async handleSelectMenu(interaction, client) {
    const { guildId, user, values } = interaction;
    const value = values[0]; // Get the selected option
    
    // Check if bank is configured or faction is registered
    const isBankConfigured = await hasBankConfig(guildId);
    if (!isBankConfigured) {
      return interaction.reply({
        content: '❌ Faction not registered. Please ask an administrator to use `/factionregister` first.',
        ephemeral: true
      });
    }
    
    // Get server config for bank settings
    const serverConfig = getServerConfig(guildId);
    let bankerRoleId = null;
    
    // Use traditional bank config if available
    if (serverConfig && serverConfig.bankConfig) {
      bankerRoleId = serverConfig.bankConfig.bankerRoleId;
    }
    
    // Check if user is a banker or admin
    const hasBankerRole = bankerRoleId ? interaction.member.roles.cache.has(bankerRoleId) : false;
    const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
    const isBanker = hasBankerRole || isAdmin;
    
    // Handle different options
    if (value === 'bank_withdraw') {
      // Show withdrawal request modal
      const modal = new ModalBuilder()
        .setCustomId('bank_withdrawal_modal')
        .setTitle('Request Bank Withdrawal');
      
      const amountInput = new TextInputBuilder()
        .setCustomId('withdrawal_amount')
        .setLabel('Amount (numbers only)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Enter amount (e.g. 10000000)')
        .setRequired(true);
      
      const reasonInput = new TextInputBuilder()
        .setCustomId('withdrawal_reason')
        .setLabel('Reason for withdrawal')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Enter reason for withdrawal')
        .setRequired(false);
      
      const firstRow = new ActionRowBuilder().addComponents(amountInput);
      const secondRow = new ActionRowBuilder().addComponents(reasonInput);
      
      modal.addComponents(firstRow, secondRow);
      
      await interaction.showModal(modal);
    }
    else if (value === 'bank_mybalance') {
      // Get API key
      const apiKey = await keyStorageService.getApiKey(user.id, 'torn');
      if (!apiKey) {
        return interaction.reply({
          content: '❌ You need to set up your API key first with `/apikey`.',
          ephemeral: true
        });
      }
      
      // Defer reply while we fetch data
      await interaction.deferReply({ ephemeral: true });
      
      try {
        // Fetch user information to get their Torn ID
        const userResponse = await fetch(`https://api.torn.com/user/?selections=basic&key=${apiKey}`);
        const userData = await userResponse.json();
        
        if (userData.error) {
          return interaction.editReply(`❌ API Error: ${userData.error.error}`);
        }
        
        const tornId = userData.player_id;
        const tornName = userData.name;
        
        // Fetch player's bank balance
        const balance = await getPlayerBalance(tornId, apiKey);
        
        if (balance === null) {
          return interaction.editReply('❌ Could not fetch your faction bank balance. Make sure your API key has the correct permissions.');
        }
        
        // Check if there are any pending requests from this user
        const pendingRequests = getPendingBankRequests(guildId).filter(req => req.tornId === tornId.toString());
        
        // Create embed with player's bank information
        const embed = new EmbedBuilder()
          .setTitle('💰 Your Faction Bank Information')
          .setColor(BOT_CONFIG.color)
          .setDescription(`Here's your faction bank information, ${tornName}.`)
          .addFields(
            { name: 'Your Balance', value: `$${formatNumber(balance)}`, inline: true }
          )
          .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
          .setTimestamp();
        
        // Add pending requests if any
        if (pendingRequests.length > 0) {
          const requestsText = pendingRequests.map(req => 
            `Request #${req.id.substring(0, 6)}: $${formatNumber(req.amount)} (${req.status})`
          ).join('\n');
          
          embed.addFields({ name: 'Your Pending Requests', value: requestsText });
        }
        
        await interaction.editReply({
          embeds: [embed]
        });
      } catch (error) {
        logError(`Error checking bank balance:`, error);
        await interaction.editReply('❌ An error occurred while checking your bank balance. Please try again later.');
      }
    }
    else if (value === 'bank_memberbalance') {
      // Check if user is a banker
      if (!isBanker) {
        return interaction.reply({
          content: '❌ Only bankers can view other members\' balances.',
          ephemeral: true
        });
      }
      
      // Show member balance lookup modal
      const modal = new ModalBuilder()
        .setCustomId('bank_memberbalance_modal')
        .setTitle('View Member Balance');
      
      const memberIdInput = new TextInputBuilder()
        .setCustomId('member_id')
        .setLabel('Member\'s Torn ID')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Enter member\'s Torn ID')
        .setRequired(true);
      
      const firstRow = new ActionRowBuilder().addComponents(memberIdInput);
      modal.addComponents(firstRow);
      
      await interaction.showModal(modal);
    }
    else if (value === 'bank_allrequests') {
      // Check if user is a banker
      if (!isBanker) {
        return interaction.reply({
          content: '❌ Only bankers can view all withdrawal requests.',
          ephemeral: true
        });
      }
      
      // Get all pending requests
      const pendingRequests = getPendingBankRequests(guildId);
      
      if (pendingRequests.length === 0) {
        return interaction.reply({
          content: '✅ There are no pending withdrawal requests.',
          ephemeral: true
        });
      }
      
      // Create embed with all pending requests
      const embed = new EmbedBuilder()
        .setTitle('📋 Pending Bank Withdrawal Requests')
        .setColor(BOT_CONFIG.color)
        .setDescription(`There are ${pendingRequests.length} pending withdrawal requests.`)
        .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
        .setTimestamp();
      
      // Group requests by member
      const requestsByMember = {};
      pendingRequests.forEach(req => {
        if (!requestsByMember[req.tornName]) {
          requestsByMember[req.tornName] = [];
        }
        requestsByMember[req.tornName].push(req);
      });
      
      // Add each member's requests to the embed
      Object.keys(requestsByMember).forEach(memberName => {
        const memberRequests = requestsByMember[memberName];
        const requestsText = memberRequests.map(req => 
          `Request #${req.id.substring(0, 6)}: $${formatNumber(req.amount)} (${req.reason || 'No reason provided'})`
        ).join('\n');
        
        embed.addFields({ name: `${memberName} [${memberRequests[0].tornId}]`, value: requestsText });
      });
      
      // Add fulfill request buttons for each request
      const rows = [];
      let buttonsAdded = 0;
      let currentRow = new ActionRowBuilder();
      
      pendingRequests.slice(0, 5).forEach(req => {
        const button = new ButtonBuilder()
          .setCustomId(`bank_pay_${req.id}`)
          .setLabel(`Pay #${req.id.substring(0, 6)}`)
          .setStyle(ButtonStyle.Success);
        
        currentRow.addComponents(button);
        buttonsAdded++;
        
        if (buttonsAdded % 5 === 0) {
          rows.push(currentRow);
          currentRow = new ActionRowBuilder();
        }
      });
      
      if (buttonsAdded % 5 !== 0) {
        rows.push(currentRow);
      }
      
      await interaction.reply({
        embeds: [embed],
        components: rows,
        ephemeral: true
      });
    }
  },
  
  /**
   * Handle button interactions
   * @param {ButtonInteraction} interaction - Button interaction
   * @param {Client} client - Discord client
   */
  async handleButton(interaction, client) {
    const { guildId, user } = interaction;
    
    // Handle bank pay buttons for withdrawal requests
    if (interaction.customId.startsWith('bank_pay_')) {
      const requestId = interaction.customId.split('_')[2];
      
      // Get server config
      const serverConfig = getServerConfig(guildId);
      let bankerRoleId = null;
      
      // Use traditional bank config if available
      if (serverConfig && serverConfig.bankConfig) {
        bankerRoleId = serverConfig.bankConfig.bankerRoleId;
      }
      
      // Check if user is a banker or admin
      const hasBankerRole = bankerRoleId ? interaction.member.roles.cache.has(bankerRoleId) : false;
      const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
      const isBanker = hasBankerRole || isAdmin;
      
      if (!isBanker) {
        return interaction.reply({
          content: '❌ Only bankers can fulfill withdrawal requests.',
          ephemeral: true
        });
      }
      
      // Check if the request exists
      const request = getBankRequest(guildId, requestId);
      if (!request) {
        return interaction.reply({
          content: `❌ Bank request #${requestId} not found.`,
          ephemeral: true
        });
      }
      
      // Check if the request is already fulfilled or cancelled
      if (request.status !== 'pending') {
        return interaction.reply({
          content: `❌ Bank request #${requestId} is already ${request.status}.`,
          ephemeral: true
        });
      }
      
      // Create a direct bank URL for this payment
      const bankURL = generateBankURL(request.tornId, request.amount);
      
      // Create embed with withdrawal details
      const embed = new EmbedBuilder()
        .setTitle('💰 Bank Withdrawal Request')
        .setColor(BOT_CONFIG.color)
        .setDescription(`Please click the button below to open the Torn bank page and send $${formatNumber(request.amount)} to ${request.tornName} [${request.tornId}].`)
        .addFields(
          { name: 'Amount', value: `$${formatNumber(request.amount)}`, inline: true },
          { name: 'Member', value: `${request.tornName} [${request.tornId}]`, inline: true },
          { name: 'Reason', value: request.reason || 'No reason provided' }
        )
        .setFooter({ text: `Request ID: ${requestId}` })
        .setTimestamp();
      
      // Add buttons to confirm payment or cancel
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setURL(bankURL)
            .setLabel('Open Torn Bank')
            .setStyle(ButtonStyle.Link),
          new ButtonBuilder()
            .setCustomId(`bank_confirm_${requestId}`)
            .setLabel('Confirm Payment Sent')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`bank_cancel_${requestId}`)
            .setLabel('Cancel Request')
            .setStyle(ButtonStyle.Danger)
        );
      
      await interaction.reply({
        embeds: [embed],
        components: [row],
        ephemeral: true
      });
    }
    // Handle confirmation of payment
    else if (interaction.customId.startsWith('bank_confirm_')) {
      const requestId = interaction.customId.split('_')[2];
      
      // Get server config for banker role
      const serverConfig = getServerConfig(guildId);
      let bankerRoleId = null;
      
      // Use traditional bank config if available
      if (serverConfig && serverConfig.bankConfig) {
        bankerRoleId = serverConfig.bankConfig.bankerRoleId;
      }
      
      // Check if user is a banker or admin
      const hasBankerRole = bankerRoleId ? interaction.member.roles.cache.has(bankerRoleId) : false;
      const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
      const isBanker = hasBankerRole || isAdmin;
      
      if (!isBanker) {
        return interaction.reply({
          content: '❌ Only bankers can confirm payments.',
          ephemeral: true
        });
      }
      
      // Check if the request exists
      const request = getBankRequest(guildId, requestId);
      if (!request) {
        return interaction.reply({
          content: `❌ Bank request #${requestId} not found.`,
          ephemeral: true
        });
      }
      
      // Check if the request is already fulfilled or cancelled
      if (request.status !== 'pending') {
        return interaction.reply({
          content: `❌ Bank request #${requestId} is already ${request.status}.`,
          ephemeral: true
        });
      }
      
      // Mark the request as fulfilled
      const success = updateBankRequest(guildId, requestId, 'fulfilled', user.id);
      
      if (!success) {
        return interaction.reply({
          content: '❌ Error fulfilling bank request. Please try again later.',
          ephemeral: true
        });
      }
      
      // Update the interaction message
      try {
        await interaction.update({
          content: `✅ Payment for $${formatNumber(request.amount)} to ${request.tornName} [${request.tornId}] has been confirmed.`,
          embeds: [],
          components: []
        });
      } catch (error) {
        logError('Error updating payment confirmation message:', error);
      }
      
      log(`Bank request ${requestId} fulfilled by ${user.tag} [${user.id}]`);
    }
    // Handle bank request fulfillment buttons (legacy)
    else if (interaction.customId.startsWith('bank_fulfill_')) {
      const requestId = interaction.customId.split('_')[2];
      
      // Get server config
      const serverConfig = getServerConfig(guildId);
      if (!serverConfig || !serverConfig.bankConfig) {
        return interaction.reply({
          content: '❌ Faction bank not configured.',
          ephemeral: true
        });
      }
      
      const { bankerRoleId } = serverConfig.bankConfig;
      
      // Check if user has the banker role
      const hasBankerRole = interaction.member.roles.cache.has(bankerRoleId);
      if (!hasBankerRole && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({
          content: `❌ Only members with the <@&${bankerRoleId}> role can fulfill bank requests.`,
          ephemeral: true
        });
      }
      
      // Check if the request exists
      const request = getBankRequest(guildId, requestId);
      if (!request) {
        return interaction.reply({
          content: `❌ Bank request #${requestId} not found.`,
          ephemeral: true
        });
      }
      
      // Check if the request is already fulfilled or cancelled
      if (request.status !== 'pending') {
        // Update the message
        try {
          const row = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId(`bank_status_${requestId}`)
                .setLabel(`Status: ${request.status}`)
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true)
            );
          
          // Update the message
          await interaction.message.edit({
            content: `❌ This request is already ${request.status}`,
            components: [row]
          });
        } catch (error) {
          logError('Error updating bank request message:', error);
          // Not critical, so we'll continue
        }
        
        return interaction.reply({
          content: `❌ Bank request #${requestId} is already ${request.status}.`,
          ephemeral: true
        });
      }
      
      // Mark the request as fulfilled
      const success = updateBankRequest(guildId, requestId, 'fulfilled', user.id);
      
      if (!success) {
        return interaction.reply({
          content: '❌ Error fulfilling bank request. Please try again later.',
          ephemeral: true
        });
      }
      
      // Update the message
      try {
        const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId(`bank_status_${requestId}`)
              .setLabel('Status: Fulfilled')
              .setStyle(ButtonStyle.Success)
              .setDisabled(true)
          );
        
        // Update the message
        await interaction.message.edit({
          content: `✅ Request fulfilled by <@${user.id}>`,
          components: [row]
        });
      } catch (error) {
        logError('Error updating bank request message:', error);
        // Not critical, so we'll continue
      }
      
      // Confirmation message
      await interaction.reply({
        content: `✅ Bank request #${requestId} has been fulfilled. The user will be notified the next time they use a bank command.`,
        ephemeral: true
      });
      
      log(`Bank request ${requestId} fulfilled by ${user.tag} [${user.id}]`);
      return;
    }
    
    // Handle bank request cancellation buttons
    if (interaction.customId.startsWith('bank_cancel_')) {
      const requestId = interaction.customId.split('_')[2];
      
      // Get server config
      const serverConfig = getServerConfig(guildId);
      if (!serverConfig || !serverConfig.bankConfig) {
        return interaction.reply({
          content: '❌ Faction bank not configured.',
          ephemeral: true
        });
      }
      
      const { bankerRoleId } = serverConfig.bankConfig;
      
      // Check if the request exists
      const request = getBankRequest(guildId, requestId);
      if (!request) {
        return interaction.reply({
          content: `❌ Bank request #${requestId} not found.`,
          ephemeral: true
        });
      }
      
      // Check if the request is already fulfilled or cancelled
      if (request.status !== 'pending') {
        // Update the message
        try {
          const row = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId(`bank_status_${requestId}`)
                .setLabel(`Status: ${request.status}`)
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true)
            );
          
          // Update the message
          await interaction.message.edit({
            content: `❌ This request is already ${request.status}`,
            components: [row]
          });
        } catch (error) {
          logError('Error updating bank request message:', error);
          // Not critical, so we'll continue
        }
        
        return interaction.reply({
          content: `❌ Bank request #${requestId} is already ${request.status}.`,
          ephemeral: true
        });
      }
      
      // Check if user is the requester or has banker role
      const isRequester = request.requesterId === user.id;
      const hasBankerRole = interaction.member.roles.cache.has(bankerRoleId);
      const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!isRequester && !hasBankerRole && !isAdmin) {
        return interaction.reply({
          content: '❌ You can only cancel your own requests or use the banker role.',
          ephemeral: true
        });
      }
      
      // Mark the request as cancelled
      const success = updateBankRequest(guildId, requestId, 'cancelled', user.id);
      
      if (!success) {
        return interaction.reply({
          content: '❌ Error cancelling bank request. Please try again later.',
          ephemeral: true
        });
      }
      
      // Update the message
      try {
        const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId(`bank_status_${requestId}`)
              .setLabel('Status: Cancelled')
              .setStyle(ButtonStyle.Danger)
              .setDisabled(true)
          );
        
        // Update the message
        await interaction.message.edit({
          content: `❌ Request cancelled by <@${user.id}>`,
          components: [row]
        });
      } catch (error) {
        logError('Error updating bank request message:', error);
        // Not critical, so we'll continue
      }
      
      log(`Bank request ${requestId} cancelled by ${user.tag} [${user.id}]`);
      return;
    }
    
    // Handle withdraw button (improved with better error handling)
    if (interaction.customId === 'bank_withdraw') {
      try {
        // Check if faction is registered
        const isBankConfigured = await hasBankConfig(guildId);
        if (!isBankConfigured) {
          return interaction.reply({
            content: '❌ Faction not registered. Please ask an administrator to use `/factionregister` first.',
            ephemeral: true
          });
        }
        
        // Get server config for bank settings
        const serverConfig = getServerConfig(guildId);
        
        // Get user's API key
        const apiKey = await keyStorageService.getApiKey(user.id, 'torn');
        if (!apiKey) {
          return interaction.reply({
            content: '❌ You need to set up your API key first with `/apikey`.',
            ephemeral: true
          });
        }
        
        // Show modal for withdrawal amount
        const modal = new ModalBuilder()
          .setCustomId('bank_withdraw_modal')
          .setTitle('Bank Withdrawal Request');
        
        const amountInput = new TextInputBuilder()
          .setCustomId('withdrawal_amount')
          .setLabel('Amount to withdraw')
          .setPlaceholder('Enter amount (e.g. 10000000)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMinLength(1)
          .setMaxLength(20);
        
        const reasonInput = new TextInputBuilder()
          .setCustomId('withdrawal_reason')
          .setLabel('Reason for withdrawal')
          .setPlaceholder('Enter reason (optional)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
          .setMaxLength(500);
        
        const amountRow = new ActionRowBuilder().addComponents(amountInput);
        const reasonRow = new ActionRowBuilder().addComponents(reasonInput);
        
        modal.addComponents(amountRow, reasonRow);
        
        await interaction.showModal(modal);
      } catch (error) {
        logError('Error handling bank withdraw button:', error);
        await interaction.reply({
          content: '❌ An error occurred while processing your request. Please try again later.',
          ephemeral: true
        }).catch(() => {});
      }
    }
  },
  
  /**
   * Handle select menu interactions
   * @param {StringSelectMenuInteraction} interaction - Select menu interaction
   * @param {Client} client - Discord client
   */
  async handleSelectMenu(interaction, client) {
    const { guildId, user } = interaction;
    const selectedValue = interaction.values[0];
    
    log(`Bank select menu interaction: ${selectedValue} by ${user.tag}`);
    
    try {
      // Get server config
      const serverConfig = getServerConfig(guildId);
      let bankerRoleId = null;
      
      // Use traditional bank config if available
      if (serverConfig && serverConfig.bankConfig) {
        bankerRoleId = serverConfig.bankConfig.bankerRoleId;
      }
      
      // Check if user is a banker or admin
      const hasBankerRole = bankerRoleId ? interaction.member.roles.cache.has(bankerRoleId) : false;
      const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
      const isBanker = hasBankerRole || isAdmin;
      
      // Process the selected option
      switch (selectedValue) {
        case 'bank_withdraw':
          // Show withdrawal request modal
          const withdrawModal = new ModalBuilder()
            .setCustomId('bank_withdraw_modal')
            .setTitle('Faction Bank Withdrawal Request');
            
          const amountInput = new TextInputBuilder()
            .setCustomId('withdraw_amount')
            .setLabel('Amount (numbers only)')
            .setPlaceholder('Enter amount (e.g., 1000000)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true);
            
          const reasonInput = new TextInputBuilder()
            .setCustomId('withdraw_reason')
            .setLabel('Reason for withdrawal')
            .setPlaceholder('Why do you need these funds?')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);
            
          const firstRow = new ActionRowBuilder().addComponents(amountInput);
          const secondRow = new ActionRowBuilder().addComponents(reasonInput);
          
          withdrawModal.addComponents(firstRow, secondRow);
          
          await interaction.showModal(withdrawModal);
          break;
          
        case 'bank_mybalance':
          // Check user's balance
          await interaction.deferReply({ ephemeral: true });
          
          try {
            // Get user's API key
            const apiKey = await keyStorageService.getApiKey(user.id, 'torn');
            
            if (!apiKey) {
              return interaction.editReply({
                content: '❌ You need to set your Torn API key first with `/apikey set`.',
                ephemeral: true
              });
            }
            
            // Get user's Torn profile
            const userData = await fetch(`https://api.torn.com/user/?selections=basic&key=${apiKey}`)
              .then(res => res.json());
              
            if (userData.error) {
              return interaction.editReply({
                content: `❌ Error accessing Torn API: ${userData.error.error}`,
                ephemeral: true
              });
            }
            
            const balance = await getPlayerBalance(userData.player_id, apiKey);
            
            // Create embed with user's balance
            const embed = new EmbedBuilder()
              .setTitle('💰 Your Faction Bank Balance')
              .setColor(BOT_CONFIG.color)
              .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
              .setTimestamp();
              
            if (balance !== null) {
              embed.setDescription(`Your current faction bank balance: $${formatNumber(balance)}`);
            } else {
              embed.setDescription('Unable to retrieve your faction bank balance. You may not have sufficient API key access or you are not in a faction.');
            }
            
            await interaction.editReply({
              embeds: [embed],
              ephemeral: true
            });
          } catch (error) {
            logError('Error getting player balance:', error);
            await interaction.editReply({
              content: '❌ Error getting your balance. Please try again later.',
              ephemeral: true
            });
          }
          break;
          
        case 'bank_memberbalance':
          // Check if user is a banker
          if (!isBanker) {
            return interaction.reply({
              content: '❌ Only bankers can check member balances.',
              ephemeral: true
            });
          }
          
          // Show member lookup modal
          const memberModal = new ModalBuilder()
            .setCustomId('bank_member_lookup_modal')
            .setTitle('Member Balance Lookup');
            
          const memberIdInput = new TextInputBuilder()
            .setCustomId('member_id')
            .setLabel('Member Torn ID')
            .setPlaceholder('Enter the member\'s Torn ID')
            .setStyle(TextInputStyle.Short)
            .setRequired(true);
            
          const memberRow = new ActionRowBuilder().addComponents(memberIdInput);
          
          memberModal.addComponents(memberRow);
          
          await interaction.showModal(memberModal);
          break;
          
        case 'bank_allrequests':
          // Check if user is a banker
          if (!isBanker) {
            return interaction.reply({
              content: '❌ Only bankers can view all requests.',
              ephemeral: true
            });
          }
          
          await interaction.deferReply({ ephemeral: true });
          
          // Get all pending requests
          const pendingRequests = getPendingBankRequests(guildId);
          
          if (pendingRequests.length === 0) {
            return interaction.editReply({
              content: '✅ No pending bank requests.',
              ephemeral: true
            });
          }
          
          // Create embed with all pending requests
          const requestsEmbed = new EmbedBuilder()
            .setTitle('📋 Pending Bank Requests')
            .setColor(BOT_CONFIG.color)
            .setDescription(`There are ${pendingRequests.length} pending bank requests.`)
            .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
            .setTimestamp();
            
          // Add each request as a field
          pendingRequests.forEach(request => {
            const requestAge = Math.floor((Date.now() - request.requestTime) / (1000 * 60 * 60));
            requestsEmbed.addFields({
              name: `Request #${request.id} (${requestAge} hours ago)`,
              value: `**From:** ${request.tornName} [${request.tornId}]\n**Amount:** $${formatNumber(request.amount)}\n**Reason:** ${request.reason}`
            });
          });
          
          await interaction.editReply({
            embeds: [requestsEmbed],
            ephemeral: true
          });
          break;
          
        default:
          await interaction.reply({
            content: '❌ Unknown bank option.',
            ephemeral: true
          });
      }
    } catch (error) {
      logError('Error handling bank select menu interaction:', error);
      
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: '❌ There was an error processing your bank option. Please try again later.',
          ephemeral: true
        }).catch(e => logError('Failed to send error reply:', e));
      } else if (interaction.deferred) {
        await interaction.editReply({
          content: '❌ There was an error processing your bank option. Please try again later.',
          ephemeral: true
        }).catch(e => logError('Failed to send error reply:', e));
      }
    }
  },
  
  /**
   * Handle modal submissions
   * @param {ModalSubmitInteraction} interaction - Modal submission interaction
   * @param {Client} client - Discord client
   */
  async handleModal(interaction, client) {
    const { guildId, user } = interaction;
    
    if (interaction.customId === 'bank_withdraw_modal' || interaction.customId === 'bank_withdrawal_modal') {
      try {
        // Get input values
        const amountString = interaction.fields.getTextInputValue('withdrawal_amount');
        const reason = interaction.fields.getTextInputValue('withdrawal_reason') || 'No reason provided';
        
        // Validate amount
        let amount;
        try {
          // Remove commas, spaces, and dollar signs
          const cleanedAmount = amountString.replace(/[$,\s]/g, '');
          amount = parseInt(cleanedAmount);
          
          if (isNaN(amount) || amount <= 0) {
            return interaction.reply({
              content: '❌ Please enter a valid positive number for the withdrawal amount.',
              ephemeral: true
            });
          }
        } catch (error) {
          return interaction.reply({
            content: '❌ Invalid amount format. Please enter a valid number.',
            ephemeral: true
          });
        }
        
        // Get user's API key
        const apiKey = await keyStorageService.getApiKey(user.id, 'torn');
        if (!apiKey) {
          return interaction.reply({
            content: '❌ You need to set up your API key first with `/apikey`.',
            ephemeral: true
          });
        }
        
        // Defer reply while we process
        await interaction.deferReply({ ephemeral: true });
        
        try {
          // Fetch user information to get their Torn ID
          const userResponse = await fetch(`https://api.torn.com/user/?selections=basic&key=${apiKey}`);
          const userData = await userResponse.json();
          
          if (userData.error) {
            return interaction.editReply(`❌ API Error: ${userData.error.error}`);
          }
          
          const tornId = userData.player_id;
          const tornName = userData.name;
          
          // Get server config
          const serverConfig = getServerConfig(guildId);
          const { channelId, bankerRoleId } = serverConfig.bankConfig;
          
          // Create the bank request with a clearer identifier
          const requestId = crypto.randomBytes(4).toString('hex');
          
          // Log the request details for debugging
          log(`Attempting to create bank request for ${tornName} [${tornId}] - $${formatNumber(amount)} - Reason: ${reason}`);
          
          // Store the request - matching the signature expected by the bank-service.js
          const success = createBankRequest(guildId, requestId, user.id, tornId.toString(), tornName, amount, reason);
          
          if (!success) {
            return interaction.editReply('❌ Error creating bank request. Please try again later.');
          }
          
          // Get the channel
          const channel = await client.channels.fetch(channelId);
          
          if (!channel) {
            return interaction.editReply('❌ Bank channel not found. Please contact an administrator.');
          }
          
          // Create the bank request embed
          const embed = new EmbedBuilder()
            .setTitle('💰 Bank Withdrawal Request')
            .setColor(BOT_CONFIG.color)
            .setDescription(`A new bank withdrawal request has been submitted.`)
            .addFields(
              { name: 'Request ID', value: `#${requestId}`, inline: true },
              { name: 'Player', value: `${tornName} [${tornId}]`, inline: true },
              { name: 'Amount', value: `$${formatNumber(amount)}`, inline: true },
              { name: 'Requested By', value: `<@${user.id}>`, inline: true },
              { name: 'Banker Role', value: `<@&${bankerRoleId}>`, inline: true },
              { name: 'Status', value: 'Pending', inline: true },
              { name: 'Reason', value: reason }
            )
            .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
            .setTimestamp();
          
          // Create buttons for the request
          const row = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId(`bank_fulfill_${requestId}`)
                .setLabel('Fulfill Request')
                .setStyle(ButtonStyle.Success)
                .setEmoji('✅'),
              
              new ButtonBuilder()
                .setCustomId(`bank_cancel_${requestId}`)
                .setLabel('Cancel Request')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('❌'),
                
              new ButtonBuilder()
                .setURL(generateBankURL(tornId, amount))
                .setLabel('Open Faction Bank')
                .setStyle(ButtonStyle.Link)
                .setEmoji('🔗')
            );
          
          // Send the request to the bank channel
          await channel.send({
            content: `<@&${bankerRoleId}> New withdrawal request from <@${user.id}>`,
            embeds: [embed],
            components: [row]
          });
          
          // Confirmation message to the user
          await interaction.editReply({
            content: `✅ Your withdrawal request for $${formatNumber(amount)} has been submitted. You will be notified when it's fulfilled.`,
            ephemeral: true
          });
          
          log(`Bank withdrawal request #${requestId} created by ${user.tag} [${user.id}] for $${formatNumber(amount)}`);
        } catch (error) {
          logError('Error processing withdrawal request:', error);
          await interaction.editReply('❌ An error occurred while processing your withdrawal request. Please try again later.');
        }
      } catch (error) {
        logError('Error handling bank withdraw modal:', error);
        
        if (interaction.replied || interaction.deferred) {
          await interaction.editReply({
            content: '❌ An error occurred while processing your withdrawal request. Please try again later.',
            ephemeral: true
          }).catch(() => {});
        } else {
          await interaction.reply({
            content: '❌ An error occurred while processing your withdrawal request. Please try again later.',
            ephemeral: true
          }).catch(() => {});
        }
      }
    }
    // Handle member balance lookup modal
    else if (interaction.customId === 'bank_memberbalance_modal') {
      try {
        // Get member ID from the modal
        const memberId = interaction.fields.getTextInputValue('member_id');
        
        // Validate member ID format (numeric)
        if (!/^\d+$/.test(memberId)) {
          return interaction.reply({
            content: '❌ Member ID must be a numeric Torn ID.',
            ephemeral: true
          });
        }
        
        // Get server config
        const serverConfig = getServerConfig(guildId);
        let bankerRoleId = null;
        
        // Use traditional bank config if available
        if (serverConfig && serverConfig.bankConfig) {
          bankerRoleId = serverConfig.bankConfig.bankerRoleId;
        }
        
        // Check if user is a banker or admin
        const hasBankerRole = bankerRoleId ? interaction.member.roles.cache.has(bankerRoleId) : false;
        const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
        const isBanker = hasBankerRole || isAdmin;
        
        if (!isBanker) {
          return interaction.reply({
            content: '❌ Only bankers can view other members\' balances.',
            ephemeral: true
          });
        }
        
        // Get the banker's API key
        const apiKey = await keyStorageService.getApiKey(user.id, 'torn');
        if (!apiKey) {
          return interaction.reply({
            content: '❌ You need to set up your API key first with `/apikey`.',
            ephemeral: true
          });
        }
        
        // Defer reply while we fetch data
        await interaction.deferReply({ ephemeral: true });
        
        try {
          // Fetch member information
          const memberResponse = await fetch(`https://api.torn.com/user/${memberId}?selections=basic,profile&key=${apiKey}`);
          const memberData = await memberResponse.json();
          
          if (memberData.error) {
            return interaction.editReply(`❌ API Error: ${memberData.error.error}`);
          }
          
          const memberName = memberData.name;
          
          // Fetch member's bank balance
          const balance = await getPlayerBalance(memberId, apiKey);
          
          if (balance === null) {
            return interaction.editReply('❌ Could not fetch member\'s faction bank balance. Make sure your API key has the correct permissions.');
          }
          
          // Check if there are any pending requests from this member
          const pendingRequests = getPendingBankRequests(guildId).filter(req => req.tornId === memberId);
          
          // Create embed with member's bank information
          const embed = new EmbedBuilder()
            .setTitle('💰 Member\'s Faction Bank Information')
            .setColor(BOT_CONFIG.color)
            .setDescription(`Faction bank information for ${memberName} [${memberId}]`)
            .addFields(
              { name: 'Member Balance', value: `$${formatNumber(balance)}`, inline: true }
            )
            .setFooter({ text: `Requested by ${user.tag} | ${BOT_CONFIG.name} v${BOT_CONFIG.version}` })
            .setTimestamp();
          
          // Add pending requests if any
          if (pendingRequests.length > 0) {
            const requestsText = pendingRequests.map(req => 
              `Request #${req.id.substring(0, 6)}: $${formatNumber(req.amount)} (${req.status})`
            ).join('\n');
            
            embed.addFields({ name: 'Pending Requests', value: requestsText });
          }
          
          // Add pay button if there are pending requests
          const components = [];
          if (pendingRequests.length > 0) {
            const row = new ActionRowBuilder();
            pendingRequests.filter(req => req.status === 'pending').slice(0, 5).forEach(req => {
              row.addComponents(
                new ButtonBuilder()
                  .setCustomId(`bank_pay_${req.id}`)
                  .setLabel(`Pay #${req.id.substring(0, 6)}`)
                  .setStyle(ButtonStyle.Success)
              );
            });
            
            if (row.components.length > 0) {
              components.push(row);
            }
          }
          
          await interaction.editReply({
            embeds: [embed],
            components: components
          });
          
          log(`Member bank balance for ${memberName} [${memberId}] checked by ${user.tag} [${user.id}]`);
        } catch (error) {
          logError(`Error checking member bank balance:`, error);
          await interaction.editReply('❌ An error occurred while checking the member\'s bank balance. Please try again later.');
        }
      } catch (error) {
        logError('Error handling member balance lookup modal:', error);
        
        if (interaction.replied || interaction.deferred) {
          await interaction.editReply({
            content: '❌ An error occurred while looking up the member\'s balance. Please try again later.',
            ephemeral: true
          }).catch(() => {});
        } else {
          await interaction.reply({
            content: '❌ An error occurred while looking up the member\'s balance. Please try again later.',
            ephemeral: true
          }).catch(() => {});
        }
      }
    }
  }
};

module.exports = bankCommand;