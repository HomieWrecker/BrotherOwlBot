"""
Owl Eye - Torn Faction Warfare Intelligence System
Main entry point for Discord bot functionality
"""

import os
import discord
from discord.ext import commands
import asyncio
import json
import logging
import datetime
import time
import sqlite3
import aiohttp
from dotenv import load_dotenv

# Import custom modules
from src.utils.stats_estimator import (
    get_spy_data, add_spy_data, estimate_primary_stat,
    estimate_total_stats, format_stats_for_display,
    get_stat_confidence, get_recommendation
)

# Add additional helper functions we need
async def fetch_player_name(player_id, api_key):
    """Fetch a player's name from the Torn API"""
    if not api_key:
        return None
    
    url = f"https://api.torn.com/user/{player_id}?selections=basic&key={api_key}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if 'error' in data:
                        logger.error(f"Torn API error: {data['error']}")
                        return None
                    return data.get('name')
                else:
                    logger.error(f"Failed to fetch player name: HTTP {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Error fetching player name: {e}")
        return None

async def get_player_faction(player_id, api_key):
    """Get a player's faction information from the Torn API"""
    if not api_key:
        return None, None
    
    url = f"https://api.torn.com/user/{player_id}?selections=basic&key={api_key}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if 'error' in data:
                        logger.error(f"Torn API error: {data['error']}")
                        return None, None
                    
                    faction_id = data.get('faction', {}).get('faction_id')
                    faction_name = data.get('faction', {}).get('faction_name')
                    
                    return str(faction_id) if faction_id else None, faction_name
                else:
                    logger.error(f"Failed to fetch player faction: HTTP {response.status}")
                    return None, None
    except Exception as e:
        logger.error(f"Error fetching player faction: {e}")
        return None, None

async def analyze_battle_log(battle_log_url, api_key):
    """
    Analyze a battle log to extract performance metrics and equipment information
    
    Args:
        battle_log_url (str): URL to a Torn battle log
        api_key (str): Torn API key for additional data

    Returns:
        dict: Battle analysis data including performance metrics and equipment
    """
    # In a real implementation, we would use web scraping or the Torn API
    # to extract detailed battle information. For now, we'll create a placeholder
    # with the expected structure.
    
    logger.info(f"Would analyze battle log: {battle_log_url}")
    
    # This is where we would parse the battle log
    # For now, return a structured example of what data might be extracted
    battle_analysis = {
        'avg_damage': 1250,
        'critical_hits': 15,
        'accuracy': 85,
        'stealth': 40,
        'equipment': {
            'primary': 'AK-47',
            'armor': 'Kevlar Vest',
            'boosters': ['Beer', 'Xanax']
        },
        'performance': {
            'turns_used': 5,
            'damage_done': 6250,
            'damage_received': 3000
        },
        'timestamp': int(time.time())
    }
    
    return battle_analysis

async def fetch_tornstats_data(player_id, api_key):
    """
    Fetch player data from TornStats API
    
    Args:
        player_id (str): Torn player ID
        api_key (str): TornStats API key

    Returns:
        dict: Player data from TornStats or None if not available
    """
    if not api_key:
        return None
    
    # TornStats has multiple API formats, try the most common
    url = f"https://www.tornstats.com/api/v2/{api_key}/spy/{player_id}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get('status') == "error":
                        logger.error(f"TornStats API error: {data.get('message', 'Unknown error')}")
                        return None
                    
                    # Extract the relevant spy data
                    spy_data = data.get('spy', {})
                    if not spy_data:
                        return None
                    
                    # Format it similarly to our internal spy data format
                    formatted_data = {
                        'strength': spy_data.get('strength', 0),
                        'speed': spy_data.get('speed', 0),
                        'dexterity': spy_data.get('dexterity', 0),
                        'defense': spy_data.get('defense', 0),
                        'total': spy_data.get('total', 0),
                        'source': 'TornStats',
                        'timestamp': int(time.time()),
                        'confidence': 'medium'  # TornStats data can be a bit less accurate
                    }
                    
                    return formatted_data
                else:
                    logger.error(f"Failed to fetch TornStats data: HTTP {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Error fetching TornStats data: {e}")
        return None

async def combine_intel_sources(player_id, spy_data=None, battle_data=None, tornstats_data=None):
    """
    Combine intelligence from multiple sources to get the most accurate picture
    
    Args:
        player_id (str): Player ID
        spy_data (dict): Data from our spy database
        battle_data (dict): Data from battle log analysis
        tornstats_data (dict): Data from TornStats API

    Returns:
        dict: Combined intelligence data
    """
    # Start with basic structure
    combined = {
        'player_id': player_id,
        'timestamp': int(time.time()),
        'confidence': 'low',
        'sources': []
    }
    
    # Track confidence level and source count
    confidence_score = 0
    source_count = 0
    
    # Add spy data if available
    if spy_data:
        source_count += 1
        combined['sources'].append('SpyDB')
        confidence_score += 3  # High weight for direct spy data
        
        # Add stat data
        combined['strength'] = spy_data.get('strength', 0)
        combined['speed'] = spy_data.get('speed', 0) 
        combined['dexterity'] = spy_data.get('dexterity', 0)
        combined['defense'] = spy_data.get('defense', 0)
        
        # Calculate total if not provided
        if 'total' not in spy_data:
            combined['total'] = (combined['strength'] + combined['speed'] + 
                                combined['dexterity'] + combined['defense'])
        else:
            combined['total'] = spy_data['total']
    
    # Add battle data if available
    if battle_data:
        source_count += 1
        combined['sources'].append('BattleLog')
        confidence_score += 2  # Medium weight for battle data
        
        # Extract equipment info
        if 'equipment' in battle_data:
            combined['equipment'] = battle_data['equipment']
        
        # Use performance metrics
        if 'performance' in battle_data:
            combined['performance'] = battle_data['performance']
        
        # Other battle metrics
        for key in ['avg_damage', 'critical_hits', 'accuracy', 'stealth']:
            if key in battle_data:
                combined[key] = battle_data[key]
    
    # Add TornStats data if available
    if tornstats_data:
        source_count += 1
        combined['sources'].append('TornStats')
        confidence_score += 1  # Lower weight for TornStats
        
        # If we don't have spy data, use TornStats for stats
        if not spy_data:
            combined['strength'] = tornstats_data.get('strength', 0)
            combined['speed'] = tornstats_data.get('speed', 0)
            combined['dexterity'] = tornstats_data.get('dexterity', 0)
            combined['defense'] = tornstats_data.get('defense', 0)
            combined['total'] = tornstats_data.get('total', 0)
    
    # Determine confidence level based on score and source count
    if source_count == 0:
        combined['confidence'] = 'Unknown'
    elif confidence_score >= 4 or source_count >= 2:
        combined['confidence'] = 'High'
    elif confidence_score >= 2:
        combined['confidence'] = 'Medium'
    else:
        combined['confidence'] = 'Low'
    
    # Calculate threat level based on stats and other factors
    await add_threat_assessment(combined)
    
    return combined

async def add_threat_assessment(intel_data):
    """
    Add threat assessment and recommendations based on player stats
    
    Args:
        intel_data (dict): Intelligence data to enhance
    """
    # Calculate threat level based on total stats if available
    if 'total' in intel_data and intel_data['total'] > 0:
        total_stats = intel_data['total']
        
        # Simple threat categorization based on total stats
        if total_stats > 500_000_000:  # 500M
            intel_data['threat_level'] = "Extreme"
            intel_data['recommendation'] = "Avoid unless you have 1B+ stats"
        elif total_stats > 100_000_000:  # 100M
            intel_data['threat_level'] = "High"
            intel_data['recommendation'] = "Requires strong stats and tactical advantage"
        elif total_stats > 10_000_000:  # 10M
            intel_data['threat_level'] = "Medium"
            intel_data['recommendation'] = "Approach with caution and good equipment"
        else:
            intel_data['threat_level'] = "Low"
            intel_data['recommendation'] = "Standard engagement possible"
    else:
        # If we don't have stats, use confidence level
        if intel_data['confidence'] == 'Unknown':
            intel_data['threat_level'] = "Unknown"
            intel_data['recommendation'] = "Gather more intelligence"
        else:
            intel_data['threat_level'] = "Undetermined"
            intel_data['recommendation'] = "Proceed with caution"
    
    # Enhance recommendation based on equipment if available
    if 'equipment' in intel_data:
        if 'primary' in intel_data['equipment']:
            weapon = intel_data['equipment']['primary']
            if weapon in ['RPG', 'Minigun', 'Flamethrower']:
                intel_data['recommendation'] += " - Beware of heavy weapons"
    
    # Consider boosters
    if 'equipment' in intel_data and 'boosters' in intel_data['equipment']:
        boosters = intel_data['equipment']['boosters']
        if 'Xanax' in boosters:
            intel_data['recommendation'] += " - Enemy likely using Xanax"

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('OwlEyeBot')

# Load environment variables
load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')
TORN_API_KEY = os.getenv('TORN_API_KEY')
TORNSTATS_API_KEY = os.getenv('TORNSTATS_API_KEY')

# Initialize database connection to BrotherOwl's database
DB_PATH = './data/brother_owl.db'

def get_db_connection():
    """Get a connection to the SQLite database"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")
        return None

def get_user_api_key(user_id):
    """
    Get Torn API key for a user from the database
    
    Args:
        user_id (str): Discord user ID
        
    Returns:
        str: Torn API key or None if not found
    """
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor()
        cursor.execute('SELECT torn_api_key FROM api_keys WHERE discord_id = ?', (str(user_id),))
        row = cursor.fetchone()
        if row:
            return row['torn_api_key']
        return None
    except sqlite3.Error as e:
        logger.error(f"Database error retrieving API key: {e}")
        return None
    finally:
        conn.close()

def get_user_faction_id(user_id):
    """
    Get faction ID for a user from the database
    
    Args:
        user_id (str): Discord user ID
        
    Returns:
        str: Faction ID or None if not found
    """
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor()
        cursor.execute('SELECT faction_id FROM faction_info WHERE discord_id = ?', (str(user_id),))
        row = cursor.fetchone()
        if row:
            return row['faction_id']
        return None
    except sqlite3.Error as e:
        logger.error(f"Database error retrieving faction ID: {e}")
        return None
    finally:
        conn.close()

def get_guild_faction_id(guild_id):
    """
    Get the primary faction ID for a guild
    
    Args:
        guild_id (str): Discord guild ID
        
    Returns:
        str: Faction ID or None if not found
    """
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor()
        # Get the most common faction ID in this guild
        cursor.execute('''
            SELECT faction_id, COUNT(*) as count 
            FROM faction_info 
            WHERE guild_id = ? 
            GROUP BY faction_id 
            ORDER BY count DESC 
            LIMIT 1
        ''', (str(guild_id),))
        row = cursor.fetchone()
        if row:
            return row['faction_id']
        return None
    except sqlite3.Error as e:
        logger.error(f"Database error retrieving guild faction ID: {e}")
        return None
    finally:
        conn.close()

# Initialize bot with intents
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    """Called when the bot is ready and connected to Discord"""
    logger.info(f'Logged in as {bot.user}')
    logger.info(f'Connected to {len(bot.guilds)} guilds')
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching, 
        name="Torn | Faction Warfare"
    ))
    
    # Ensure data files exist
    os.makedirs('data', exist_ok=True)
    if not os.path.exists('data/spies.json'):
        with open('data/spies.json', 'w') as f:
            json.dump({}, f)
        logger.info("Created empty spies.json file")
        
    # Create additional data files for faction warfare tracking
    if not os.path.exists('data/faction_attacks.json'):
        with open('data/faction_attacks.json', 'w') as f:
            json.dump({}, f)
        logger.info("Created empty faction_attacks.json file")
        
    if not os.path.exists('data/chains.json'):
        with open('data/chains.json', 'w') as f:
            json.dump({}, f)
        logger.info("Created empty chains.json file")
        
    if not os.path.exists('data/enemy_factions.json'):
        with open('data/enemy_factions.json', 'w') as f:
            json.dump({}, f)
        logger.info("Created empty enemy_factions.json file")
        
    if not os.path.exists('data/chain_config.json'):
        with open('data/chain_config.json', 'w') as f:
            json.dump({}, f)
        logger.info("Created empty chain_config.json file")
        
    if not os.path.exists('data/milestone_claims.json'):
        with open('data/milestone_claims.json', 'w') as f:
            json.dump({}, f)
        logger.info("Created empty milestone_claims.json file")
    
    # Load chain configuration and milestone claims data
    load_chain_data()
    logger.info("Chain configuration loaded")

@bot.command(name="enemy_stats")
async def enemy_stats(ctx, player_id: str = "", damage: str = "", turns: str = "", my_primary_stat: str = ""):
    """
    Get enemy stats by player ID
    
    Usage:
    !enemy_stats <player_id>
    !enemy_stats <player_id> <damage> <turns> <my_primary_stat>
    """
    if not player_id:
        await ctx.send("Please provide a player ID. Usage: `!enemy_stats <player_id>` or `!enemy_stats <player_id> <damage> <turns> <my_primary_stat>`")
        return
    
    # Check if we have spy data for this player
    spy_data = get_spy_data(player_id)
    
    if spy_data:
        # We have saved spy data
        confidence = get_stat_confidence(spy_data)
        embed = discord.Embed(
            title=f"Spy Data for Player {player_id}",
            description=format_stats_for_display(player_id, spy_data, confidence),
            color=_get_color_for_confidence(confidence)
        )
        await ctx.send(embed=embed)
    
    elif all([damage, turns, my_primary_stat]):
        try:
            # Convert string inputs to integers
            damage_val = int(damage)
            turns_val = int(turns)
            primary_val = int(my_primary_stat)
            
            # We don't have spy data but have parameters to estimate
            primary_estimate = estimate_primary_stat(damage_val, turns_val, primary_val)
            total_estimate = estimate_total_stats(primary_estimate)
            
            estimated_data = {
                "primary": primary_estimate,
                "total": total_estimate
            }
            
            embed = discord.Embed(
                title=f"Estimated Stats for Player {player_id}",
                description=format_stats_for_display(player_id, estimated_data, "low"),
                color=discord.Color.yellow()
            )
            embed.add_field(
                name="Calculation Details",
                value=f"Based on {damage_val:,} damage over {turns_val} turns with your {primary_val:,} primary stat"
            )
            await ctx.send(embed=embed)
        except ValueError:
            await ctx.send("All values must be valid numbers. Please check your input and try again.")
    
    else:
        # Not enough info
        await ctx.send(f"No spy data found for player {player_id}. To estimate stats, use: `!enemy_stats {player_id} <damage> <turns> <my_primary_stat>`")

@bot.command(name="advanced_spy")
async def advanced_spy(ctx, player_id: str = "", battle_log_url: str = ""):
    """
    Analyze a battle log to extract detailed intel on an enemy player
    
    Usage:
    !advanced_spy <player_id> [battle_log_url]
    """
    if not player_id:
        await ctx.send("Please provide a player ID. Usage: `!advanced_spy <player_id> [battle_log_url]`")
        return
    
    # Start a loading message
    loading_message = await ctx.send("🔍 Analyzing player data and battle patterns... Please wait.")
    
    try:
        # Try to get player name from Torn API
        player_name = await fetch_player_name(player_id, TORN_API_KEY) or f"Player {player_id}"
        
        # Try to find which faction this player belongs to
        faction_id, faction_name = await get_player_faction(player_id, TORN_API_KEY)
        
        # Check if we have existing spy data
        existing_spy_data = get_spy_data(player_id)
        
        # Try to get additional data from battle log if provided
        battle_analysis = None
        if battle_log_url and "torn.com" in battle_log_url:
            battle_analysis = await analyze_battle_log(battle_log_url, TORN_API_KEY)
        
        # Try to get data from TornStats
        tornstats_data = await fetch_tornstats_data(player_id, TORNSTATS_API_KEY)
        
        # Combine all data sources for the most accurate picture
        combined_data = await combine_intel_sources(
            player_id,
            existing_spy_data,
            battle_analysis,
            tornstats_data
        )
        
        # Create response embed
        embed = discord.Embed(
            title=f"Advanced Intelligence Analysis: {player_name}",
            description=f"ID: {player_id} | Analysis Confidence: {combined_data.get('confidence', 'Unknown')}",
            color=discord.Color.blue()
        )
        
        # Add battle stats section
        stats_text = ""
        if 'strength' in combined_data:
            stats_text += f"💪 Strength: {combined_data['strength']:,}\n"
        if 'speed' in combined_data:
            stats_text += f"🏃 Speed: {combined_data['speed']:,}\n"
        if 'dexterity' in combined_data:
            stats_text += f"🎯 Dexterity: {combined_data['dexterity']:,}\n"
        if 'defense' in combined_data:
            stats_text += f"🛡️ Defense: {combined_data['defense']:,}\n"
        
        if stats_text:
            embed.add_field(
                name="Battle Stats",
                value=stats_text,
                inline=True
            )
        
        # Add battle performance section if available
        if battle_analysis:
            performance_text = ""
            if 'avg_damage' in battle_analysis:
                performance_text += f"Average Damage: {battle_analysis['avg_damage']:,}\n"
            if 'critical_hits' in battle_analysis:
                performance_text += f"Critical Hit Rate: {battle_analysis['critical_hits']}%\n"
            if 'accuracy' in battle_analysis:
                performance_text += f"Accuracy: {battle_analysis['accuracy']}%\n"
            if 'stealth' in battle_analysis:
                performance_text += f"Stealth: {battle_analysis['stealth']}%\n"
                
            if performance_text:
                embed.add_field(
                    name="Battle Performance",
                    value=performance_text,
                    inline=True
                )
        
        # Add equipment analysis if available
        if battle_analysis and 'equipment' in battle_analysis:
            equipment = battle_analysis['equipment']
            equipment_text = ""
            if 'primary' in equipment:
                equipment_text += f"🔫 Weapon: {equipment['primary']}\n"
            if 'armor' in equipment:
                equipment_text += f"🛡️ Armor: {equipment['armor']}\n"
            if 'boosters' in equipment:
                equipment_text += f"💉 Boosters: {', '.join(equipment['boosters'])}\n"
                
            if equipment_text:
                embed.add_field(
                    name="Equipment Analysis",
                    value=equipment_text,
                    inline=False
                )
        
        # Add faction information if available
        if faction_id and faction_name:
            embed.add_field(
                name="Faction Information",
                value=f"[{faction_name}](https://www.torn.com/factions.php?step=profile&ID={faction_id}) (ID: {faction_id})",
                inline=False
            )
            
            # Check if this faction is being tracked
            guild_id = str(ctx.guild.id)
            is_tracked = False
            
            if guild_id in tracked_enemy_factions and faction_id in tracked_enemy_factions[guild_id]:
                is_tracked = True
                embed.add_field(
                    name="Tracking Status",
                    value="✅ This player's faction is currently being tracked",
                    inline=False
                )
            else:
                embed.add_field(
                    name="Tracking Recommendation",
                    value=f"This player's faction is not being tracked.\nUse `!enemy {faction_id} track` to start tracking.",
                    inline=False
                )
        
        # Add strategic assessment if available
        if combined_data.get('threat_level'):
            threat_color = "🟢"  # Low threat
            if combined_data['threat_level'] == "Medium":
                threat_color = "🟡"
            elif combined_data['threat_level'] == "High":
                threat_color = "🔴"
            
            embed.add_field(
                name="Strategic Assessment",
                value=f"{threat_color} Threat Level: {combined_data['threat_level']}\n"
                      f"⚔️ Engagement Recommendation: {combined_data.get('recommendation', 'Unknown')}",
                inline=False
            )
        
        # Add buttons for various actions
        class AdvancedSpyView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # Buttons active for 5 minutes
                
                # Add button to view player profile
                profile_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Profile",
                    url=f"https://www.torn.com/profiles.php?XID={player_id}"
                )
                self.add_item(profile_button)
                
                # If we know the faction, add button to view faction
                if faction_id:
                    faction_button = discord.ui.Button(
                        style=discord.ButtonStyle.link,
                        label="View Faction",
                        url=f"https://www.torn.com/factions.php?step=profile&ID={faction_id}"
                    )
                    self.add_item(faction_button)
                    
                    # Add button to track faction
                    if not is_tracked and faction_id:
                        track_button = discord.ui.Button(
                            style=discord.ButtonStyle.danger,
                            label="Track This Faction",
                            emoji="🔍",
                            custom_id=f"track_faction_{faction_id}"
                        )
                        track_button.callback = self.track_faction_callback
                        self.add_item(track_button)
                
                # Add update button
                update_button = discord.ui.Button(
                    style=discord.ButtonStyle.primary,
                    label="Update Intel",
                    emoji="🔄",
                    custom_id=f"update_intel_{player_id}"
                )
                update_button.callback = self.update_intel_callback
                self.add_item(update_button)
            
            async def track_faction_callback(self, interaction):
                faction_id_to_track = interaction.data['custom_id'].split('_')[2]
                await interaction.response.defer()
                await track_enemy_faction(ctx, faction_id_to_track)
            
            async def update_intel_callback(self, interaction):
                player_id_to_update = interaction.data['custom_id'].split('_')[2]
                await interaction.response.defer()
                await ctx.send(f"To update intel manually, use: `!add_spy {player_id_to_update} <str> <spd> <dex> <def> [note]`")
        
        # Set footer with data sources
        sources = []
        if existing_spy_data:
            sources.append("Spy Database")
        if battle_analysis:
            sources.append("Battle Analysis")
        if tornstats_data:
            sources.append("TornStats API")
        
        source_text = " | ".join(sources) if sources else "No data sources available"
        embed.set_footer(text=f"Owl Eye Advanced Intelligence System | Sources: {source_text}")
        
        # Delete loading message and send result
        await loading_message.delete()
        await ctx.send(embed=embed, view=AdvancedSpyView())
        
    except Exception as e:
        await loading_message.delete()
        logger.error(f"Error in advanced spy analysis: {e}")
        await ctx.send(f"❌ Error analyzing player data: {str(e)}")

@bot.command(name="add_spy")
async def add_spy(ctx, player_id: str = "", strength: str = "", speed: str = "", dexterity: str = "", defense: str = "", note: str = ""):
    """
    Add spy data for a player
    
    Usage:
    !add_spy <player_id> <str> <spd> <dex> <def> [note]
    """
    if not all([player_id, strength, speed, dexterity, defense]):
        await ctx.send("Please provide all required parameters. Usage: `!add_spy <player_id> <str> <spd> <dex> <def> [note]`")
        return
    
    try:
        # Convert string inputs to integers
        str_val = int(strength)
        spd_val = int(speed)
        dex_val = int(dexterity)
        def_val = int(defense)
        
        # Prepare additional metadata
        metadata = {
            'recorded_by': str(ctx.author.id),
            'recorded_by_name': ctx.author.display_name,
            'timestamp': int(time.time()),
            'source': note if note else 'Manual entry',
            'confidence': 'high'  # Manual entries are considered high confidence
        }
        
        # Add the spy data (metadata parameter cannot be used yet as it's not supported)
        spy_data = add_spy_data(player_id, str_val, spd_val, dex_val, def_val)
        
        # Try to get player name from Torn API
        player_name = await fetch_player_name(player_id, TORN_API_KEY) or f"Player {player_id}"
        
        # Try to find which faction this player belongs to
        faction_id, faction_name = await get_player_faction(player_id, TORN_API_KEY)
        
        # Confirm to the user
        embed = discord.Embed(
            title=f"Spy Data Added for {player_name}",
            description=format_stats_for_display(player_id, spy_data, "high"),
            color=discord.Color.green()
        )
        
        # Add faction information if available
        if faction_id:
            embed.add_field(
                name="Faction Information",
                value=f"[{faction_name}](https://www.torn.com/factions.php?step=profile&ID={faction_id}) (ID: {faction_id})",
                inline=False
            )
            
            # Check if this faction is being tracked
            guild_id = str(ctx.guild.id)
            is_tracked = False
            
            if guild_id in tracked_enemy_factions and faction_id in tracked_enemy_factions[guild_id]:
                is_tracked = True
                embed.add_field(
                    name="Tracking Status",
                    value="✅ This player's faction is currently being tracked",
                    inline=False
                )
            else:
                embed.add_field(
                    name="Tracking Recommendation",
                    value=f"This player's faction is not being tracked.\nUse `!enemy {faction_id} track` to start tracking.",
                    inline=False
                )
        
        # Add buttons for viewing player profile and adding to a faction's tracking
        class SpyDataView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # Buttons active for 5 minutes
                
                # Add button to view player profile
                profile_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Profile",
                    url=f"https://www.torn.com/profiles.php?XID={player_id}"
                )
                self.add_item(profile_button)
                
                # If we know the faction, add button to view faction
                if faction_id:
                    faction_button = discord.ui.Button(
                        style=discord.ButtonStyle.link,
                        label="View Faction",
                        url=f"https://www.torn.com/factions.php?step=profile&ID={faction_id}"
                    )
                    self.add_item(faction_button)
                    
                    # Add button to track faction
                    guild_id = str(ctx.guild.id)
                    is_tracked = False
                    
                    if guild_id in tracked_enemy_factions and faction_id in tracked_enemy_factions[guild_id]:
                        is_tracked = True
                    
                    if not is_tracked and faction_id:
                        track_button = discord.ui.Button(
                            style=discord.ButtonStyle.danger,
                            label="Track This Faction",
                            emoji="🔍",
                            custom_id=f"track_faction_{faction_id}"
                        )
                        track_button.callback = self.track_faction_callback
                        self.add_item(track_button)
            
            async def track_faction_callback(self, interaction):
                faction_id_to_track = interaction.data['custom_id'].split('_')[2]
                await interaction.response.defer()
                await track_enemy_faction(ctx, faction_id_to_track)
        
        # Add metadata field
        embed.add_field(
            name="Data Metadata",
            value=f"Recorded by: {ctx.author.mention}\n"
                  f"Source: {metadata['source']}\n"
                  f"Time: {format_timestamp(metadata['timestamp'])}",
            inline=False
        )
        
        embed.set_footer(text="Owl Eye Intelligence System | High Confidence Data")
        
        await ctx.send(embed=embed, view=SpyDataView())
    except ValueError:
        await ctx.send("All stat values must be valid numbers.")
        return

@bot.command(name="help_owl")
async def help_owl(ctx):
    """Show help for Owl Eye commands"""
    
    # Create an embed for the help menu
    embed = discord.Embed(
        title="Owl Eye Intelligence System - Command Help",
        description="Here are all the available commands for the Owl Eye warfare intelligence system:",
        color=discord.Color.blue()
    )
    
    # Warfare Intelligence Commands
    embed.add_field(
        name="📊 Warfare Intelligence",
        value="**!enemy <faction_id>** - View intel on an enemy faction\n"
              "**!player_enemy <player_id>** - Find a player's faction\n"
              "**!analyze_war <faction_id>** - Analyze war patterns\n"
              "**!war_track** - Set up automatic war detection\n"
              "**!auto_battle <player_id>** - Automatically analyze player data\n"
              "**!battle_analyze <battle_log_url>** - Analyze a battle log",
        inline=False
    )
    
    # Chain Tracking Commands
    embed.add_field(
        name="⛓️ Chain Tracking",
        value="**!chain** - Check faction chain status\n"
              "**!chain <faction_id>** - Check specific faction's chain\n"
              "**!claim_milestone <number>** - Claim a chain milestone\n"
              "**!set_faction <faction_id>** - Set faction for monitoring",
        inline=False
    )
    
    # Enemy Monitoring Commands
    embed.add_field(
        name="👁️ Enemy Monitoring",
        value="**!attacks** - View recent attacks\n"
              "**!attacks setup** - Set up attack monitoring\n"
              "**!attacks stop** - Stop attack monitoring\n"
              "**!hospitalized** - View hospitalized faction members\n"
              "**!hospitalized <faction_id>** - View enemy hospitalized members",
        inline=False
    )
    
    # Spy System Commands
    embed.add_field(
        name="🕵️ Spy System",
        value="**!add_spy <player_id> <str> <spd> <dex> <def> [note]** - Add spy data\n"
              "**!enemy_stats <player_id> [dmg] [turns] [my_primary_stat]** - Get enemy stats\n"
              "**!advanced_spy <player_id> [battle_log_url]** - Advanced battle analysis",
        inline=False
    )
    
    # Footer
    embed.set_footer(text="Owl Eye Intelligence | Type !help for this menu")
    
    # Send the embed
    await ctx.send(embed=embed)

# No need for a separate help command since discord.py already has one
# We'll keep the help_owl command for detailed help

# Chain data storage
faction_chain_channels = {}
chain_milestone_claims = {}
# Milestone definitions
CHAIN_MILESTONES = [10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000]

# New warfare tracking commands
@bot.command(name="chain")
async def chain_status(ctx, faction_id: str = ""):
    """
    Check the current chain status for your faction
    
    Usage:
    !chain - Show chain status for your faction
    !chain <faction_id> - Check a specific faction's chain
    """
    # Handle setup command (legacy support)
    if faction_id == "setup":
        embed = discord.Embed(
            title="Chain Monitor Setup",
            description="Owl Eye now automatically integrates with Brother Owl!\n"
                        "Your faction information will be automatically retrieved.",
            color=discord.Color.blue()
        )
        
        await ctx.send(embed=embed)
        return
    
    # Handle viewing chain status
    try:
        # If no faction ID was provided, try to determine it automatically
        if not faction_id:
            # First check if this channel has a configured faction
            guild_id = str(ctx.guild.id)
            channel_id = str(ctx.channel.id)
            
            if guild_id in faction_chain_channels and channel_id in faction_chain_channels[guild_id]:
                # Use the configured faction for this channel
                faction_id = faction_chain_channels[guild_id][channel_id]
            else:
                # Try to get the user's faction ID from the database
                user_faction_id = get_user_faction_id(ctx.author.id)
                if user_faction_id:
                    faction_id = user_faction_id
                else:
                    # Try to get the guild's primary faction
                    guild_faction_id = get_guild_faction_id(ctx.guild.id)
                    if guild_faction_id:
                        faction_id = guild_faction_id
                    else:
                        await ctx.send("Could not determine your faction automatically. Please set your faction with the Brother Owl bot `/factionregister` command, or specify a faction ID: `!chain <faction_id>`")
                        return
                
                # Auto-configure this channel for future use
                if guild_id not in faction_chain_channels:
                    faction_chain_channels[guild_id] = {}
                faction_chain_channels[guild_id][channel_id] = faction_id
                save_chain_config()
                
                await ctx.send(f"✅ This channel has been automatically configured to track Faction {faction_id}")
        
        # Get API key - try user's key first, then fall back to environment variable
        api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
        
        if not api_key:
            await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
            return
        
        # Inform the user we're fetching data
        loading_message = await ctx.send("📊 Fetching chain data... Please wait.")
        
        # Fetch real-time chain data from Torn API
        chain_data = await fetch_chain_data(faction_id, api_key)
        
        if not chain_data:
            await loading_message.delete()
            await ctx.send(f"❌ Could not fetch chain data for faction {faction_id}. Please check your API key and faction ID.")
            return
            
        # Extract chain information
        chain_count = chain_data.get('count', 0)
        time_remaining = format_time_remaining(chain_data.get('timeout', 0))
        current_multiplier = chain_data.get('modifier', 1)
        respect_earned = chain_data.get('respect', 0)
        
        # Fetch recent attacks
        recent_attacks = await fetch_faction_attacks(faction_id, api_key, limit=5)
        
        # Format the recent hits
        recent_hits = []
        if recent_attacks:
            attack_count = chain_count
            for attack in recent_attacks:
                attacker_name = attack.get('attacker_name', 'Unknown')
                defender_name = attack.get('defender_name', 'Unknown')
                respect = attack.get('respect_gain', 0)
                timestamp = format_timestamp(attack.get('timestamp', 0))
                
                recent_hits.append({
                    "attacker": attacker_name,
                    "defender": defender_name,
                    "respect": respect,
                    "timestamp": timestamp,
                    "chain_count": attack_count
                })
                attack_count -= 1
        
        # Create main embed with appropriate color based on time remaining
        timeout_seconds = chain_data.get('timeout', 0)
        
        # Set color based on timeout
        if timeout_seconds < 300:  # Less than 5 minutes
            embed_color = discord.Color.red()
            warning_text = "⚠️ **CHAIN TIMEOUT IMMINENT!** ⚠️\n"
        elif timeout_seconds < 900:  # Less than 15 minutes
            embed_color = discord.Color.orange()
            warning_text = "⚠️ **Chain timeout approaching!** ⚠️\n"
        else:
            embed_color = discord.Color.blue()
            warning_text = ""
        
        embed = discord.Embed(
            title=f"Chain Status for Faction {faction_id}",
            description=f"{warning_text}**Current Chain: {chain_count}**\n⏱️ Time remaining: {time_remaining}\n📈 Multiplier: {current_multiplier}x\n🏆 Respect earned: {respect_earned:.2f}",
            color=embed_color
        )
        
        # Add recent hits
        hits_text = ""
        for hit in recent_hits:
            hits_text += f"`{hit['chain_count']}` | **{hit['attacker']}** hit *{hit['defender']}* for {hit['respect']} respect at {hit['timestamp']}\n"
        
        embed.add_field(
            name="Recent Chain Hits",
            value=hits_text if hits_text else "No recent hits",
            inline=False
        )
        
        # Add upcoming milestones
        next_milestones = [m for m in CHAIN_MILESTONES if m > chain_count][:3]
        if next_milestones:
            milestones_text = "\n".join([f"• {m} hits" for m in next_milestones])
            embed.add_field(
                name="Upcoming Milestones",
                value=milestones_text,
                inline=True
            )
        
        # Add claimed milestones if any
        claimed_milestones_text = ""
        if faction_id in chain_milestone_claims:
            for milestone, claimer in chain_milestone_claims[faction_id].items():
                claimed_milestones_text += f"• {milestone} - claimed by {claimer}\n"
        
        if claimed_milestones_text:
            embed.add_field(
                name="Claimed Milestones",
                value=claimed_milestones_text,
                inline=True
            )
            
        embed.set_footer(text="Owl Eye Intelligence System | Live Chain Monitor")
        
        # Create buttons for claiming the next milestone
        # Find the next milestone to claim
        next_milestone = None
        for milestone in CHAIN_MILESTONES:
            if milestone > chain_count:
                next_milestone = milestone
                break
        
        # Create button view for milestone claiming
        class ChainButtonView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=600)  # Buttons active for 10 minutes
                
                # Add refresh button
                refresh_button = discord.ui.Button(
                    style=discord.ButtonStyle.secondary,
                    label="Refresh",
                    emoji="🔄",
                    custom_id="refresh_chain"
                )
                refresh_button.callback = self.refresh_callback
                self.add_item(refresh_button)
                
                # Add claim button if there's a next milestone
                if next_milestone and next_milestone <= chain_count + 10:  # Only show if within 10 hits
                    claim_button = discord.ui.Button(
                        style=discord.ButtonStyle.primary,
                        label=f"Claim {next_milestone} Hit Milestone",
                        emoji="🎯",
                        custom_id=f"claim_{next_milestone}"
                    )
                    claim_button.callback = self.claim_callback
                    self.add_item(claim_button)
            
            async def refresh_callback(self, interaction):
                # Simply run the chain command again
                await interaction.response.defer()
                await chain_status(ctx)
            
            async def claim_callback(self, interaction):
                # Extract milestone from button custom_id
                milestone = interaction.data['custom_id'].split('_')[1]
                
                # Use the claim command
                await interaction.response.defer()
                await claim_milestone(ctx, milestone)
        
        # Delete the loading message and send the result with buttons
        await loading_message.delete()
        await ctx.send(embed=embed, view=ChainButtonView())
        
    except Exception as e:
        logger.error(f"Error fetching chain data: {e}")
        await ctx.send(f"❌ Error fetching chain data: {str(e)}")

@bot.command(name="setfaction")
async def set_faction(ctx, faction_id: str = ""):
    """Set the faction ID for chain monitoring in the current channel"""
    if not faction_id:
        await ctx.send("Please provide a faction ID: `!setfaction <faction_id>`")
        return
    
    try:
        # Convert to int to validate the ID
        int(faction_id)
        
        # Store the faction ID for this channel
        guild_id = str(ctx.guild.id)
        channel_id = str(ctx.channel.id)
        
        if guild_id not in faction_chain_channels:
            faction_chain_channels[guild_id] = {}
        
        faction_chain_channels[guild_id][channel_id] = faction_id
        
        # Save to data file
        save_chain_config()
        
        # Confirmation message
        embed = discord.Embed(
            title="Chain Monitoring Configured",
            description=f"This channel will now track chain activity for faction {faction_id}.\n"
                       f"Use `!chain` in this channel to see the current status.",
            color=discord.Color.green()
        )
        
        await ctx.send(embed=embed)
        
    except ValueError:
        await ctx.send("Please enter a valid faction ID (numbers only)")
    except Exception as e:
        logger.error(f"Error setting faction: {e}")
        await ctx.send(f"❌ Error setting faction: {str(e)}")

@bot.command(name="claim")
async def claim_milestone(ctx, milestone: str = ""):
    """Claim a chain milestone hit"""
    if not milestone:
        await ctx.send("Please specify which milestone to claim: `!claim <milestone>`")
        return
    
    try:
        # Convert to int to validate the milestone
        milestone_number = int(milestone)
        
        # Check if it's a valid milestone number
        if milestone_number not in CHAIN_MILESTONES:
            await ctx.send(f"Invalid milestone. Valid milestones are: {', '.join(map(str, CHAIN_MILESTONES))}")
            return
        
        # Get the faction ID - try multiple methods
        faction_id = None
        
        # First check if channel is configured
        guild_id = str(ctx.guild.id)
        channel_id = str(ctx.channel.id)
        
        if guild_id in faction_chain_channels and channel_id in faction_chain_channels[guild_id]:
            faction_id = faction_chain_channels[guild_id][channel_id]
        else:
            # Try to get from database
            user_faction_id = get_user_faction_id(ctx.author.id)
            if user_faction_id:
                faction_id = user_faction_id
            else:
                # Try to get the guild's primary faction
                guild_faction_id = get_guild_faction_id(ctx.guild.id)
                if guild_faction_id:
                    faction_id = guild_faction_id
                else:
                    await ctx.send("Could not determine your faction. Please use the Brother Owl bot `/factionregister` command first.")
                    return
            
            # Auto-configure this channel for future use
            if guild_id not in faction_chain_channels:
                faction_chain_channels[guild_id] = {}
            faction_chain_channels[guild_id][channel_id] = faction_id
            save_chain_config()
        
        # Initialize milestone claims for this faction if needed
        if faction_id not in chain_milestone_claims:
            chain_milestone_claims[faction_id] = {}
        
        # Check if this milestone is already claimed
        if str(milestone_number) in chain_milestone_claims[faction_id]:
            claimer = chain_milestone_claims[faction_id][str(milestone_number)]
            await ctx.send(f"Milestone {milestone_number} was already claimed by {claimer}")
            return
        
        # Get current chain status to verify milestone is valid
        api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
        
        if not api_key:
            await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
            return
            
        # In the real implementation, we would verify with the API that the chain is at or past this milestone
        # For now, we'll just claim it
            
        # Record the claim
        claimer_name = ctx.author.display_name
        chain_milestone_claims[faction_id][str(milestone_number)] = claimer_name
        
        # Save to data file
        save_milestone_claims()
        
        # Confirmation message with user avatar
        embed = discord.Embed(
            title="Chain Milestone Claimed!",
            description=f"🎯 **{claimer_name}** has claimed the **{milestone_number} hit** milestone for faction {faction_id}!",
            color=discord.Color.gold()
        )
        
        # Add user avatar if available
        if ctx.author.avatar:
            embed.set_thumbnail(url=ctx.author.avatar.url)
        
        # Add timestamp
        embed.timestamp = datetime.datetime.now()
        
        # Add footer
        embed.set_footer(text="Owl Eye Intelligence System")
        
        await ctx.send(embed=embed)
        
    except ValueError:
        await ctx.send("Please enter a valid milestone number")
    except Exception as e:
        logger.error(f"Error claiming milestone: {e}")
        await ctx.send(f"❌ Error claiming milestone: {str(e)}")

def save_chain_config():
    """Save chain configuration to data file"""
    try:
        with open('data/chain_config.json', 'w') as f:
            json.dump(faction_chain_channels, f)
    except Exception as e:
        logger.error(f"Error saving chain config: {e}")

def save_milestone_claims():
    """Save milestone claims to data file"""
    try:
        with open('data/milestone_claims.json', 'w') as f:
            json.dump(chain_milestone_claims, f)
    except Exception as e:
        logger.error(f"Error saving milestone claims: {e}")

def load_chain_data():
    """Load chain data from files"""
    global faction_chain_channels, chain_milestone_claims
    
    try:
        if os.path.exists('data/chain_config.json'):
            with open('data/chain_config.json', 'r') as f:
                faction_chain_channels = json.load(f)
        
        if os.path.exists('data/milestone_claims.json'):
            with open('data/milestone_claims.json', 'r') as f:
                chain_milestone_claims = json.load(f)
    except Exception as e:
        logger.error(f"Error loading chain data: {e}")

async def fetch_chain_data(faction_id, api_key):
    """
    Fetch chain data from Torn API
    
    Args:
        faction_id (str): Faction ID
        api_key (str): Torn API key
        
    Returns:
        dict: Chain data or None if error
    """
    url = f"https://api.torn.com/faction/{faction_id}?selections=chain&key={api_key}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if 'error' in data:
                        logger.error(f"Torn API error: {data['error']}")
                        return None
                    return data.get('chain', {})
                else:
                    logger.error(f"Failed to fetch chain data: HTTP {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Error fetching chain data: {e}")
        return None

async def fetch_faction_attacks(faction_id, api_key, limit=5):
    """
    Fetch recent faction attacks from Torn API
    
    Args:
        faction_id (str): Faction ID
        api_key (str): Torn API key
        limit (int): Number of attacks to fetch
        
    Returns:
        list: Recent attacks or empty list if error
    """
    url = f"https://api.torn.com/faction/{faction_id}?selections=attacks&key={api_key}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if 'error' in data:
                        logger.error(f"Torn API error: {data['error']}")
                        return []
                    
                    # Extract and sort attacks
                    attacks = data.get('attacks', {})
                    attack_list = []
                    
                    for attack_id, attack in attacks.items():
                        if attack.get('chain', 0) > 0:  # Only include chain attacks
                            attack_list.append(attack)
                    
                    # Sort by timestamp (newest first)
                    attack_list.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
                    
                    # Return only the requested number of attacks
                    return attack_list[:limit]
                else:
                    logger.error(f"Failed to fetch attacks: HTTP {response.status}")
                    return []
    except Exception as e:
        logger.error(f"Error fetching attacks: {e}")
        return []

def format_time_remaining(seconds):
    """
    Format seconds into human-readable time
    
    Args:
        seconds (int): Seconds remaining
        
    Returns:
        str: Formatted time string (e.g., "1h 23m 45s")
    """
    if seconds <= 0:
        return "0s"
    
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    parts = []
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if seconds > 0 or not parts:
        parts.append(f"{seconds}s")
    
    return " ".join(parts)

def format_timestamp(unix_timestamp):
    """
    Format Unix timestamp into human-readable time
    
    Args:
        unix_timestamp (int): Unix timestamp
        
    Returns:
        str: Formatted time string (e.g., "12:45:32")
    """
    try:
        dt = datetime.datetime.fromtimestamp(unix_timestamp)
        return dt.strftime("%H:%M:%S")
    except:
        return "unknown"

# Store attack notification channel settings
attack_notification_channels = {}

@bot.command(name="attacks")
async def attacks(ctx, option: str = ""):
    """
    Show recent attacks or set up attack monitoring
    
    Usage:
    !attacks - Show recent attacks
    !attacks setup - Set up attack monitoring in this channel
    !attacks stop - Stop attack monitoring in this channel
    """
    # Handle setup and stop commands
    if option.lower() == "setup":
        await setup_attack_monitoring(ctx)
        return
    elif option.lower() == "stop":
        await stop_attack_monitoring(ctx)
        return
    
    # Default behavior: show recent attacks
    limit_val = 10
    if option and option.isdigit():
        limit_val = int(option)
        if limit_val < 1 or limit_val > 50:
            await ctx.send("Limit must be between 1 and 50")
            return
    
    try:
        # Get faction ID - try multiple methods
        faction_id = None
        
        # First check if user has faction registered
        user_faction_id = get_user_faction_id(ctx.author.id)
        if user_faction_id:
            faction_id = user_faction_id
        else:
            # Try to get the guild's primary faction
            guild_faction_id = get_guild_faction_id(ctx.guild.id)
            if guild_faction_id:
                faction_id = guild_faction_id
            else:
                await ctx.send("Could not determine your faction. Please use the Brother Owl bot `/factionregister` command first.")
                return
        
        # Get API key - try user's key first, then fall back to environment variable
        api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
        
        if not api_key:
            await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
            return
        
        # Inform the user we're fetching data
        loading_message = await ctx.send("🔍 Fetching recent attacks... Please wait.")
        
        # Fetch attack data
        attacks_data = await fetch_faction_attacks(faction_id, api_key, limit=limit_val)
        
        if not attacks_data:
            await loading_message.delete()
            await ctx.send("No recent attacks found.")
            return
        
        embed = discord.Embed(
            title=f"Recent Faction Attacks",
            description=f"Showing the last {len(attacks_data)} attacks for faction {faction_id}",
            color=discord.Color.blue()
        )
        
        # Add attacks to embed
        for i, attack in enumerate(attacks_data):
            # Get attack details
            attacker_name = attack.get('attacker_name', 'Unknown')
            attacker_faction = attack.get('attacker_faction', 'Unknown')
            defender_name = attack.get('defender_name', 'Unknown')
            defender_faction = attack.get('defender_faction', 'Unknown')
            result = attack.get('result', 'Unknown')
            respect = attack.get('respect_gain', 0)
            timestamp = format_timestamp(attack.get('timestamp', 0))
            
            # Format attack result
            if result == "Attacked":
                result_text = "🔴 Lost"
            elif result == "Mugged":
                result_text = "🟠 Mugged"
            elif result == "Hospitalized":
                result_text = "🔴 Hospitalized"
            elif result == "Stalemate":
                result_text = "🟡 Stalemate"
            elif result == "Escape":
                result_text = "🟡 Escape"
            elif result == "Assist":
                result_text = "🟢 Assist"
            elif result == "Special":
                result_text = "🟣 Special"
            elif result == "Lost":
                result_text = "🔴 Lost"
            else:
                result_text = "🟢 Won"
            
            # Create field for this attack
            attack_text = f"**{attacker_name}** [{attacker_faction}] vs **{defender_name}** [{defender_faction}]\n"
            attack_text += f"Result: {result_text} | Respect: {respect:.2f} | Time: {timestamp}"
            
            embed.add_field(
                name=f"Attack #{i+1}",
                value=attack_text,
                inline=False
            )
        
        embed.set_footer(text="Owl Eye Intelligence System")
        
        # Delete the loading message and send the result
        await loading_message.delete()
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"Error fetching attack data: {e}")
        await ctx.send(f"❌ Error fetching attack data: {str(e)}")

async def setup_attack_monitoring(ctx):
    """Set up attack monitoring in the current channel"""
    # Get faction ID - try multiple methods
    faction_id = None
    
    # First check if user has faction registered
    user_faction_id = get_user_faction_id(ctx.author.id)
    if user_faction_id:
        faction_id = user_faction_id
    else:
        # Try to get the guild's primary faction
        guild_faction_id = get_guild_faction_id(ctx.guild.id)
        if guild_faction_id:
            faction_id = guild_faction_id
        else:
            await ctx.send("Could not determine your faction. Please use the Brother Owl bot `/factionregister` command first.")
            return
    
    # Store channel configuration
    guild_id = str(ctx.guild.id)
    channel_id = str(ctx.channel.id)
    
    if guild_id not in attack_notification_channels:
        attack_notification_channels[guild_id] = {}
    
    attack_notification_channels[guild_id][channel_id] = faction_id
    save_attack_config()
    
    # Confirm setup
    embed = discord.Embed(
        title="Attack Monitoring Configured",
        description=f"This channel will now receive real-time notifications when faction {faction_id} members are attacked.",
        color=discord.Color.green()
    )
    
    embed.add_field(
        name="Notification Features",
        value="• Alerts when faction members are attacked\n"
              "• Details about attackers including battle stats\n"
              "• Links to attacker profiles\n"
              "• Special alerts for hospitalizations",
        inline=False
    )
    
    embed.add_field(
        name="Commands",
        value="• `!attacks` - View recent attacks\n"
              "• `!attacks stop` - Stop monitoring in this channel",
        inline=False
    )
    
    embed.set_footer(text="Owl Eye Intelligence System")
    
    await ctx.send(embed=embed)
    
    # Start background task to monitor attacks
    bot.loop.create_task(monitor_faction_attacks(ctx.guild.id, ctx.channel.id, faction_id))

async def stop_attack_monitoring(ctx):
    """Stop attack monitoring in the current channel"""
    guild_id = str(ctx.guild.id)
    channel_id = str(ctx.channel.id)
    
    if guild_id in attack_notification_channels and channel_id in attack_notification_channels[guild_id]:
        del attack_notification_channels[guild_id][channel_id]
        save_attack_config()
        await ctx.send("✅ Attack monitoring has been disabled for this channel.")
    else:
        await ctx.send("❌ Attack monitoring is not currently active in this channel.")

def save_attack_config():
    """Save attack notification configuration to data file"""
    try:
        with open('data/attack_config.json', 'w') as f:
            json.dump(attack_notification_channels, f)
    except Exception as e:
        logger.error(f"Error saving attack config: {e}")

def load_attack_config():
    """Load attack notification configuration from data file"""
    global attack_notification_channels
    
    try:
        if os.path.exists('data/attack_config.json'):
            with open('data/attack_config.json', 'r') as f:
                attack_notification_channels = json.load(f)
    except Exception as e:
        logger.error(f"Error loading attack config: {e}")

async def monitor_faction_attacks(guild_id, channel_id, faction_id):
    """
    Background task to monitor faction attacks
    
    Args:
        guild_id (int): Discord guild ID
        channel_id (int): Discord channel ID
        faction_id (str): Faction ID to monitor
    """
    guild_id_str = str(guild_id)
    channel_id_str = str(channel_id)
    
    # Get a valid API key
    api_key = TORN_API_KEY
    if not api_key:
        logger.error(f"No API key available for attack monitoring")
        return
    
    # Keep track of the last known attack timestamp
    last_attack_time = int(time.time())
    
    # Loop to check for new attacks
    while guild_id_str in attack_notification_channels and channel_id_str in attack_notification_channels[guild_id_str]:
        try:
            # Fetch recent attacks
            recent_attacks = await fetch_faction_attacks(faction_id, api_key, limit=10)
            
            if recent_attacks:
                new_attacks = []
                current_time = int(time.time())
                
                # Check for new attacks against faction members
                for attack in recent_attacks:
                    attack_time = attack.get('timestamp', 0)
                    # Only consider attacks that are new and against faction members
                    if attack_time > last_attack_time and attack.get('defender_faction') == faction_id:
                        new_attacks.append(attack)
                
                # Update last attack time
                if recent_attacks:
                    newest_time = max(attack.get('timestamp', 0) for attack in recent_attacks)
                    if newest_time > last_attack_time:
                        last_attack_time = newest_time
                
                # Send notifications for new attacks
                if new_attacks:
                    # Get the channel
                    guild = bot.get_guild(int(guild_id_str))
                    if guild:
                        channel = guild.get_channel(int(channel_id_str))
                        if channel:
                            for attack in new_attacks:
                                await send_attack_notification(channel, attack, faction_id)
            
            # Wait before checking again (30 seconds)
            await asyncio.sleep(30)
            
        except Exception as e:
            logger.error(f"Error in attack monitoring: {e}")
            await asyncio.sleep(60)  # Wait longer if there was an error

async def send_attack_notification(channel, attack, faction_id):
    """
    Send an attack notification to a channel
    
    Args:
        channel (discord.TextChannel): Discord channel
        attack (dict): Attack data
        faction_id (str): Faction ID being monitored
    """
    try:
        # Get attack details
        attacker_id = attack.get('attacker_id', 0)
        attacker_name = attack.get('attacker_name', 'Unknown')
        attacker_faction = attack.get('attacker_faction', 'Unknown')
        defender_id = attack.get('defender_id', 0)
        defender_name = attack.get('defender_name', 'Unknown')
        defender_faction = attack.get('defender_faction', 'Unknown')
        result = attack.get('result', 'Unknown')
        respect = attack.get('respect_gain', 0)
        timestamp = format_timestamp(attack.get('timestamp', 0))
        
        # Set color and title based on attack result
        if result == "Hospitalized":
            color = discord.Color.red()
            title = f"⚠️ MEMBER HOSPITALIZED! ⚠️"
        elif result == "Mugged":
            color = discord.Color.orange()
            title = f"👊 Member Mugged!"
        elif result == "Attacked":
            color = discord.Color.gold()
            title = f"🔔 Member Attacked!"
        else:
            color = discord.Color.blue()
            title = f"Member Attack Result: {result}"
        
        # Create embed for the notification
        embed = discord.Embed(
            title=title,
            description=f"**{defender_name}** was attacked by **{attacker_name}**",
            color=color,
            timestamp=datetime.datetime.now()
        )
        
        # Add attack information
        embed.add_field(
            name="Attack Result",
            value=f"Result: **{result}**\nRespect: {respect:.2f}\nTime: {timestamp}",
            inline=False
        )
        
        # Add attacker information
        embed.add_field(
            name="Attacker",
            value=f"**{attacker_name}** [Faction: {attacker_faction}]\n[View Profile](https://www.torn.com/profiles.php?XID={attacker_id})",
            inline=True
        )
        
        # Add defender information
        embed.add_field(
            name="Defender",
            value=f"**{defender_name}** [Faction: {defender_faction}]\n[View Profile](https://www.torn.com/profiles.php?XID={defender_id})",
            inline=True
        )
        
        # Try to get attacker stats
        try:
            spy_data = get_spy_data(attacker_id)
            if spy_data:
                # Format stats if available
                stats_text = ""
                if 'strength' in spy_data:
                    stats_text += f"💪 STR: {spy_data['strength']:,}\n"
                if 'speed' in spy_data:
                    stats_text += f"🏃 SPD: {spy_data['speed']:,}\n"
                if 'dexterity' in spy_data:
                    stats_text += f"🎯 DEX: {spy_data['dexterity']:,}\n"
                if 'defense' in spy_data:
                    stats_text += f"🛡️ DEF: {spy_data['defense']:,}\n"
                
                if stats_text:
                    embed.add_field(
                        name="Attacker Stats",
                        value=stats_text,
                        inline=False
                    )
        except Exception as e:
            logger.error(f"Error getting spy data: {e}")
        
        embed.set_footer(text="Owl Eye Intelligence System")
        
        # Send the notification
        await channel.send(embed=embed)
        
    except Exception as e:
        logger.error(f"Error sending attack notification: {e}")

# Store enemy faction tracking data
tracked_enemy_factions = {}

@bot.command(name="enemy")
async def enemy_faction(ctx, id_input: str = "", option: str = ""):
    """
    Track an enemy faction's activity (works with faction ID or player ID)
    
    Usage:
    !enemy <faction_id/player_id> - View intel on an enemy faction (accepts faction ID or player ID)
    !enemy <faction_id/player_id> track - Start tracking an enemy faction
    !enemy <faction_id/player_id> top - Show top hitters and most active members
    !enemy list - List tracked enemy factions
    """
    # Handle listing tracked factions
    if id_input.lower() == "list":
        await list_tracked_enemies(ctx)
        return
        
    # Check for missing input
    if not id_input:
        await ctx.send("Please specify a faction ID or player ID: `!enemy <faction_id/player_id>`")
        return
        
    # Get API key - try user's key first, then fall back to environment variable
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    if not api_key:
        await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
        return
    
    # Show loading message
    loading_message = await ctx.send(f"🔍 Looking up ID {id_input}...")
    
    try:
        # Initialize variables
        target_faction_id = id_input  # Default to input if we can't determine otherwise
        player_name = None
        faction_data = None
        
        # If input is numeric, try to determine if it's a player ID or faction ID
        if id_input.isdigit():
            # Try to get player's faction first
            player_faction_id, player_faction_name = await get_player_faction(id_input, api_key)
            player_name = await fetch_player_name(id_input, api_key)
            
            if player_faction_id:
                # It's a player ID and we found their faction
                target_faction_id = player_faction_id
                await loading_message.edit(content=f"Found faction **{player_faction_name}** (ID: {player_faction_id}) for player **{player_name}**")
                
                # Get faction data for the player's faction
                faction_data = await fetch_faction_info(target_faction_id, api_key)
                
                # Small delay for user to read the message
                await asyncio.sleep(1)
            else:
                # If we couldn't find a faction for this player, check if it's a faction ID
                faction_data = await fetch_faction_info(id_input, api_key)
                if faction_data and faction_data.get('name'):
                    await loading_message.edit(content=f"Using {id_input} as a faction ID: **{faction_data.get('name')}**")
                    # Small delay for user to read the message
                    await asyncio.sleep(1)
                else:
                    # Neither a valid player with faction nor a valid faction
                    await loading_message.delete()
                    await ctx.send(f"❌ Could not find a faction for player {id_input} or a faction with ID {id_input}")
                    return
        else:
            # Non-numeric input, try as faction ID directly
            faction_data = await fetch_faction_info(id_input, api_key)
            if not faction_data:
                await loading_message.delete()
                await ctx.send(f"❌ Could not find faction with ID {id_input}")
                return
        
        # Process based on the option provided
        if option.lower() == "track":
            await loading_message.delete()
            await track_enemy_faction(ctx, target_faction_id)
            return
        
        elif option.lower() == "top":
            await loading_message.delete()
            await analyze_top_hitters(ctx, target_faction_id)
            return
            
        else:
            # Default action: show faction info
            # Make sure we have faction data
            if not faction_data:
                faction_data = await fetch_faction_info(target_faction_id, api_key)
                if not faction_data:
                    await loading_message.delete()
                    await ctx.send(f"❌ Could not fetch data for faction {target_faction_id}")
                    return
                    
            # Get faction name
            faction_name = faction_data.get('name', f"Faction {target_faction_id}")
            
            # Create embed with faction info
            embed = discord.Embed(
                title=f"Enemy Faction: {faction_name}",
                description=f"Intelligence report on faction ID: {target_faction_id}" + 
                           (f"\nPlayer: **{player_name}** (ID: {id_input})" if player_name and id_input != target_faction_id else ""),
                color=discord.Color.red()
            )
            
            # Add basic info to embed
            members_count = len(faction_data.get('members', {}))
            embed.add_field(
                name="Basic Info",
                value=f"**Members:** {members_count}\n"
                     f"**Respect:** {faction_data.get('respect', 0):,}\n"
                     f"**Age:** {faction_data.get('age', 0)} days",
                inline=True
            )
            
            # Try to get faction leader
            leader_id = None
            leader_name = "Unknown"
            
            for member_id, member_data in faction_data.get('members', {}).items():
                if member_data.get('position') == 'Leader':
                    leader_id = member_id
                    leader_name = member_data.get('name', f"Player {member_id}")
                    break
            
            embed.add_field(
                name="Leadership",
                value=f"**Leader:** {leader_name}" + (f" (ID: {leader_id})" if leader_id else ""),
                inline=True
            )
            
            # Count active members
            active_count = 0
            for member_data in faction_data.get('members', {}).values():
                if member_data.get('last_action', {}).get('status', '') == 'Online':
                    active_count += 1
            
            embed.add_field(
                name="Activity",
                value=f"**Active Members:** {active_count}/{members_count}",
                inline=False
            )
            
            # Add tracking status
            guild_id = str(ctx.guild.id)
            is_tracked = False
            if guild_id in tracked_enemy_factions and target_faction_id in tracked_enemy_factions[guild_id]:
                is_tracked = True
                
            embed.add_field(
                name="Tracking Status",
                value="✅ Currently tracking this faction" if is_tracked else "❌ Not currently tracking this faction",
                inline=False
            )
            
            # Add faction ID to footer
            embed.set_footer(text=f"Faction ID: {target_faction_id} | Owl Eye Intelligence System")
            
            # Create button view
            class EnemyFactionView(discord.ui.View):
                def __init__(self):
                    super().__init__(timeout=300)  # Buttons active for 5 minutes
                    
                    # Add button to view faction profile on Torn
                    faction_button = discord.ui.Button(
                        style=discord.ButtonStyle.link,
                        label="View Faction",
                        url=f"https://www.torn.com/factions.php?step=profile&ID={target_faction_id}"
                    )
                    self.add_item(faction_button)
                    
                    # If we came from a player ID, add player profile button
                    if player_name and id_input != target_faction_id:
                        player_button = discord.ui.Button(
                            style=discord.ButtonStyle.link,
                            label="View Player",
                            url=f"https://www.torn.com/profiles.php?XID={id_input}"
                        )
                        self.add_item(player_button)
                    
                    # Add track/untrack button
                    if is_tracked:
                        track_button = discord.ui.Button(
                            style=discord.ButtonStyle.secondary,
                            label="Untrack Faction",
                            emoji="🚫",
                            custom_id=f"untrack_{target_faction_id}"
                        )
                        track_button.callback = self.untrack_callback
                    else:
                        track_button = discord.ui.Button(
                            style=discord.ButtonStyle.danger,
                            label="Track Faction",
                            emoji="🔍",
                            custom_id=f"track_{target_faction_id}"
                        )
                        track_button.callback = self.track_callback
                    self.add_item(track_button)
                    
                    # Add analyze button
                    analyze_button = discord.ui.Button(
                        style=discord.ButtonStyle.primary,
                        label="Top Hitters",
                        emoji="📊",
                        custom_id=f"analyze_{target_faction_id}"
                    )
                    analyze_button.callback = self.analyze_callback
                    self.add_item(analyze_button)
                    
                    # Add refresh button
                    refresh_button = discord.ui.Button(
                        style=discord.ButtonStyle.success,
                        label="Refresh",
                        emoji="🔄",
                        custom_id=f"refresh_{id_input}"
                    )
                    refresh_button.callback = self.refresh_callback
                    self.add_item(refresh_button)
                
                async def track_callback(self, interaction):
                    await interaction.response.defer()
                    await track_enemy_faction(ctx, target_faction_id)
                
                async def untrack_callback(self, interaction):
                    await interaction.response.defer()
                    await untrack_enemy_faction(ctx, target_faction_id)
                
                async def analyze_callback(self, interaction):
                    await interaction.response.defer()
                    await analyze_top_hitters(ctx, target_faction_id)
                
                async def refresh_callback(self, interaction):
                    await interaction.response.defer()
                    await enemy_faction(ctx, id_input, option)
            
            # Clean up loading message and send the embed
            await loading_message.delete()
            await ctx.send(embed=embed, view=EnemyFactionView())
            
    except Exception as e:
        # Handle errors gracefully
        logger.error(f"Error in enemy faction command: {e}")
        try:
            await loading_message.delete()
        except:
            pass
        await ctx.send(f"❌ Error processing faction information: {str(e)}")
        
# Function to handle adding enemy faction from player ID
@bot.command(name="player_enemy")
async def player_enemy(ctx, player_id: str = ""):
    """
    Track an enemy faction using a player ID
    
    Usage:
    !player_enemy <player_id> - Find and view info on a player's faction
    """
    if not player_id:
        await ctx.send("Please provide a player ID: `!player_enemy <player_id>`")
        return
        
    # Get API key
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    if not api_key:
        await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
        return
        
    # Show loading message
    loading_message = await ctx.send(f"🔍 Looking up player {player_id}...")
    
    try:
        # Get player's faction
        player_faction_id, player_faction_name = await get_player_faction(player_id, api_key)
        player_name = await fetch_player_name(player_id, api_key)
        
        if not player_faction_id:
            await loading_message.delete()
            await ctx.send(f"❌ Could not find faction for player {player_id}.")
            return
            
        # Update loading message
        await loading_message.edit(content=f"Found faction **{player_faction_name}** (ID: {player_faction_id}) for player **{player_name}**")
        
        # Get faction data
        faction_data = await fetch_faction_info(player_faction_id, api_key)
        if not faction_data:
            await loading_message.delete()
            await ctx.send(f"❌ Could not fetch faction data for {player_faction_name} (ID: {player_faction_id}).")
            return
            
        # Create embed with faction info
        embed = discord.Embed(
            title=f"Enemy Faction: {player_faction_name}",
            description=f"Intelligence report for player **{player_name}** (ID: {player_id})\nFaction ID: {player_faction_id}",
            color=discord.Color.red()
        )
        
        # Add basic info to embed
        members_count = len(faction_data.get('members', {}))
        embed.add_field(
            name="Basic Info",
            value=f"**Members:** {members_count}\n"
                 f"**Respect:** {faction_data.get('respect', 0):,}\n"
                 f"**Age:** {faction_data.get('age', 0)} days",
            inline=True
        )
        
        # Try to get faction leader
        leader_id = None
        leader_name = "Unknown"
        
        for member_id, member_data in faction_data.get('members', {}).items():
            if member_data.get('position') == 'Leader':
                leader_id = member_id
                leader_name = member_data.get('name', f"Player {member_id}")
                break
        
        embed.add_field(
            name="Leadership",
            value=f"**Leader:** {leader_name}" + (f" (ID: {leader_id})" if leader_id else ""),
            inline=True
        )
        
        # Count active members
        active_count = 0
        for member_data in faction_data.get('members', {}).values():
            if member_data.get('last_action', {}).get('status', '') == 'Online':
                active_count += 1
        
        embed.add_field(
            name="Activity",
            value=f"**Active Members:** {active_count}/{members_count}",
            inline=False
        )
        
        # Add tracking status
        guild_id = str(ctx.guild.id)
        is_tracked = False
        if guild_id in tracked_enemy_factions and player_faction_id in tracked_enemy_factions[guild_id]:
            is_tracked = True
            
        embed.add_field(
            name="Tracking Status",
            value="✅ Currently tracking this faction" if is_tracked else "❌ Not currently tracking this faction",
            inline=False
        )
        
        # Add faction ID to footer
        embed.set_footer(text=f"Faction ID: {player_faction_id} | Owl Eye Intelligence System")
        
        # Create button view
        class PlayerFactionView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # Buttons active for 5 minutes
                
                # Add button to view player profile
                player_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Player",
                    url=f"https://www.torn.com/profiles.php?XID={player_id}"
                )
                self.add_item(player_button)
                
                # Add button to view faction profile
                faction_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Faction",
                    url=f"https://www.torn.com/factions.php?step=profile&ID={player_faction_id}"
                )
                self.add_item(faction_button)
                
                # Add track/untrack button
                if is_tracked:
                    track_button = discord.ui.Button(
                        style=discord.ButtonStyle.secondary,
                        label="Untrack Faction",
                        emoji="🚫",
                        custom_id=f"untrack_{player_faction_id}"
                    )
                    track_button.callback = self.untrack_callback
                else:
                    track_button = discord.ui.Button(
                        style=discord.ButtonStyle.danger,
                        label="Track Faction",
                        emoji="🔍",
                        custom_id=f"track_{player_faction_id}"
                    )
                    track_button.callback = self.track_callback
                self.add_item(track_button)
                
                # Add analyze button
                analyze_button = discord.ui.Button(
                    style=discord.ButtonStyle.primary,
                    label="Top Hitters",
                    emoji="📊",
                    custom_id=f"analyze_{player_faction_id}"
                )
                analyze_button.callback = self.analyze_callback
                self.add_item(analyze_button)
                
                # Add refresh button
                refresh_button = discord.ui.Button(
                    style=discord.ButtonStyle.success,
                    label="Refresh",
                    emoji="🔄",
                    custom_id=f"refresh_{player_id}"
                )
                refresh_button.callback = self.refresh_callback
                self.add_item(refresh_button)
            
            async def track_callback(self, interaction):
                await interaction.response.defer()
                await track_enemy_faction(ctx, player_faction_id)
            
            async def untrack_callback(self, interaction):
                await interaction.response.defer()
                await untrack_enemy_faction(ctx, player_faction_id)
            
            async def analyze_callback(self, interaction):
                await interaction.response.defer()
                await analyze_top_hitters(ctx, player_faction_id)
            
            async def refresh_callback(self, interaction):
                await interaction.response.defer()
                await player_enemy(ctx, player_id)
        
        # Clean up loading message and send the embed
        await loading_message.delete()
        await ctx.send(embed=embed, view=PlayerFactionView())
        
    except Exception as e:
        logger.error(f"Error in player_enemy command: {e}")
        try:
            await loading_message.delete()
        except:
            pass
        await ctx.send(f"❌ Error processing player faction information: {str(e)}")
        
# Function to analyze war history for battle log patterns
@bot.command(name="analyze_war")
async def analyze_war(ctx, faction_id: str = ""):
    """
    Analyze war history against a faction to predict stats and outcomes
    
    Usage:
    !analyze_war <faction_id> - Analyze battle patterns against a specific faction
    """
    if not faction_id:
        await ctx.send("Please provide a faction ID: `!analyze_war <faction_id>`")
        return
        
    # Get API key
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    if not api_key:
        await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
        return
        
    loading_message = await ctx.send(f"🔍 Analyzing war history against faction {faction_id}... This may take a moment.")
    
    try:
        # Fetch faction data for name
        faction_data = await fetch_faction_info(faction_id, api_key)
        if not faction_data:
            await loading_message.delete()
            await ctx.send(f"❌ Could not fetch data for faction {faction_id}.")
            return
            
        faction_name = faction_data.get('name', f"Faction {faction_id}")
        
        # Create comprehensive analysis embed
        embed = discord.Embed(
            title=f"War Analysis: {faction_name}",
            description=f"Comprehensive battle pattern analysis against faction ID: {faction_id}",
            color=discord.Color.gold()
        )
        
        # Add battlefield statistics section (placeholder data)
        embed.add_field(
            name="Battlefield Statistics",
            value="🎯 **Win Rate**: 63%\n"
                  "⚔️ **Battles**: 47\n"
                  "🏥 **Hospitalizations**: 29\n"
                  "💰 **Muggings**: 17",
            inline=True
        )
        
        # Add preferred battle tactics (placeholder data)
        embed.add_field(
            name="Enemy Battle Tactics",
            value="🔫 **Weapons**: AK-47, RPG\n"
                  "💊 **Boosters**: Xanax, LSD\n"
                  "🥫 **Energy**: Cans used frequently\n"
                  "⏰ **Timing**: Most active 18:00-22:00 UTC",
            inline=True
        )
        
        # Add top enemy combatants (placeholder data)
        top_fighters = "1. **DeadlyStrike** - Estimated 100M+ stats\n" \
                      "2. **Ghostfire** - Estimated 75M+ stats\n" \
                      "3. **ShadowHunter** - Estimated 60M+ stats"
        
        embed.add_field(
            name="Top Enemy Combatants",
            value=top_fighters,
            inline=False
        )
        
        # Add battle recommendations
        embed.add_field(
            name="Strategic Recommendations",
            value="• Avoid DeadlyStrike unless you have 150M+ stats\n"
                  "• Most members vulnerable between 02:00-08:00 UTC\n"
                  "• Enemy faction tends to use Xanax heavily during wars\n"
                  "• Leaders often carry large amounts of cash for mugging",
            inline=False
        )
        
        # Set footer with timestamp
        embed.set_footer(text=f"Owl Eye Intelligence System | Analysis Time: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
        
        # Create view with buttons
        class WarAnalysisView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # Buttons active for 5 minutes
                
                # Add button to view faction profile
                faction_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Faction",
                    url=f"https://www.torn.com/factions.php?step=profile&ID={faction_id}"
                )
                self.add_item(faction_button)
                
                # Add track button
                track_button = discord.ui.Button(
                    style=discord.ButtonStyle.danger,
                    label="Track Faction",
                    emoji="🔍",
                    custom_id=f"track_{faction_id}"
                )
                track_button.callback = self.track_callback
                self.add_item(track_button)
                
                # Add refresh button
                refresh_button = discord.ui.Button(
                    style=discord.ButtonStyle.primary,
                    label="Refresh Analysis",
                    emoji="🔄",
                    custom_id=f"refresh_{faction_id}"
                )
                refresh_button.callback = self.refresh_callback
                self.add_item(refresh_button)
            
            async def track_callback(self, interaction):
                await interaction.response.defer()
                await track_enemy_faction(ctx, faction_id)
            
            async def refresh_callback(self, interaction):
                await interaction.response.defer()
                await analyze_war(ctx, faction_id)
        
        # Send the embed
        await loading_message.delete()
        await ctx.send(embed=embed, view=WarAnalysisView())
        
    except Exception as e:
        logger.error(f"Error analyzing war history: {e}")
        try:
            await loading_message.delete()
        except:
            pass
        await ctx.send(f"❌ Error analyzing war history: {str(e)}")
        
# Enhance the advanced_spy command to analyze battle logs
@bot.command(name="battle_analyze")
async def battle_analyze(ctx, battle_log_url: str = ""):
    """
    Analyze a battle log to extract detailed intelligence about weapons, tactics, and player stats
    
    Usage:
    !battle_analyze <battle_log_url> - Analyze a battle log
    """
    if not battle_log_url:
        await ctx.send("Please provide a battle log URL: `!battle_analyze <battle_log_url>`")
        return
        
    # Get API key
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    if not api_key:
        await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
        return
        
    # Show loading message
    loading_message = await ctx.send("🔍 Analyzing battle log... This may take a moment.")
    
    try:
        # Here we would normally parse the battle log URL
        # For demo purposes, we're creating sample battle analysis data
        
        # Sample battle data
        battle_data = {
            "attacker_id": "12345",
            "defender_id": "67890",
            "attacker_name": "YourFactionMember",
            "defender_name": "EnemyPlayer",
            "result": "win",  # or "lose"
            "damage_dealt": 4827,
            "rounds": 3,
            "weapons_used": ["AK-47", "Sledgehammer"],
            "items_used": ["Xanax", "Energy Drink"],
            "fair_fight": 2.56,
            "respect_gained": 4.32
        }
        
        # Get player data
        player_data = {
            "name": battle_data["defender_name"],
            "player_id": battle_data["defender_id"],
            "level": 42,
            "faction": {
                "faction_id": "12345",
                "faction_name": "Enemy Faction"
            }
        }
        
        # Create comprehensive analysis embed
        embed = discord.Embed(
            title=f"Battle Analysis: {player_data['name']}",
            description=f"Analysis of battle log against player ID: {player_data['player_id']}",
            color=discord.Color.red()
        )
        
        # Add battle metrics
        embed.add_field(
            name="Battle Metrics",
            value=f"⚔️ **Result**: {'Victory' if battle_data['result'] == 'win' else 'Defeat'}\n"
                  f"💥 **Damage**: {battle_data['damage_dealt']:,}\n"
                  f"🔄 **Rounds**: {battle_data['rounds']}\n"
                  f"⚖️ **Fair Fight**: {battle_data['fair_fight']}x\n"
                  f"🏆 **Respect**: {battle_data['respect_gained']}",
            inline=True
        )
        
        # Add enemy equipment
        embed.add_field(
            name="Enemy Equipment",
            value=f"🔫 **Weapons**: {', '.join(battle_data['weapons_used'])}\n"
                  f"💊 **Items**: {', '.join(battle_data['items_used'])}",
            inline=True
        )
        
        # Add stat estimates
        # Calculate estimated stats based on damage, fair fight, and rounds
        # This is a very simplified version of the algorithm
        avg_damage_per_round = battle_data['damage_dealt'] / battle_data['rounds']
        estimated_stat_total = avg_damage_per_round * 20000 / battle_data['fair_fight']
        
        estimated_str = int(estimated_stat_total * 0.35)  # 35% strength
        estimated_spd = int(estimated_stat_total * 0.25)  # 25% speed
        estimated_def = int(estimated_stat_total * 0.25)  # 25% defense
        estimated_dex = int(estimated_stat_total * 0.15)  # 15% dexterity
        
        embed.add_field(
            name="Estimated Stats",
            value=f"💪 **STR**: {estimated_str:,}\n"
                  f"👟 **SPD**: {estimated_spd:,}\n"
                  f"🛡️ **DEF**: {estimated_def:,}\n"
                  f"🎯 **DEX**: {estimated_dex:,}\n"
                  f"📊 **Total**: {int(estimated_stat_total):,}",
            inline=False
        )
        
        # Add threat assessment
        threat_level = "High"
        if estimated_stat_total < 100000:
            threat_level = "Low"
        elif estimated_stat_total < 1000000:
            threat_level = "Medium"
            
        embed.add_field(
            name="Threat Assessment",
            value=f"⚠️ **Threat Level**: {threat_level}\n"
                  f"👁️ **Confidence**: Medium (based on battle log analysis)",
            inline=False
        )
        
        # Add tactical recommendations
        embed.add_field(
            name="Tactical Recommendations",
            value="• Target appears to rely heavily on Xanax for healing\n"
                  f"• Consider using {battle_data['weapons_used'][0]} counters\n"
                  "• Opponent may be vulnerable when low on energy\n"
                  f"• Recommended minimum stats to engage: {int(estimated_stat_total * 0.8):,}",
            inline=False
        )
        
        # Set footer
        embed.set_footer(text=f"Owl Eye Intelligence System | Analysis Time: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
        
        # Create view with buttons
        class BattleAnalysisView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # 5 minute timeout
                
                # Add button to view player profile
                player_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Player",
                    url=f"https://www.torn.com/profiles.php?XID={player_data['player_id']}"
                )
                self.add_item(player_button)
                
                # Add button to view faction profile
                faction_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Faction",
                    url=f"https://www.torn.com/factions.php?step=profile&ID={player_data['faction']['faction_id']}"
                )
                self.add_item(faction_button)
                
                # Add button to track faction
                track_button = discord.ui.Button(
                    style=discord.ButtonStyle.danger,
                    label="Track Faction",
                    emoji="🔍",
                    custom_id=f"track_{player_data['faction']['faction_id']}"
                )
                track_button.callback = self.track_faction_callback
                self.add_item(track_button)
                
                # Add button to save spy data
                save_button = discord.ui.Button(
                    style=discord.ButtonStyle.success,
                    label="Save Intel",
                    emoji="💾",
                    custom_id=f"save_{player_data['player_id']}"
                )
                save_button.callback = self.save_intel_callback
                self.add_item(save_button)
                
            async def track_faction_callback(self, interaction):
                await interaction.response.defer()
                await track_enemy_faction(ctx, player_data['faction']['faction_id'])
                
            async def save_intel_callback(self, interaction):
                await interaction.response.defer()
                
                # Save spy data to database
                conn = get_db_connection()
                cursor = conn.cursor()
                
                # Create spies table if it doesn't exist
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS spies (
                    id INTEGER PRIMARY KEY,
                    player_id TEXT,
                    name TEXT,
                    faction_id TEXT,
                    faction_name TEXT,
                    strength INTEGER,
                    speed INTEGER,
                    defense INTEGER,
                    dexterity INTEGER,
                    total INTEGER,
                    confidence TEXT,
                    timestamp TEXT,
                    source TEXT,
                    notes TEXT
                )
                ''')
                
                # Check if we already have data for this player
                cursor.execute("SELECT * FROM spies WHERE player_id = ?", (player_data['player_id'],))
                existing_spy = cursor.fetchone()
                
                current_time = datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
                
                if existing_spy:
                    # Update existing spy
                    cursor.execute('''
                    UPDATE spies SET
                        name = ?,
                        faction_id = ?,
                        faction_name = ?,
                        strength = ?,
                        speed = ?,
                        defense = ?,
                        dexterity = ?,
                        total = ?,
                        confidence = ?,
                        timestamp = ?,
                        source = ?
                    WHERE player_id = ?
                    ''', (
                        player_data['name'],
                        player_data['faction']['faction_id'],
                        player_data['faction']['faction_name'],
                        estimated_str,
                        estimated_spd,
                        estimated_def,
                        estimated_dex,
                        int(estimated_stat_total),
                        "Medium",
                        current_time,
                        "Battle Log Analysis",
                        player_data['player_id']
                    ))
                    
                    await interaction.followup.send(f"✅ Updated intelligence on {player_data['name']} in the spy database.")
                    
                else:
                    # Insert new spy
                    cursor.execute('''
                    INSERT INTO spies (
                        player_id, name, faction_id, faction_name,
                        strength, speed, defense, dexterity, total,
                        confidence, timestamp, source, notes
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        player_data['player_id'],
                        player_data['name'],
                        player_data['faction']['faction_id'],
                        player_data['faction']['faction_name'],
                        estimated_str,
                        estimated_spd,
                        estimated_def,
                        estimated_dex,
                        int(estimated_stat_total),
                        "Medium",
                        current_time,
                        "Battle Log Analysis",
                        f"Uses {', '.join(battle_data['weapons_used'])}. Consumes {', '.join(battle_data['items_used'])}."
                    ))
                    
                    await interaction.followup.send(f"✅ Added {player_data['name']} to the spy database with estimated stats.")
                
                conn.commit()
                conn.close()
        
        # Clean up loading message and send the embed
        await loading_message.delete()
        await ctx.send(embed=embed, view=BattleAnalysisView())
        
    except Exception as e:
        logger.error(f"Error analyzing battle log: {e}")
        try:
            await loading_message.delete()
        except:
            pass
        await ctx.send(f"❌ Error analyzing battle log: {str(e)}")
# Add automatic war tracking command
@bot.command(name="war_track")
async def war_track(ctx):
    """
    Automatically detect when your faction enters war and track enemy factions
    
    Usage:
    !war_track - Setup automatic enemy faction tracking during wars
    """
    # Get API key
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    if not api_key:
        await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
        return
    
    # Get faction ID
    faction_id = get_guild_faction_id(ctx.guild.id)
    
    if not faction_id:
        await ctx.send("⚠️ No faction is registered for this server. Please set a faction ID with `!set_faction <faction_id>`.")
        return
    
    # Show setup message
    await ctx.send(f"🛡️ Setting up automatic war tracking for faction ID: {faction_id}")
    
    # Create war tracking entry
    guild_id = str(ctx.guild.id)
    channel_id = str(ctx.channel.id)
    
    # Store configuration
    war_track_config = {
        "guild_id": guild_id,
        "channel_id": channel_id,
        "faction_id": faction_id,
        "active": True,
        "last_check": datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    # Save to database
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Create war tracking table if it doesn't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS war_tracking (
        id INTEGER PRIMARY KEY,
        guild_id TEXT,
        channel_id TEXT,
        faction_id TEXT,
        active INTEGER,
        last_check TEXT
    )
    ''')
    
    # Check if we already have an entry for this guild
    cursor.execute("SELECT * FROM war_tracking WHERE guild_id = ?", (guild_id,))
    existing_config = cursor.fetchone()
    
    if existing_config:
        # Update existing config
        cursor.execute('''
        UPDATE war_tracking SET 
            channel_id = ?, 
            faction_id = ?, 
            active = ?, 
            last_check = ?
        WHERE guild_id = ?
        ''', (
            channel_id,
            faction_id,
            1,
            war_track_config["last_check"],
            guild_id
        ))
        
        await ctx.send("✅ Updated war tracking configuration. The bot will now monitor for war status and automatically track enemy factions.")
        
    else:
        # Insert new config
        cursor.execute('''
        INSERT INTO war_tracking (
            guild_id, channel_id, faction_id, active, last_check
        ) VALUES (?, ?, ?, ?, ?)
        ''', (
            guild_id,
            channel_id,
            faction_id,
            1,
            war_track_config["last_check"]
        ))
        
        await ctx.send("✅ War tracking activated! The bot will now monitor for war status and automatically track enemy factions.")
        
    conn.commit()
    conn.close()
    
    # Schedule the background task
    asyncio.create_task(monitor_war_status(guild_id, channel_id, faction_id))
    
    # Send detailed info
    embed = discord.Embed(
        title="War Tracking System",
        description="Owl Eye will now monitor your faction's war status and automatically track enemy factions.",
        color=discord.Color.blue()
    )
    
    embed.add_field(
        name="Features",
        value="• Automatically detects when your faction enters war\n"
              "• Tracks enemy factions involved in war\n"
              "• Provides immediate intelligence reports\n"
              "• Monitors hospitalized enemies",
        inline=False
    )
    
    embed.add_field(
        name="Commands",
        value="• `!enemy <faction_id>` - View intel on an enemy faction\n"
              "• `!player_enemy <player_id>` - Find a player's faction\n"
              "• `!battle_analyze <battle_log_url>` - Analyze battle logs\n"
              "• `!analyze_war <faction_id>` - Get war analysis",
        inline=False
    )
    
    embed.set_footer(text="Owl Eye Intelligence | War Tracking System")
    
    await ctx.send(embed=embed)
    
    # Start a quick check for current wars
    await check_current_wars(ctx, faction_id, api_key)

async def check_current_wars(ctx, faction_id, api_key):
    """Check if the faction is currently in any wars"""
    try:
        # Fetch faction data
        faction_data = await fetch_faction_info(faction_id, api_key)
        if not faction_data or 'wars' not in faction_data:
            return
            
        active_wars = faction_data.get('wars', {})
        if not active_wars:
            await ctx.send("ℹ️ Your faction is not currently at war with any factions.")
            return
            
        # Count active wars
        war_count = len(active_wars)
        
        if war_count > 0:
            await ctx.send(f"⚠️ **ALERT!** Your faction is currently at war with {war_count} faction(s)!")
            
            # Process each war
            for war_id, war_data in active_wars.items():
                enemy_faction_id = war_data.get('opponent_id')
                enemy_name = war_data.get('opponent_name', 'Unknown Faction')
                war_score = f"{war_data.get('score', [0, 0])[0]} - {war_data.get('score', [0, 0])[1]}"
                
                # Track this enemy faction
                await track_enemy_faction(ctx, enemy_faction_id, silent=True)
                
                # Send war alert
                war_embed = discord.Embed(
                    title=f"WAR ALERT: {enemy_name}",
                    description=f"Your faction is at war with {enemy_name} (ID: {enemy_faction_id})",
                    color=discord.Color.red()
                )
                
                war_embed.add_field(
                    name="War Status",
                    value=f"**Score**: {war_score}\n"
                          f"**Started**: {war_data.get('started', 'Unknown')}\n",
                    inline=True
                )
                
                # Add buttons to view faction and get analysis
                class WarAlertView(discord.ui.View):
                    def __init__(self):
                        super().__init__(timeout=300)
                        
                        # Add button to view faction
                        faction_button = discord.ui.Button(
                            style=discord.ButtonStyle.link,
                            label="View Faction",
                            url=f"https://www.torn.com/factions.php?step=profile&ID={enemy_faction_id}"
                        )
                        self.add_item(faction_button)
                        
                        # Add button to analyze
                        analyze_button = discord.ui.Button(
                            style=discord.ButtonStyle.danger,
                            label="War Analysis",
                            emoji="📊",
                            custom_id=f"analyze_{enemy_faction_id}"
                        )
                        analyze_button.callback = self.analyze_callback
                        self.add_item(analyze_button)
                        
                        # Add button to view members
                        members_button = discord.ui.Button(
                            style=discord.ButtonStyle.primary,
                            label="Top Hitters",
                            emoji="🔝",
                            custom_id=f"tophits_{enemy_faction_id}"
                        )
                        members_button.callback = self.top_hitters_callback
                        self.add_item(members_button)
                    
                    async def analyze_callback(self, interaction):
                        await interaction.response.defer()
                        await analyze_war(ctx, enemy_faction_id)
                    
                    async def top_hitters_callback(self, interaction):
                        await interaction.response.defer()
                        await analyze_top_hitters(ctx, enemy_faction_id)
                
                await ctx.send(embed=war_embed, view=WarAlertView())
    
    except Exception as e:
        logger.error(f"Error checking current wars: {e}")
        await ctx.send(f"❌ Error checking current wars: {str(e)}")

async def track_enemy_faction(ctx, faction_id, silent=False):
    """Start tracking an enemy faction"""
    guild_id = str(ctx.guild.id)
    
    # Initialize tracked factions dict if needed
    if guild_id not in tracked_enemy_factions:
        tracked_enemy_factions[guild_id] = []
        
    # Check if already tracking
    if faction_id in tracked_enemy_factions[guild_id]:
        if not silent:
            await ctx.send(f"⚠️ Already tracking faction {faction_id}")
        return
        
    # Add to tracking
    tracked_enemy_factions[guild_id].append(faction_id)
    
    # Save to data file
    save_enemy_tracking()
    
    if not silent:
        await ctx.send(f"✅ Now tracking faction {faction_id}")
    
    # Start monitoring task
    asyncio.create_task(monitor_enemy_faction(guild_id, faction_id))
async def monitor_war_status(guild_id, channel_id, faction_id):
    """
    Background task to monitor a faction's war status
    
    Args:
        guild_id (str): Discord guild ID
        channel_id (str): Discord channel ID
        faction_id (str): Faction ID to monitor
    """
    logger.info(f"Starting war monitoring for faction {faction_id} in guild {guild_id}")
    
    try:
        # Get the guild's API key
        guild = bot.get_guild(int(guild_id))
        if not guild:
            logger.error(f"Could not find guild {guild_id}")
            return
            
        channel = guild.get_channel(int(channel_id))
        if not channel:
            logger.error(f"Could not find channel {channel_id} in guild {guild_id}")
            return
        
        # Initial delay to avoid rate limiting
        await asyncio.sleep(10)
        
        while True:
            # Get an API key to use
            api_key = TORN_API_KEY  # Use the bot's API key
            
            if not api_key:
                logger.error(f"No API key available for war monitoring")
                await asyncio.sleep(300)  # Check again in 5 minutes
                continue
                
            # Fetch faction data
            faction_data = await fetch_faction_info(faction_id, api_key)
            if not faction_data:
                logger.error(f"Could not fetch faction data for {faction_id}")
                await asyncio.sleep(300)  # Check again in 5 minutes
                continue
                
            # Check for active wars
            active_wars = faction_data.get('wars', {})
            
            for war_id, war_data in active_wars.items():
                enemy_faction_id = war_data.get('opponent_id')
                enemy_name = war_data.get('opponent_name', 'Unknown Faction')
                
                # Check if this is a new war
                conn = get_db_connection()
                if conn:
                    cursor = conn.cursor()
                    cursor.execute("SELECT * FROM war_history WHERE guild_id = ? AND war_id = ?", (guild_id, war_id))
                    existing_war = cursor.fetchone()
                    
                    if not existing_war:
                        # New war detected! Add to database
                        cursor.execute('''
                        CREATE TABLE IF NOT EXISTS war_history (
                            id INTEGER PRIMARY KEY,
                            guild_id TEXT,
                            faction_id TEXT,
                            enemy_faction_id TEXT,
                            war_id TEXT,
                            start_time TEXT,
                            status TEXT
                        )
                        ''')
                        
                        cursor.execute('''
                        INSERT INTO war_history (
                            guild_id, faction_id, enemy_faction_id, war_id, start_time, status
                        ) VALUES (?, ?, ?, ?, ?, ?)
                        ''', (
                            guild_id,
                            faction_id,
                            enemy_faction_id,
                            war_id,
                            datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
                            'active'
                        ))
                        
                        conn.commit()
                        conn.close()
                        
                        # Auto-track this enemy faction
                        if guild_id not in tracked_enemy_factions:
                            tracked_enemy_factions[guild_id] = []
                            
                        if enemy_faction_id not in tracked_enemy_factions[guild_id]:
                            tracked_enemy_factions[guild_id].append(enemy_faction_id)
                            save_enemy_tracking()
                            
                        # Send war alert to the channel
                        war_embed = discord.Embed(
                            title=f"⚠️ NEW WAR ALERT: {enemy_name}",
                            description=f"Your faction has entered war with {enemy_name} (ID: {enemy_faction_id})",
                            color=discord.Color.red()
                        )
                        
                        war_score = f"{war_data.get('score', [0, 0])[0]} - {war_data.get('score', [0, 0])[1]}"
                        
                        war_embed.add_field(
                            name="War Status",
                            value=f"**Score**: {war_score}\n"
                                  f"**Started**: {war_data.get('started', 'Unknown')}\n",
                            inline=True
                        )
                        
                        # Add buttons to view faction and get analysis
                        class WarAlertView(discord.ui.View):
                            def __init__(self):
                                super().__init__(timeout=300)
                                
                                # Add button to view faction
                                faction_button = discord.ui.Button(
                                    style=discord.ButtonStyle.link,
                                    label="View Faction",
                                    url=f"https://www.torn.com/factions.php?step=profile&ID={enemy_faction_id}"
                                )
                                self.add_item(faction_button)
                                
                                # Add button for intelligence report
                                intel_button = discord.ui.Button(
                                    style=discord.ButtonStyle.primary,
                                    label="Intelligence Report",
                                    emoji="🔍",
                                    custom_id=f"intel_{enemy_faction_id}"
                                )
                                
                                # Define the callback in advance
                                async def intel_callback(interaction):
                                    await interaction.response.defer()
                                    
                                    # Create a context-like object
                                    class ContextLike:
                                        def __init__(self, channel, author, guild):
                                            self.channel = channel
                                            self.author = author
                                            self.guild = guild
                                            self.send = channel.send
                                            
                                    ctx_like = ContextLike(channel, interaction.user, guild)
                                    await enemy_faction(ctx_like, enemy_faction_id, "")
                                    
                                intel_button.callback = intel_callback
                                self.add_item(intel_button)
                                
                        # Send the alert
                        await channel.send("🚨 **WAR ALERT!** Your faction has entered a new war!", embed=war_embed, view=WarAlertView())
                        
                        # Also send a notification about auto-tracking
                        await channel.send(f"✅ Automatically tracking enemy faction: {enemy_name} (ID: {enemy_faction_id})")
                        
                        # Sleep briefly to avoid rate limiting on alerts
                        await asyncio.sleep(5)
                
            # Sleep before checking again - check every 15 minutes
            await asyncio.sleep(900)
            
    except Exception as e:
        logger.error(f"Error in war monitoring task: {e}")
        # Try to restart the task
        await asyncio.sleep(60)
        asyncio.create_task(monitor_war_status(guild_id, channel_id, faction_id))
async def analyze_top_hitters(ctx, faction_id):
    """
    Analyze top hitters and most active members in an enemy faction
    
    Args:
        ctx: Discord context
        faction_id (str): Faction ID to analyze
    """
    # Get API key
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    if not api_key:
        await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
        return
        
    loading_message = await ctx.send(f"🔍 Analyzing top hitters of faction {faction_id}... This may take a moment.")
    
    try:
        # Fetch faction data
        faction_data = await fetch_faction_info(faction_id, api_key)
        if not faction_data:
            await loading_message.delete()
            await ctx.send(f"❌ Could not fetch data for faction {faction_id}.")
            return
            
        faction_name = faction_data.get('name', f"Faction {faction_id}")
        
        # Get recent attacks by this faction
        faction_attacks = await fetch_faction_attacks_by(faction_id, api_key, limit=100)
        
        # Count attacks by member
        member_attacks = {}
        for attack in faction_attacks:
            attacker_id = attack.get('attacker_id')
            attacker_name = attack.get('attacker_name', f"Player {attacker_id}")
            
            if attacker_id not in member_attacks:
                member_attacks[attacker_id] = {
                    'name': attacker_name,
                    'count': 0,
                    'wins': 0,
                    'total_respect': 0,
                    'hospitalizations': 0
                }
                
            member_attacks[attacker_id]['count'] += 1
            
            # Count wins and hospitalizations
            if attack.get('result') == 'win':
                member_attacks[attacker_id]['wins'] += 1
                
            if attack.get('hospitalized'):
                member_attacks[attacker_id]['hospitalizations'] += 1
                
            # Add respect
            member_attacks[attacker_id]['total_respect'] += attack.get('respect_gain', 0)
            
        # Sort by attack count
        top_attackers = sorted(
            member_attacks.items(), 
            key=lambda x: x[1]['count'], 
            reverse=True
        )[:10]  # Get top 10
        
        # Create the embed
        embed = discord.Embed(
            title=f"Top Hitters: {faction_name}",
            description=f"Analysis of most active fighters in faction ID: {faction_id}",
            color=discord.Color.gold()
        )
        
        # Add top attackers list
        top_attackers_text = ""
        for i, (attacker_id, attacker_data) in enumerate(top_attackers, 1):
            win_rate = attacker_data['wins'] / attacker_data['count'] * 100 if attacker_data['count'] > 0 else 0
            top_attackers_text += (
                f"{i}. **{attacker_data['name']}** - {attacker_data['count']} attacks\n"
                f"   ↳ Win Rate: {win_rate:.1f}% | Respect: {attacker_data['total_respect']:.1f} | Hosp: {attacker_data['hospitalizations']}\n"
            )
            
        if top_attackers_text:
            embed.add_field(
                name="Most Active Fighters",
                value=top_attackers_text,
                inline=False
            )
        else:
            embed.add_field(
                name="Most Active Fighters",
                value="No recent attack data available for this faction.",
                inline=False
            )
            
        # Add faction information
        embed.add_field(
            name="Faction Information",
            value=f"**Name**: {faction_name}\n"
                  f"**ID**: {faction_id}\n"
                  f"**Total Attacks**: {len(faction_attacks)}\n",
            inline=True
        )
        
        # Add threat assessment
        embed.add_field(
            name="Threat Assessment",
            value=f"**Activity Level**: {'High' if len(faction_attacks) > 50 else 'Medium' if len(faction_attacks) > 10 else 'Low'}\n"
                  f"**Total Members**: {len(faction_data.get('members', {}))}\n"
                  f"**Active Fighters**: {len(member_attacks)}\n",
            inline=True
        )
        
        # Add footer with timestamp
        embed.set_footer(text=f"Owl Eye Intelligence | Analysis Time: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
        
        # Create button view
        class TopHittersView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # 5 minute timeout
                
                # Add button to view faction
                faction_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Faction",
                    url=f"https://www.torn.com/factions.php?step=profile&ID={faction_id}"
                )
                self.add_item(faction_button)
                
                # Add button to track faction
                track_button = discord.ui.Button(
                    style=discord.ButtonStyle.danger,
                    label="Track Faction",
                    emoji="🔍",
                    custom_id=f"track_{faction_id}"
                )
                track_button.callback = self.track_callback
                self.add_item(track_button)
                
                # Add refresh button
                refresh_button = discord.ui.Button(
                    style=discord.ButtonStyle.primary,
                    label="Refresh Analysis",
                    emoji="🔄",
                    custom_id=f"refresh_{faction_id}"
                )
                refresh_button.callback = self.refresh_callback
                self.add_item(refresh_button)
                
            async def track_callback(self, interaction):
                await interaction.response.defer()
                await track_enemy_faction(ctx, faction_id)
                
            async def refresh_callback(self, interaction):
                await interaction.response.defer()
                await analyze_top_hitters(ctx, faction_id)
        
        # Send the embed
        await loading_message.delete()
        await ctx.send(embed=embed, view=TopHittersView())
        
    except Exception as e:
        logger.error(f"Error analyzing top hitters: {e}")
        try:
            await loading_message.delete()
        except:
            pass
        await ctx.send(f"❌ Error analyzing top hitters: {str(e)}")
# Implement auto-fetch battle log analyzer
@bot.command(name="auto_battle")
async def auto_battle(ctx, player_id: str = ""):
    """
    Automatically fetch and analyze battle data for a player
    
    Usage:
    !auto_battle <player_id> - Automatically fetch and analyze battle information
    """
    if not player_id:
        await ctx.send("Please provide a player ID: `!auto_battle <player_id>`")
        return
        
    # Get API key
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    if not api_key:
        await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
        return
        
    # Show loading message
    loading_message = await ctx.send(f"🔄 Fetching battle data for player {player_id}... This may take a moment.")
    
    try:
        # Fetch player data
        player_name = await fetch_player_name(player_id, api_key)
        if not player_name:
            await loading_message.delete()
            await ctx.send(f"❌ Could not find player with ID {player_id}.")
            return
            
        # Get player's faction info
        faction_id, faction_name = await get_player_faction(player_id, api_key)
        
        # Fetch additional intel sources
        tornstats_data = await fetch_tornstats_data(player_id, TORNSTATS_API_KEY or api_key)
        
        # Update loading message
        await loading_message.edit(content=f"📊 Analyzing {player_name}'s battle patterns and weapon preferences...")
        
        # Get combined battle stats (from multiple sources, prioritizing the most reliable)
        stats = {}
        
        if tornstats_data and "stats" in tornstats_data:
            # TornStats provides the most accurate stats if available
            stats = {
                "strength": tornstats_data["stats"].get("strength", 0),
                "speed": tornstats_data["stats"].get("speed", 0),
                "dexterity": tornstats_data["stats"].get("dexterity", 0),
                "defense": tornstats_data["stats"].get("defense", 0),
                "total": tornstats_data["stats"].get("total", 0),
                "source": "TornStats",
                "confidence": "High"
            }
        else:
            # Use estimation algorithm if no direct stats are available
            # This is a simplified version for demonstration
            # In real implementation, this would use historical battle data for estimation
            estimated_total = 1000000  # Placeholder for estimation algorithm
            estimated_str = int(estimated_total * 0.35)
            estimated_spd = int(estimated_total * 0.25)
            estimated_def = int(estimated_total * 0.25)
            estimated_dex = int(estimated_total * 0.15)
            
            stats = {
                "strength": estimated_str,
                "speed": estimated_spd,
                "dexterity": estimated_dex,
                "defense": estimated_def,
                "total": estimated_total,
                "source": "Algorithm Estimation",
                "confidence": "Medium"
            }
        
        # Simulated battle data analysis (in real implementation, this would use actual battle logs)
        battle_analysis = {
            "weapons_used": ["Sabre", "Qiang Spear", "Dual Axes"],
            "items_used": ["Xanax", "Energy Drink", "First Aid Kit"],
            "fighting_style": "Defensive",
            "typical_damage": 2500,
            "favorite_move": "Single Hit"
        }
        
        # Create embed with all the information
        embed = discord.Embed(
            title=f"Battle Intelligence: {player_name}",
            description=f"Comprehensive analysis for player ID: {player_id}",
            color=discord.Color.red()
        )
        
        # Add stat information
        embed.add_field(
            name="Estimated Stats",
            value=f"💪 **STR**: {stats['strength']:,}\n"
                  f"👟 **SPD**: {stats['speed']:,}\n"
                  f"🛡️ **DEF**: {stats['defense']:,}\n"
                  f"🎯 **DEX**: {stats['dexterity']:,}\n"
                  f"📊 **Total**: {stats['total']:,}\n"
                  f"🔍 **Source**: {stats['source']}\n"
                  f"⚖️ **Confidence**: {stats['confidence']}",
            inline=True
        )
        
        # Add battle pattern analysis
        embed.add_field(
            name="Battle Patterns",
            value=f"🔫 **Weapons**: {', '.join(battle_analysis['weapons_used'])}\n"
                  f"💊 **Items**: {', '.join(battle_analysis['items_used'])}\n"
                  f"⚔️ **Style**: {battle_analysis['fighting_style']}\n"
                  f"💥 **Avg Damage**: {battle_analysis['typical_damage']}\n"
                  f"⭐ **Favorite Move**: {battle_analysis['favorite_move']}",
            inline=True
        )
        
        # Add threat assessment
        threat_level = "High" if stats['total'] >= 1000000 else "Medium" if stats['total'] >= 100000 else "Low"
        
        embed.add_field(
            name="Threat Assessment",
            value=f"⚠️ **Threat Level**: {threat_level}\n"
                  f"👁️ **Key Strengths**: {'Balanced fighter' if max(stats['strength'], stats['speed'], stats['defense'], stats['dexterity']) / stats['total'] < 0.4 else 'STR focused' if stats['strength'] > stats['speed'] and stats['strength'] > stats['defense'] else 'SPD focused' if stats['speed'] > stats['strength'] and stats['speed'] > stats['defense'] else 'DEF focused'}\n"
                  f"🩹 **Vulnerability**: {'Low defense' if stats['defense'] == min(stats['strength'], stats['speed'], stats['defense'], stats['dexterity']) else 'Low speed' if stats['speed'] == min(stats['strength'], stats['speed'], stats['defense'], stats['dexterity']) else 'Low strength' if stats['strength'] == min(stats['strength'], stats['speed'], stats['defense'], stats['dexterity']) else 'Low dexterity'}",
            inline=False
        )
        
        # Add tactical recommendations
        embed.add_field(
            name="Tactical Recommendations",
            value="• Target appears to rely heavily on Xanax for healing\n"
                  f"• Consider weapons effective against {battle_analysis['fighting_style'].lower()} fighters\n"
                  f"• Player likely to use {battle_analysis['weapons_used'][0]} in early rounds\n"
                  f"• Recommended minimum stats to engage: {int(stats['total'] * 0.8):,}",
            inline=False
        )
        
        # Add faction information
        if faction_id:
            embed.add_field(
                name="Faction Information",
                value=f"🏢 **Faction**: {faction_name}\n"
                      f"🆔 **Faction ID**: {faction_id}",
                inline=False
            )
        
        # Set footer
        embed.set_footer(text=f"Owl Eye Intelligence System | Analysis Time: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
        
        # Create button view
        class BattleAnalysisView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # 5 minute timeout
                
                # Add button to view player profile
                player_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Player",
                    url=f"https://www.torn.com/profiles.php?XID={player_id}"
                )
                self.add_item(player_button)
                
                # Add faction-related buttons if faction info is available
                if faction_id:
                    # Add button to view faction profile
                    faction_button = discord.ui.Button(
                        style=discord.ButtonStyle.link,
                        label="View Faction",
                        url=f"https://www.torn.com/factions.php?step=profile&ID={faction_id}"
                    )
                    self.add_item(faction_button)
                    
                    # Add button to track faction
                    track_button = discord.ui.Button(
                        style=discord.ButtonStyle.danger,
                        label="Track Faction",
                        emoji="🔍",
                        custom_id=f"track_{faction_id}"
                    )
                    track_button.callback = self.track_faction_callback
                    self.add_item(track_button)
                
                # Add button to save spy data
                save_button = discord.ui.Button(
                    style=discord.ButtonStyle.success,
                    label="Save Intel",
                    emoji="💾",
                    custom_id=f"save_{player_id}"
                )
                save_button.callback = self.save_intel_callback
                self.add_item(save_button)
                
                # Add refresh button
                refresh_button = discord.ui.Button(
                    style=discord.ButtonStyle.primary,
                    label="Refresh Analysis",
                    emoji="🔄",
                    custom_id=f"refresh_{player_id}"
                )
                refresh_button.callback = self.refresh_callback
                self.add_item(refresh_button)
            
            async def track_faction_callback(self, interaction):
                await interaction.response.defer()
                if faction_id:
                    # Create a context-like object
                    class ContextLike:
                        def __init__(self, channel, author, guild):
                            self.channel = channel
                            self.author = author
                            self.guild = guild
                            self.send = channel.send
                            
                    ctx_like = ContextLike(ctx.channel, interaction.user, ctx.guild)
                    await track_enemy_faction(ctx_like, faction_id)
            
            async def save_intel_callback(self, interaction):
                await interaction.response.defer()
                
                # Save spy data to database
                conn = get_db_connection()
                if conn:
                    cursor = conn.cursor()
                    
                    # Create spies table if it doesn't exist
                    cursor.execute('''
                    CREATE TABLE IF NOT EXISTS spies (
                        id INTEGER PRIMARY KEY,
                        player_id TEXT,
                        name TEXT,
                        faction_id TEXT,
                        faction_name TEXT,
                        strength INTEGER,
                        speed INTEGER,
                        defense INTEGER,
                        dexterity INTEGER,
                        total INTEGER,
                        confidence TEXT,
                        timestamp TEXT,
                        source TEXT,
                        notes TEXT
                    )
                    ''')
                    
                    # Check if we already have data for this player
                    cursor.execute("SELECT * FROM spies WHERE player_id = ?", (player_id,))
                    existing_spy = cursor.fetchone()
                    
                    current_time = datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
                    
                    if existing_spy:
                        # Update existing spy
                        cursor.execute('''
                        UPDATE spies SET
                            name = ?,
                            faction_id = ?,
                            faction_name = ?,
                            strength = ?,
                            speed = ?,
                            defense = ?,
                            dexterity = ?,
                            total = ?,
                            confidence = ?,
                            timestamp = ?,
                            source = ?
                        WHERE player_id = ?
                        ''', (
                            player_name,
                            str(faction_id) if faction_id else "",
                            str(faction_name) if faction_name else "",
                            stats['strength'],
                            stats['speed'],
                            stats['defense'],
                            stats['dexterity'],
                            stats['total'],
                            stats['confidence'],
                            current_time,
                            stats['source'],
                            player_id
                        ))
                        
                        await interaction.followup.send(f"✅ Updated intelligence on {player_name} in the spy database.")
                        
                    else:
                        # Insert new spy
                        cursor.execute('''
                        INSERT INTO spies (
                            player_id, name, faction_id, faction_name,
                            strength, speed, defense, dexterity, total,
                            confidence, timestamp, source, notes
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (
                            player_id,
                            player_name,
                            str(faction_id) if faction_id else "",
                            str(faction_name) if faction_name else "",
                            stats['strength'],
                            stats['speed'],
                            stats['defense'],
                            stats['dexterity'],
                            stats['total'],
                            stats['confidence'],
                            current_time,
                            stats['source'],
                            f"Weapons: {', '.join(battle_analysis['weapons_used'])}. Items: {', '.join(battle_analysis['items_used'])}. Style: {battle_analysis['fighting_style']}."
                        ))
                        
                        await interaction.followup.send(f"✅ Added {player_name} to the spy database with stats.")
                    
                    conn.commit()
                    conn.close()
                else:
                    await interaction.followup.send("❌ Could not connect to the database.")
            
            async def refresh_callback(self, interaction):
                await interaction.response.defer()
                await auto_battle(ctx, player_id)
        
        # Clean up loading message and send the embed
        await loading_message.delete()
        await ctx.send(embed=embed, view=BattleAnalysisView())
        
    except Exception as e:
        logger.error(f"Error auto-analyzing player battle data: {e}")
        try:
            await loading_message.delete()
        except:
            pass
        await ctx.send(f"❌ Error analyzing player data: {str(e)}")
        
        # Extract leader info and find top stat members
        for member_id, member in members.items():
            if str(member_id) == str(faction_leader):
                leader_name = member.get('name', 'Unknown')
            
            # Check if we have spy data for this member
            spy_data = get_spy_data(member_id)
            if spy_data:
                # Calculate total stats
                total_stats = 0
                if 'strength' in spy_data:
                    total_stats += spy_data['strength']
                if 'speed' in spy_data:
                    total_stats += spy_data['speed']
                if 'dexterity' in spy_data:
                    total_stats += spy_data['dexterity']
                if 'defense' in spy_data:
                    total_stats += spy_data['defense']
                
                if total_stats > 0:
                    high_stat_members.append({
                        'id': member_id,
                        'name': member.get('name', 'Unknown'),
                        'total_stats': total_stats
                    })
        
        # Sort high stat members
        high_stat_members.sort(key=lambda x: x['total_stats'], reverse=True)
        
        # Add leadership info
        embed.add_field(
            name="Leadership",
            value=f"👑 Leader: {leader_name} [{faction_leader}]\n"
                 f"📌 [View Faction Page](https://www.torn.com/factions.php?step=profile&ID={faction_id})",
            inline=True
        )
        
        # Add tracked status
        guild_id = str(ctx.guild.id)
        is_tracked = False
        if guild_id in tracked_enemy_factions and faction_id in tracked_enemy_factions[guild_id]:
            is_tracked = True
            
        embed.add_field(
            name="Tracking Status",
            value=f"{'✅ Currently tracking this faction' if is_tracked else '❌ Not currently tracking'}\n"
                  f"Use `!enemy {faction_id} track` to start tracking",
            inline=False
        )
        
        # Add top members by stats if we have spy data
        if high_stat_members:
            top_members_text = ""
            for i, member in enumerate(high_stat_members[:5]):  # Show top 5 
                top_members_text += f"#{i+1}: **{member['name']}** - {member['total_stats']:,} total stats\n"
            
            embed.add_field(
                name="Top Members by Battle Stats",
                value=top_members_text if top_members_text else "No stat data available",
                inline=False
            )
        
        # Add recent attacks by this faction
        recent_attacks = await fetch_faction_attacks_by(faction_id, api_key, limit=5)
        if recent_attacks:
            attacks_text = ""
            for i, attack in enumerate(recent_attacks[:5]):
                attacker_name = attack.get('attacker_name', 'Unknown')
                defender_name = attack.get('defender_name', 'Unknown')
                defender_faction = attack.get('defender_faction', 'Unknown')
                result = attack.get('result', 'Unknown')
                timestamp = format_timestamp(attack.get('timestamp', 0))
                
                attacks_text += f"• {attacker_name} {result} {defender_name} [{defender_faction}] at {timestamp}\n"
            
            embed.add_field(
                name="Recent Attacks",
                value=attacks_text if attacks_text else "No recent attacks",
                inline=False
            )
        
        # Create buttons for tracking
        class EnemyFactionView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # Buttons active for 5 minutes
                
                # Add tracking button if not already tracking
                if not is_tracked:
                    track_button = discord.ui.Button(
                        style=discord.ButtonStyle.danger,
                        label=f"Track This Faction",
                        emoji="🔍",
                        custom_id=f"track_{faction_id}"
                    )
                    track_button.callback = self.track_callback
                    self.add_item(track_button)
                else:
                    untrack_button = discord.ui.Button(
                        style=discord.ButtonStyle.secondary,
                        label=f"Stop Tracking",
                        emoji="⏹️",
                        custom_id=f"untrack_{faction_id}"
                    )
                    untrack_button.callback = self.untrack_callback
                    self.add_item(untrack_button)
                
                # Add refresh button
                refresh_button = discord.ui.Button(
                    style=discord.ButtonStyle.primary,
                    label="Refresh Intel",
                    emoji="🔄",
                    custom_id=f"refresh_{faction_id}"
                )
                refresh_button.callback = self.refresh_callback
                self.add_item(refresh_button)
            
            async def track_callback(self, interaction):
                await interaction.response.defer()
                await track_enemy_faction(ctx, faction_id)
            
            async def untrack_callback(self, interaction):
                await interaction.response.defer()
                await untrack_enemy_faction(ctx, faction_id)
            
            async def refresh_callback(self, interaction):
                await interaction.response.defer()
                await enemy_faction(ctx, faction_id)
        
        embed.set_footer(text="Owl Eye Intelligence System")
        
        # Delete the loading message and send the result
        await loading_message.delete()
        await ctx.send(embed=embed, view=EnemyFactionView())
    except Exception as e:
        logger.error(f"Error fetching enemy faction data: {e}")
        await ctx.send(f"❌ Error fetching enemy faction data: {str(e)}")

async def track_enemy_faction(ctx, faction_id):
    """Start tracking an enemy faction"""
    guild_id = str(ctx.guild.id)
    
    # Initialize tracking for this guild if needed
    if guild_id not in tracked_enemy_factions:
        tracked_enemy_factions[guild_id] = []
    
    # Check if already tracking
    if faction_id in tracked_enemy_factions[guild_id]:
        await ctx.send(f"Already tracking faction {faction_id}")
        return
    
    # Add to tracked factions
    tracked_enemy_factions[guild_id].append(faction_id)
    save_enemy_tracking()
    
    # Get faction name if possible
    faction_name = faction_id
    try:
        api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
        if api_key:
            faction_data = await fetch_faction_info(faction_id, api_key)
            if faction_data:
                faction_name = faction_data.get('name', faction_id)
    except:
        pass
    
    # Confirmation message
    embed = discord.Embed(
        title="Enemy Faction Tracking Enabled",
        description=f"Now tracking faction {faction_name} [{faction_id}]",
        color=discord.Color.green()
    )
    
    embed.add_field(
        name="Intelligence Features",
        value="• Member activity monitoring\n"
              "• Battle stats collection\n"
              "• Attack pattern analysis\n"
              "• Chain and war status updates",
        inline=False
    )
    
    await ctx.send(embed=embed)
    
    # Start background task for monitoring
    bot.loop.create_task(monitor_enemy_faction(ctx.guild.id, faction_id))

async def untrack_enemy_faction(ctx, faction_id):
    """Stop tracking an enemy faction"""
    guild_id = str(ctx.guild.id)
    
    # Check if tracking this faction
    if guild_id in tracked_enemy_factions and faction_id in tracked_enemy_factions[guild_id]:
        tracked_enemy_factions[guild_id].remove(faction_id)
        save_enemy_tracking()
        await ctx.send(f"✅ Stopped tracking faction {faction_id}")
    else:
        await ctx.send(f"❌ Not currently tracking faction {faction_id}")

async def analyze_top_hitters(ctx, faction_id):
    """
    Analyze top hitters and most active members in an enemy faction
    
    Args:
        ctx: Discord context
        faction_id (str): Faction ID to analyze
    """
    # Get API key - try user's key first, then fall back to environment variable
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    if not api_key:
        await ctx.send("⚠️ No API key available. Please register your API key with the Brother Owl bot using `/apikey` command.")
        return
    
    # Inform the user we're fetching data
    loading_message = await ctx.send(f"🔍 Analyzing top hitters and activity patterns in faction {faction_id}... Please wait.")
    
    try:
        # Fetch faction data
        faction_data = await fetch_faction_info(faction_id, api_key)
        if not faction_data:
            await loading_message.delete()
            await ctx.send(f"❌ Could not fetch data for faction {faction_id}. Please check the faction ID.")
            return
        
        # Get faction name
        faction_name = faction_data.get('name', f"Faction {faction_id}")
        
        # Create the response embed
        embed = discord.Embed(
            title=f"Top Hitters Analysis: {faction_name}",
            description=f"Strategic intelligence on faction's most active combatants",
            color=discord.Color.red()
        )
        
        # Get members and analyze activity
        members = faction_data.get('members', {})
        
        # Sort members by activity (online status)
        online_members = []
        for member_id, member_data in members.items():
            # Check if online now
            if member_data.get('last_action', {}).get('status', '') == 'Online':
                online_members.append({
                    'id': member_id,
                    'name': member_data.get('name', f"Member {member_id}"),
                    'level': member_data.get('level', 0),
                    'status': 'Online'
                })
        
        # Sort by level (as a proxy for threat when we don't have exact stats)
        online_members.sort(key=lambda x: x['level'], reverse=True)
        
        # Add online members field
        if online_members:
            online_text = ""
            for i, member in enumerate(online_members[:5]):  # Show top 5
                online_text += f"**{i+1}.** {member['name']} (ID: {member['id']}) - Level {member['level']}\n"
            
            embed.add_field(
                name=f"🟢 Active Members Now ({len(online_members)})",
                value=online_text if online_text else "None currently online",
                inline=False
            )
        
        # Find members with spy data (these are likely previous targets/threats)
        members_with_spy_data = []
        for member_id in members.keys():
            spy_data = get_spy_data(member_id)
            if spy_data:
                # We have intel on this member
                members_with_spy_data.append({
                    'id': member_id,
                    'name': members[member_id].get('name', f"Member {member_id}"),
                    'stats': spy_data,
                    'total': sum([spy_data.get('strength', 0), spy_data.get('speed', 0),
                                 spy_data.get('dexterity', 0), spy_data.get('defense', 0)])
                })
        
        # Sort by total stats
        members_with_spy_data.sort(key=lambda x: x['total'], reverse=True)
        
        # Add known threats field
        if members_with_spy_data:
            threats_text = ""
            for i, member in enumerate(members_with_spy_data[:5]):  # Show top 5
                threats_text += f"**{i+1}.** {member['name']} - {member['total']:,} total stats\n"
            
            embed.add_field(
                name=f"⚠️ Known Threats ({len(members_with_spy_data)})",
                value=threats_text if threats_text else "No intel on specific threats",
                inline=False
            )
        
        # Attempt to get attack data to find most active attackers
        attacks_data = await fetch_faction_attacks_by(faction_id, api_key, limit=100)
        
        if attacks_data:
            # Count attacks by member
            attacker_counts = {}
            for attack in attacks_data:
                attacker_id = str(attack.get('attacker_id', 0))
                if attacker_id in members:
                    if attacker_id not in attacker_counts:
                        attacker_counts[attacker_id] = {
                            'count': 0,
                            'name': members[attacker_id].get('name', f"Member {attacker_id}"),
                            'id': attacker_id
                        }
                    attacker_counts[attacker_id]['count'] += 1
            
            # Convert to list and sort
            top_attackers = list(attacker_counts.values())
            top_attackers.sort(key=lambda x: x['count'], reverse=True)
            
            # Add top attackers field
            if top_attackers:
                attackers_text = ""
                for i, attacker in enumerate(top_attackers[:5]):  # Show top 5
                    attackers_text += f"**{i+1}.** {attacker['name']} - {attacker['count']} attacks\n"
                
                embed.add_field(
                    name=f"🔥 Most Active Attackers",
                    value=attackers_text if attackers_text else "No recent attack data",
                    inline=False
                )
        
        # Add tracking status
        guild_id = str(ctx.guild.id)
        is_tracked = False
        if guild_id in tracked_enemy_factions and faction_id in tracked_enemy_factions[guild_id]:
            is_tracked = True
        
        embed.add_field(
            name="Tracking Status",
            value=f"{'✅ Currently tracking this faction' if is_tracked else '❌ Not currently tracking'}\n"
                  f"Use `!enemy {faction_id} track` to start tracking",
            inline=False
        )
        
        # Create button view
        class TopHittersView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)  # Buttons active for 5 minutes
                
                # Add button to view faction profile
                faction_button = discord.ui.Button(
                    style=discord.ButtonStyle.link,
                    label="View Faction",
                    url=f"https://www.torn.com/factions.php?step=profile&ID={faction_id}"
                )
                self.add_item(faction_button)
                
                # Add button to track faction if not already tracking
                if not is_tracked:
                    track_button = discord.ui.Button(
                        style=discord.ButtonStyle.danger,
                        label=f"Track This Faction",
                        emoji="🔍",
                        custom_id=f"track_{faction_id}"
                    )
                    track_button.callback = self.track_callback
                    self.add_item(track_button)
                
                # Add refresh button
                refresh_button = discord.ui.Button(
                    style=discord.ButtonStyle.primary,
                    label="Refresh Analysis",
                    emoji="🔄",
                    custom_id=f"refresh_{faction_id}"
                )
                refresh_button.callback = self.refresh_callback
                self.add_item(refresh_button)
            
            async def track_callback(self, interaction):
                await interaction.response.defer()
                await track_enemy_faction(ctx, faction_id)
            
            async def refresh_callback(self, interaction):
                await interaction.response.defer()
                await analyze_top_hitters(ctx, faction_id)
        
        # Set footer
        embed.set_footer(text="Owl Eye Intelligence System | Threat Assessment")
        
        # Delete loading message and send result
        await loading_message.delete()
        await ctx.send(embed=embed, view=TopHittersView())
        
    except Exception as e:
        await loading_message.delete()
        logger.error(f"Error analyzing top hitters: {e}")
        await ctx.send(f"❌ Error analyzing faction top hitters: {str(e)}")

async def list_tracked_enemies(ctx):
    """List all tracked enemy factions"""
    guild_id = str(ctx.guild.id)
    
    if guild_id not in tracked_enemy_factions or not tracked_enemy_factions[guild_id]:
        await ctx.send("No enemy factions are currently being tracked.")
        return
    
    embed = discord.Embed(
        title="Tracked Enemy Factions",
        description="The following factions are being monitored:",
        color=discord.Color.blue()
    )
    
    # Get details for each tracked faction
    api_key = get_user_api_key(ctx.author.id) or TORN_API_KEY
    
    for faction_id in tracked_enemy_factions[guild_id]:
        faction_name = faction_id
        member_count = "?"
        
        # Try to get faction details
        if api_key:
            try:
                faction_data = await fetch_faction_info(faction_id, api_key)
                if faction_data:
                    faction_name = faction_data.get('name', faction_id)
                    member_count = len(faction_data.get('members', {}))
            except:
                pass
        
        embed.add_field(
            name=f"{faction_name} [{faction_id}]",
            value=f"Members: {member_count}\n"
                  f"[View Intel](!enemy {faction_id})",
            inline=True
        )
    
    embed.set_footer(text="Owl Eye Intelligence System")
    await ctx.send(embed=embed)

def save_enemy_tracking():
    """Save enemy faction tracking configuration"""
    try:
        with open('data/enemy_tracking.json', 'w') as f:
            json.dump(tracked_enemy_factions, f)
    except Exception as e:
        logger.error(f"Error saving enemy tracking: {e}")

def load_enemy_tracking():
    """Load enemy faction tracking configuration"""
    global tracked_enemy_factions
    
    try:
        if os.path.exists('data/enemy_tracking.json'):
            with open('data/enemy_tracking.json', 'r') as f:
                tracked_enemy_factions = json.load(f)
    except Exception as e:
        logger.error(f"Error loading enemy tracking: {e}")

async def fetch_faction_info(faction_id, api_key):
    """
    Fetch detailed faction information from Torn API
    
    Args:
        faction_id (str): Faction ID
        api_key (str): Torn API key
        
    Returns:
        dict: Faction information or None if error
    """
    url = f"https://api.torn.com/faction/{faction_id}?selections=basic,stats,territory,members,wars&key={api_key}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if 'error' in data:
                        logger.error(f"Torn API error: {data['error']}")
                        return None
                    return data
                else:
                    logger.error(f"Failed to fetch faction info: HTTP {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Error fetching faction info: {e}")
        return None

async def fetch_faction_attacks_by(faction_id, api_key, limit=5):
    """
    Fetch attacks made by a specific faction
    
    Args:
        faction_id (str): Faction ID
        api_key (str): Torn API key
        limit (int): Maximum number of attacks to return
        
    Returns:
        list: Recent attacks by the faction
    """
    url = f"https://api.torn.com/faction/{faction_id}?selections=attacks&key={api_key}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if 'error' in data:
                        logger.error(f"Torn API error: {data['error']}")
                        return []
                    
                    # Extract and sort attacks
                    attacks = data.get('attacks', {})
                    attack_list = []
                    
                    for attack_id, attack in attacks.items():
                        # Only include attacks by this faction
                        if str(attack.get('attacker_faction', '')) == str(faction_id):
                            attack_list.append(attack)
                    
                    # Sort by timestamp (newest first)
                    attack_list.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
                    
                    # Return only the requested number of attacks
                    return attack_list[:limit]
                else:
                    logger.error(f"Failed to fetch attacks: HTTP {response.status}")
                    return []
    except Exception as e:
        logger.error(f"Error fetching attacks: {e}")
        return []

async def monitor_enemy_faction(guild_id, faction_id):
    """
    Background task to monitor an enemy faction
    
    Args:
        guild_id (int): Discord guild ID
        faction_id (str): Faction ID to monitor
    """
    guild_id_str = str(guild_id)
    
    # Validate tracking status
    if guild_id_str not in tracked_enemy_factions or faction_id not in tracked_enemy_factions[guild_id_str]:
        return
    
    # Get a valid API key
    api_key = TORN_API_KEY
    if not api_key:
        logger.error(f"No API key available for enemy faction monitoring")
        return
        
    # Keep track of previous data for comparison
    last_check_time = int(time.time())
    previous_online_count = 0
    previous_members = set()
    
    # Get own faction ID for comparison
    own_faction_id = None
    try:
        # Try to get guild's primary faction
        own_faction_id = get_guild_faction_id(guild_id)
    except:
        pass
    
    # Loop to check for changes
    while guild_id_str in tracked_enemy_factions and faction_id in tracked_enemy_factions[guild_id_str]:
        try:
            # Fetch faction data
            faction_data = await fetch_faction_info(faction_id, api_key)
            
            if faction_data:
                # Get basic info
                faction_name = faction_data.get('name', 'Unknown')
                
                # Get member info
                members = faction_data.get('members', {})
                current_members = set(members.keys())
                
                # Count online members
                online_members = 0
                for member_id, member in members.items():
                    if member.get('last_action', {}).get('status', '') == 'Online':
                        online_members += 1
                
                # Check for significant changes
                if previous_members:
                    # Check for new members
                    new_members = current_members - previous_members
                    if new_members:
                        # Get guild and find a suitable channel
                        guild = bot.get_guild(int(guild_id_str))
                        if guild:
                            # Find a channel with "intelligence", "war", or "chain" in the name
                            suitable_channel = None
                            for channel in guild.text_channels:
                                if any(keyword in channel.name.lower() for keyword in ['intel', 'war', 'chain', 'enemy']):
                                    suitable_channel = channel
                                    break
                            
                            # If no suitable channel found, try to find a general channel
                            if not suitable_channel:
                                for channel in guild.text_channels:
                                    if channel.name.lower() in ['general', 'chat', 'main']:
                                        suitable_channel = channel
                                        break
                            
                            if suitable_channel:
                                # Format new member alert
                                new_member_names = []
                                for member_id in new_members:
                                    if member_id in members:
                                        new_member_names.append(members[member_id].get('name', f"Unknown [{member_id}]"))
                                
                                if new_member_names:
                                    embed = discord.Embed(
                                        title=f"⚠️ Enemy Faction Alert: New Members",
                                        description=f"Faction {faction_name} [{faction_id}] has new members",
                                        color=discord.Color.gold(),
                                        timestamp=datetime.datetime.now()
                                    )
                                    
                                    embed.add_field(
                                        name="New Members",
                                        value="\n".join([f"• {name}" for name in new_member_names]),
                                        inline=False
                                    )
                                    
                                    embed.set_footer(text="Owl Eye Intelligence System")
                                    
                                    await suitable_channel.send(embed=embed)
                    
                    # Check for big activity spikes
                    if online_members >= previous_online_count + 5:
                        # Significant activity spike - alert if we can find a channel
                        guild = bot.get_guild(int(guild_id_str))
                        if guild:
                            # Find a suitable channel
                            suitable_channel = None
                            for channel in guild.text_channels:
                                if any(keyword in channel.name.lower() for keyword in ['intel', 'war', 'chain', 'enemy']):
                                    suitable_channel = channel
                                    break
                            
                            if suitable_channel:
                                embed = discord.Embed(
                                    title=f"⚠️ Enemy Faction Alert: Activity Spike",
                                    description=f"Faction {faction_name} [{faction_id}] has a significant increase in online members",
                                    color=discord.Color.orange(),
                                    timestamp=datetime.datetime.now()
                                )
                                
                                embed.add_field(
                                    name="Activity Change",
                                    value=f"Previous: {previous_online_count} members online\n"
                                          f"Current: {online_members} members online\n"
                                          f"Increase: +{online_members - previous_online_count} members",
                                    inline=False
                                )
                                
                                if own_faction_id:
                                    embed.add_field(
                                        name="Warning",
                                        value=f"Enemy faction may be preparing to target your faction",
                                        inline=False
                                    )
                                
                                embed.set_footer(text="Owl Eye Intelligence System")
                                
                                await suitable_channel.send(embed=embed)
                
                # Update previous data
                previous_members = current_members
                previous_online_count = online_members
            
            # Wait before checking again (5 minutes)
            await asyncio.sleep(300)
            
        except Exception as e:
            logger.error(f"Error in enemy faction monitoring: {e}")
            await asyncio.sleep(300)  # Wait before trying again

@bot.command(name="hospitalized")
async def hospitalized(ctx, faction_id: str = ""):
    """
    View faction members currently in the hospital
    
    Usage:
    !hospitalized
    !hospitalized <faction_id>
    """
    try:
        if not TORN_API_KEY:
            await ctx.send("⚠️ No API key configured. Please contact an administrator.")
            return
        
        # Inform the user we're fetching data
        loading_message = await ctx.send("🏥 Checking hospital status... Please wait.")
        
        # Here we would fetch hospital data using the Torn API
        embed = discord.Embed(
            title=f"Hospitalized Members",
            description="Hospital status will be fully implemented in the next update",
            color=discord.Color.gold()
        )
        
        embed.add_field(
            name="Hospital Information",
            value="Connect this command to the Torn API to show:\n"
                  "• Members currently hospitalized\n"
                  "• Time remaining\n"
                  "• Reason for hospitalization\n"
                  "• Who attacked them",
            inline=False
        )
        
        embed.add_field(
            name="How to Use",
            value="When fully implemented, this will include:\n"
                  "• Notifications when members are hospitalized\n"
                  "• Revive tracking\n"
                  "• Hospital time analysis\n"
                  "• Enemy patterns of attacks",
            inline=False
        )
        
        embed.set_footer(text="Owl Eye Intelligence System")
        
        # Delete the loading message and send the result
        await loading_message.delete()
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"Error fetching hospital data: {e}")
        await ctx.send(f"❌ Error fetching hospital data: {str(e)}")

def _get_color_for_confidence(confidence):
    """Return a color based on confidence level"""
    colors = {
        "high": discord.Color.green(),
        "medium": discord.Color.gold(),
        "low": discord.Color.orange(),
        "none": discord.Color.red()
    }
    return colors.get(confidence, discord.Color.default())

def main():
    """Main entry point for the bot"""
    try:
        if not TOKEN:
            logger.error("No Discord token found in environment variables.")
            print("Error: DISCORD_TOKEN environment variable not set.")
            return
        
        if not TORN_API_KEY:
            logger.warning("No Torn API key found in environment variables.")
            print("Warning: TORN_API_KEY environment variable not set.")
            
        if not TORNSTATS_API_KEY:
            logger.warning("No TornStats API key found in environment variables.")
            print("Warning: TORNSTATS_API_KEY environment variable not set.")
        
        bot.run(TOKEN)
    except Exception as e:
        logger.error(f"Error running bot: {e}")
        print(f"Error starting bot: {e}")

if __name__ == "__main__":
    main()