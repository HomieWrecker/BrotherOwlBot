// Replit 24/7 Uptime Booster
// This script helps maintain continuous bot operation on Replit
const express = require('express');
const http = require('http');
const https = require('https');
const { exec } = require('child_process');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

// Create Express server
const app = express();
const PORT = 3000; // Use port 3000 for Replit

// Set up a basic endpoint for health checks
app.get('/', (req, res) => {
  res.send('Brother Owl Bot is online!');
});

// Special wake endpoint for UptimeRobot
app.get('/wake', (req, res) => {
  console.log('[UPTIME] Wake request received');
  res.send('Bot woken up');
  pingAndRefresh();
});

// Start server
const server = http.createServer(app);
server.listen(PORT, () => {
  console.log(`[UPTIME] Uptime server running on port ${PORT}`);
});

// List of reliable URLs to ping
const PING_URLS = [
  'https://www.google.com',
  'https://discord.com',
  'https://www.cloudflare.com',
  'https://www.bing.com'
];

// Ping function for healthchecks
async function pingUrl(url) {
  try {
    const response = await fetch(url);
    if (response.ok) {
      console.log(`[UPTIME] Successfully pinged ${url}`);
      return true;
    }
    return false;
  } catch (error) {
    console.error(`[UPTIME] Failed to ping ${url}: ${error.message}`);
    return false;
  }
}

// Check Discord API
async function checkDiscordStatus() {
  try {
    const response = await fetch('https://discord.com/api/v10/gateway');
    return response.ok;
  } catch (error) {
    console.error(`[UPTIME] Discord API check failed: ${error.message}`);
    return false;
  }
}

// Restart both bot processes
function restartBots() {
  console.log('[UPTIME] Attempting to restart bot processes...');
  
  // Restart the Node.js bot
  exec('pkill -f "node index.js" || true', (error) => {
    if (error) {
      console.error(`[UPTIME] Error stopping Node.js bot: ${error}`);
    } else {
      console.log('[UPTIME] Successfully terminated Node.js bot process');
      
      // Start Node.js bot again
      setTimeout(() => {
        exec('node index.js &', (error) => {
          if (error) {
            console.error(`[UPTIME] Error starting Node.js bot: ${error}`);
          } else {
            console.log('[UPTIME] Successfully started Node.js bot');
          }
        });
      }, 2000);
    }
  });
  
  // Restart the Python bot
  exec('pkill -f "python main.py" || true', (error) => {
    if (error) {
      console.error(`[UPTIME] Error stopping Python bot: ${error}`);
    } else {
      console.log('[UPTIME] Successfully terminated Python bot process');
      
      // Start Python bot again
      setTimeout(() => {
        exec('cd bot_package && python main.py &', (error) => {
          if (error) {
            console.error(`[UPTIME] Error starting Python bot: ${error}`);
          } else {
            console.log('[UPTIME] Successfully started Python bot');
          }
        });
      }, 4000);
    }
  });
}

// Ping multiple URLs and refresh bots if needed
async function pingAndRefresh() {
  console.log('[UPTIME] Running health check...');
  
  // Try multiple ping services
  let successCount = 0;
  for (const url of PING_URLS) {
    if (await pingUrl(url)) {
      successCount++;
    }
    
    // Only need to check a couple of URLs
    if (successCount >= 2) break;
  }
  
  // If we couldn't reach any URLs, check Discord API directly
  if (successCount === 0) {
    const discordStatus = await checkDiscordStatus();
    if (!discordStatus) {
      console.log('[UPTIME] No connectivity detected, refreshing bot processes...');
      restartBots();
    }
  }
}

// Set up very frequent monitoring to keep bots alive
setInterval(pingAndRefresh, 15000); // Check every 15 seconds

// Run deep refresh occasionally
setInterval(() => {
  console.log('[UPTIME] Running deep refresh...');
  pingAndRefresh();
}, 5 * 60 * 1000); // Every 5 minutes

console.log('[UPTIME] Bot uptime booster activated');