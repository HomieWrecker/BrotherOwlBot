/**
 * Script to fix ownerID syntax errors in config files
 * Enhanced version with better error detection and logging
 */
const fs = require('fs');
const path = require('path');

// Configure logging
function log(message) {
  console.log(`[FIX] ${message}`);
}

function logError(message, error) {
  console.error(`[ERROR] ${message}`, error || '');
}

// Skip these directories to avoid unnecessary processing
const SKIP_DIRECTORIES = ['node_modules', '.git', '.cache', 'data'];

// Recursive function to search and fix files in directories
function processDirectory(directory) {
  try {
    const items = fs.readdirSync(directory);
    
    for (const item of items) {
      const fullPath = path.join(directory, item);
      
      try {
        const stats = fs.statSync(fullPath);
        
        if (stats.isDirectory()) {
          // Skip excluded directories
          if (!SKIP_DIRECTORIES.includes(item)) {
            processDirectory(fullPath); // Recursively process subdirectories
          }
        } else if (stats.isFile() && 
                  (item.endsWith('.js') || item.endsWith('.json') || 
                   item.endsWith('.config'))) {
          fixOwnerIdInFile(fullPath);
        }
      } catch (err) {
        logError(`Cannot access ${fullPath}:`, err);
      }
    }
  } catch (err) {
    logError(`Error reading directory ${directory}:`, err);
  }
}

// Function to fix ownerId in a file
function fixOwnerIdInFile(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Only process files that might contain ownerId references to save time
    if (content.includes('ownerId') || content.includes('owner_id') || 
        content.includes('OWNER_ID')) {
      
      let originalContent = content;
      
      // Check for specific problematic pattern with ownerId
      // The exact pattern from the Render error
      content = content.replace(/ownerId:\s*''(\d+)"/g, 'ownerId: "$1"');
      
      // More comprehensive pattern matching for various quote issues
      const patterns = [
        // Mixed quotes patterns
        { find: /ownerId:\s*''(\d+)"/g, replace: 'ownerId: "$1"' },   // ''123" -> "123"
        { find: /ownerId:\s*"'(\d+)'/g, replace: 'ownerId: "$1"' },   // "'123' -> "123"
        { find: /ownerId:\s*''(\d+)''/g, replace: 'ownerId: "$1"' },  // ''123'' -> "123"
        { find: /ownerId:\s*""(\d+)""/g, replace: 'ownerId: "$1"' },  // ""123"" -> "123"
        { find: /ownerId:\s*'(\d+)'/g, replace: 'ownerId: "$1"' },    // '123' -> "123"
        
        // owner_id variations
        { find: /owner_id:\s*''(\d+)"/g, replace: 'owner_id: "$1"' },
        { find: /owner_id:\s*"'(\d+)'/g, replace: 'owner_id: "$1"' },
        { find: /owner_id:\s*''(\d+)''/g, replace: 'owner_id: "$1"' },
        { find: /owner_id:\s*""(\d+)""/g, replace: 'owner_id: "$1"' },
        { find: /owner_id:\s*'(\d+)'/g, replace: 'owner_id: "$1"' },
        
        // OWNER_ID variations
        { find: /OWNER_ID:\s*''(\d+)"/g, replace: 'OWNER_ID: "$1"' },
        { find: /OWNER_ID:\s*"'(\d+)'/g, replace: 'OWNER_ID: "$1"' },
        { find: /OWNER_ID:\s*''(\d+)''/g, replace: 'OWNER_ID: "$1"' },
        { find: /OWNER_ID:\s*""(\d+)""/g, replace: 'OWNER_ID: "$1"' },
        { find: /OWNER_ID:\s*'(\d+)'/g, replace: 'OWNER_ID: "$1"' }
      ];
      
      // Apply each pattern
      for (const pattern of patterns) {
        content = content.replace(pattern.find, pattern.replace);
      }
      
      // Fix specific errors in configuration objects
      if (content.includes("config") && content.includes("owner")) {
        // Direct replacement of known problematic patterns in config objects
        content = content.replace(/(['"])(\d+)(?:"|')?/g, (match, quote, id) => {
          // Only replace if quotes don't match or are unbalanced
          if (!match.endsWith(quote)) {
            return `"${id}"`;
          }
          return match;
        });
      }
      
      // Check if anything was changed
      if (content !== originalContent) {
        log(`Fixed owner ID in: ${filePath}`);
        fs.writeFileSync(filePath, content, 'utf8');
      }
    }
  } catch (error) {
    logError(`Error processing file ${filePath}:`, error);
  }
}

// Direct function to check specific files known to contain owner IDs
function checkSpecificFiles() {
  const knownFiles = [
    './src/config.js',
    './src/config/config.js',
    './config.js',
    './index.js',
    './bot.js',
    './src/bot.js'
  ];
  
  for (const file of knownFiles) {
    try {
      if (fs.existsSync(file)) {
        log(`Checking known config file: ${file}`);
        fixOwnerIdInFile(file);
      }
    } catch (err) {
      logError(`Error checking specific file ${file}:`, err);
    }
  }
}

// Run the fix operation
function runFixes() {
  log("Starting to fix owner ID syntax issues...");
  
  // First check specific files that are likely to contain config
  checkSpecificFiles();
  
  // Then do a full directory scan
  processDirectory('.');
  
  log("Completed checking for owner ID syntax issues");
}

// Execute fix if run directly
if (require.main === module) {
  runFixes();
}

// Export for use in other modules
module.exports = { runFixes };