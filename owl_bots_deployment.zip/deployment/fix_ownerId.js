/**
 * Script to fix ownerID syntax errors in config files
 */
const fs = require('fs');
const path = require('path');

// Recursive function to search and fix files in directories
function processDirectory(directory) {
  const items = fs.readdirSync(directory);
  
  for (const item of items) {
    const fullPath = path.join(directory, item);
    const stats = fs.statSync(fullPath);
    
    if (stats.isDirectory()) {
      processDirectory(fullPath); // Recursively process subdirectories
    } else if (stats.isFile() && item.endsWith('.js')) {
      fixOwnerIdInFile(fullPath);
    }
  }
}

// Function to fix ownerId in a file
function fixOwnerIdInFile(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    let originalContent = content;
    
    // Check for specific problematic pattern with 893004402028331039
    // The pattern we're looking for based on the error
    const specificPattern = /ownerId:\s*''893004402028331039"/g;
    content = content.replace(specificPattern, 'ownerId: "893004402028331039"');
    
    // Also check for more general patterns
    const patterns = [
      /ownerId:\s*''([0-9]+)"/g,   // ''123" - single quotes with ending double quote
      /ownerId:\s*"'([0-9]+)'/g,   // "'123' - double quote with single quotes
      /ownerId:\s*''([0-9]+)''/g,  // ''123'' - double single quotes
      /ownerId:\s*""([0-9]+)""/g,  // ""123"" - double double quotes
      /ownerId:\s*'([0-9]+)'/g     // '123' - single quotes to double quotes
    ];
    
    for (const pattern of patterns) {
      content = content.replace(pattern, 'ownerId: "$1"');
    }
    
    // Check if anything was changed
    if (content !== originalContent) {
      console.log(`Fixed ownerId in: ${filePath}`);
      fs.writeFileSync(filePath, content, 'utf8');
    }
  } catch (error) {
    console.error(`Error processing file ${filePath}: ${error.message}`);
  }
}

// Additional function to perform broader text search
function findOwnerIdReferences() {
  console.log("Searching for all ownerId references...");
  
  const findProcess = require('child_process').spawnSync(
    'grep', 
    ['-r', 'ownerId', '--include=*.js', '.'],
    { encoding: 'utf8' }
  );
  
  if (findProcess.stdout) {
    const lines = findProcess.stdout.split('\n').filter(line => line.trim() !== '');
    
    for (const line of lines) {
      const parts = line.split(':');
      if (parts.length >= 2) {
        const filePath = parts[0];
        // Skip node_modules
        if (!filePath.includes('node_modules')) {
          console.log(`Found reference in: ${filePath}`);
          fixOwnerIdInFile(filePath);
        }
      }
    }
  }
}

// Main execution
console.log("Starting to fix ownerId syntax issues...");
processDirectory('.');
findOwnerIdReferences();
console.log("Completed checking for ownerId syntax issues");