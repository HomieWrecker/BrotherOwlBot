// Entry point for the Brother Owl Discord bot
const { startBot } = require('./src/bot');
const { log, logError } = require('./src/utils/logger');
const fs = require('fs');
const path = require('path');
const express = require('express');
const keepalive = require('./keepalive');

// Setup a specialized express server for Replit 24/7 uptime
const app = express();
const port = 5001; // Use a dedicated port for BrotherOwl

// Special root endpoint with HTML status page
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Brother Owl Discord Bot</title>
        <meta http-equiv="refresh" content="30">
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; color: #333; }
          .container { max-width: 800px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
          h1 { color: #5865F2; text-align: center; }
          .status { padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center; }
          .online { background-color: #d4edda; color: #155724; }
          .info { background-color: #e9ecef; padding: 15px; border-radius: 5px; }
          footer { text-align: center; margin-top: 30px; font-size: 0.8em; color: #777; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>Brother Owl Discord Bot</h1>
          <div class="status online">
            <h2>Status: ONLINE</h2>
            <p>The bot is currently running</p>
            <p>Uptime: ${Math.floor(process.uptime() / 60)} minutes</p>
          </div>
          <div class="info">
            <p>This page helps keep the bot running 24/7 on Replit. For UptimeRobot, use the /wake endpoint.</p>
            <p>Last checked: ${new Date().toLocaleString()}</p>
          </div>
          <footer>
            Brother Owl Bot - Grand Code Discord
          </footer>
        </div>
      </body>
    </html>
  `);
});

// Special endpoint for UptimeRobot pings
app.get('/wake', (req, res) => {
  log(`Received wake request from ${req.headers['user-agent'] || 'unknown user agent'}`);
  res.send('OK');
  
  // Force activity on bot to keep it alive
  keepalive.heartbeat();
});

app.listen(port, () => {
  log(`Web server running on port ${port} to keep the bot alive`);
});

// Create data directory if it doesn't exist
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
  log('Created data directory');
}

// Automatic restart logic for resilience
let restartAttempts = 0;
const MAX_RESTART_ATTEMPTS = 10;
const RESTART_DELAY = 30000; // 30 seconds
const RESTART_RESET_TIMEOUT = 3600000; // 1 hour

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  logError('Uncaught Exception:', error);
  attemptRestart('uncaught exception');
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  logError('Unhandled Rejection at:', promise, 'reason:', reason);
  // Not restarting for unhandled rejections as they may not be fatal
});

// Main startup function with error recovery
function startup() {
  try {
    // Start the bot
    log('Starting Brother Owl Discord bot...');
    startBot();
    
    // Print deployment guidance
    log('-----------------------------------');
    log('DEPLOYMENT INFORMATION:');
    log('Running on a custom server (suitable for Synology NAS)');
    log('Required environment variables:');
    log('- DISCORD_TOKEN: Your Discord bot token');
    log('-----------------------------------');
    
  } catch (error) {
    logError('Critical startup error:', error);
    attemptRestart('critical startup error');
  }
}

// Attempt to restart the bot with exponential backoff
function attemptRestart(reason) {
  if (restartAttempts < MAX_RESTART_ATTEMPTS) {
    restartAttempts++;
    const delay = RESTART_DELAY * Math.pow(2, restartAttempts - 1);
    log(`Attempting restart ${restartAttempts}/${MAX_RESTART_ATTEMPTS} in ${delay/1000} seconds due to ${reason}`);
    
    setTimeout(() => {
      log('Executing scheduled restart...');
      startup();
    }, delay);
    
    // Set up a timer to reset the restart attempts counter after a period of stability
    if (restartAttempts === 1) {
      setTimeout(() => {
        if (restartAttempts > 0) {
          log(`Resetting restart attempts counter after ${RESTART_RESET_TIMEOUT/60000} minutes of stability`);
          restartAttempts = 0;
        }
      }, RESTART_RESET_TIMEOUT);
    }
  } else {
    logError(`Maximum restart attempts (${MAX_RESTART_ATTEMPTS}) reached. Please check the logs and restart manually.`);
    
    // Last resort: Try one more restart after a longer delay
    setTimeout(() => {
      log('Attempting emergency restart after maximum attempts reached...');
      restartAttempts = 0;
      startup();
    }, RESTART_DELAY * 5);
  }
}

// Process termination handling
process.on('SIGINT', () => {
  log('Received SIGINT. Shutting down gracefully...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('Received SIGTERM. Shutting down gracefully...');
  process.exit(0);
});

// Activate the keepalive module
keepalive.activate();

// Start the application
startup();
