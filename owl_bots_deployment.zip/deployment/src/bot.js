const { Client, GatewayIntentBits, ActivityType, Events, Collection } = require('discord.js');
const { registerCommands } = require('./commands/index');
const { log, logError } = require('./utils/logger');
const { BOT_CONFIG } = require('./config');
const path = require('path');
const fs = require('fs');

// Load services
let welcomeService = null;
let rolePermissions = null;
let giveawayService = null;
let eventService = null;

try {
  welcomeService = require('./services/welcome-service');
  log('Welcome service loaded');
} catch (error) {
  logError('Error loading welcome service:', error);
}

try {
  rolePermissions = require('./services/role-permissions');
  log('Role permissions service loaded');
} catch (error) {
  logError('Error loading role permissions service:', error);
}

try {
  giveawayService = require('./services/giveaway-service');
  log('Giveaway service loaded');
} catch (error) {
  logError('Error loading giveaway service:', error);
}

try {
  eventService = require('./services/event-service');
  log('Event service loaded');
} catch (error) {
  logError('Error loading event service:', error);
}

// Discord client with required intents
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    // Additional intents for welcome system
    GatewayIntentBits.GuildMembers, // Needed to detect member join/leave events
    // Additional intents for giveaway system
    GatewayIntentBits.GuildMessageReactions, // Needed for reaction-based giveaways
    GatewayIntentBits.DirectMessages // Needed for DM notifications
  ],
  partials: ['MESSAGE', 'CHANNEL', 'REACTION'] // Required for reaction events on uncached messages
});

// Initialize commands collection
client.commands = new Collection();

/**
 * Starts the Discord bot and connects all services
 */
function startBot() {
  // Handle bot ready event
  client.once(Events.ClientReady, async () => {
    log(`Logged in as ${client.user.tag}`);
    
    // Set bot activity
    client.user.setActivity(`Torn Factions | ${BOT_CONFIG.name}`, { type: ActivityType.Watching });
    
    // Register slash commands
    try {
      await registerCommands(client);
      log('Slash commands registered successfully');
    } catch (error) {
      logError('Failed to register slash commands:', error);
    }
    
    // Initialize welcome service if available
    if (welcomeService && welcomeService.initWelcomeService) {
      try {
        welcomeService.initWelcomeService(client);
        log('Welcome service initialized');
      } catch (error) {
        logError('Failed to initialize welcome service:', error);
      }
    }
    
    // Initialize giveaway service if available
    if (giveawayService && giveawayService.initializeGiveawayService) {
      try {
        await giveawayService.initializeGiveawayService(client);
        log('Giveaway service initialized');
      } catch (error) {
        logError('Failed to initialize giveaway service:', error);
      }
    }
    
    // Initialize event service if available
    if (eventService && eventService.initEventService) {
      try {
        // Store client for event service to use for reminders
        global.discordClient = client;
        eventService.initEventService(client);
        log('Event service initialized');
      } catch (error) {
        logError('Failed to initialize event service:', error);
      }
    }
  });

  // Handle slash command interactions
  client.on(Events.InteractionCreate, async (interaction) => {
    // Log ALL interactions for monitoring
    try {
      log(`Received interaction: ${interaction.type} from ${interaction.user.tag}`);
    } catch (e) {
      log(`Received interaction but couldn't log details: ${e.message}`);
    }
    
    // Handle slash commands
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      
      if (!command) {
        log(`Command not found: ${interaction.commandName}`);
        return;
      }
      
      // Log all commands for monitoring
      log(`Received command: ${interaction.commandName} from ${interaction.user.tag}`);
      
      try {
        // Skip permission check for ping command
        if (interaction.commandName === 'ping') {
          log('Executing ping command immediately...');
          await command.execute(interaction, client);
          return;
        }
        
        // Check permissions if role permissions service is available
        if (rolePermissions && interaction.guild) {
          const member = interaction.member;
          
          // Skip permission check for botpermissions command (admin only)
          if (interaction.commandName !== 'botpermissions') {
            log(`Checking permissions for ${interaction.commandName}...`);
            const userRoleIds = member.roles.cache.map(role => role.id);
            log(`User roles: ${userRoleIds.join(', ')}`);
            
            const hasPermission = await rolePermissions.hasPermission(
              interaction.guildId, 
              userRoleIds, 
              interaction.commandName
            );
            
            log(`Permission check result for ${interaction.commandName}: ${hasPermission}`);
            
            if (!hasPermission) {
              log(`Permission denied for ${interaction.user.tag} to use ${interaction.commandName}`);
              await interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
              });
              return;
            }
          }
        }
        
        log(`Executing command: ${interaction.commandName}`);
        await command.execute(interaction, client);
      } catch (error) {
        logError(`Error executing ${interaction.commandName} command:`, error);
        
        // Handle errors in responding to the interaction
        const errorResponse = {
          content: '❌ There was an error while executing this command.',
          ephemeral: true
        };
        
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(errorResponse).catch(err => 
            logError('Error sending error followUp:', err)
          );
        } else {
          await interaction.reply(errorResponse).catch(err => 
            logError('Error sending error reply:', err)
          );
        }
      }
    }
    
    // Handle select menu interactions
    if (interaction.isStringSelectMenu()) {
      log(`Select menu interaction received: ${interaction.customId}`);
      
      try {
        // Handle bank menu options
        if (interaction.customId === 'bank_options') {
          log(`Handling bank options menu: ${interaction.values[0]}`);
          const bankCommand = client.commands.get('bank');
          
          if (bankCommand && bankCommand.handleSelectMenu) {
            try {
              await bankCommand.handleSelectMenu(interaction, client);
            } catch (bankError) {
              logError('Error in bank select menu handler:', bankError);
              if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                  content: '❌ There was an error processing your bank option. Please try again later.',
                  ephemeral: true
                }).catch(e => logError('Failed to send error reply:', e));
              }
            }
          }
        }
        // Handle welcome menu options
        else if (interaction.customId === 'welcome_role') {
          log(`Handling welcome role selection: ${interaction.values[0]}`);
          const welcomeCommand = client.commands.get('welcome');
          
          if (welcomeCommand && welcomeCommand.handleSelectMenu) {
            try {
              await welcomeCommand.handleSelectMenu(interaction, client);
            } catch (welcomeError) {
              logError('Error in welcome select menu handler:', welcomeError);
              if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                  content: '❌ There was an error processing your welcome role selection. Please try again later.',
                  ephemeral: true
                }).catch(e => logError('Failed to send error reply:', e));
              }
            }
          }
        }
      } catch (error) {
        logError('Error handling select menu interaction:', error);
      }
    }
    
    // Handle button interactions
    if (interaction.isButton()) {
      log(`Button interaction received: ${interaction.customId}`);
      
      try {
        // Handle welcome-related buttons
        if (interaction.customId.startsWith('welcome_')) {
          const welcomeCommand = client.commands.get('welcome');
          if (welcomeCommand && welcomeCommand.handleButton) {
            try {
              await welcomeCommand.handleButton(interaction, client);
            } catch (error) {
              logError('Error in welcome button handler:', error);
            }
          }
        }
        // Handle bank-related buttons
        else if (interaction.customId === 'bank_withdraw' || 
                 interaction.customId.startsWith('bank_fulfill_') || 
                 interaction.customId.startsWith('bank_cancel_')) {
          const bankCommand = client.commands.get('bank');
          if (bankCommand && bankCommand.handleButton) {
            try {
              await bankCommand.handleButton(interaction, client);
            } catch (error) {
              logError('Error in bank button handler:', error);
            }
          }
        }
        // Handle giveaway-related buttons
        else if (interaction.customId.startsWith('giveaway_')) {
          const giveawayCommand = client.commands.get('giveaway');
          if (giveawayCommand && giveawayCommand.handleButton) {
            try {
              await giveawayCommand.handleButton(interaction, client);
            } catch (error) {
              logError('Error in giveaway button handler:', error);
            }
          }
        }
        // Handle event-related buttons
        else if (interaction.customId.startsWith('event_')) {
          const eventsCommand = client.commands.get('events');
          if (eventsCommand && eventsCommand.handleButton) {
            try {
              await eventsCommand.handleButton(interaction, client);
            } catch (error) {
              logError('Error in events button handler:', error);
            }
          }
        }
      } catch (error) {
        logError('Error handling button interaction:', error);
      }
    }
    
    // Handle modal submissions
    if (interaction.isModalSubmit()) {
      log(`Modal submission received: ${interaction.customId}`);
      
      try {
        // Handle API key modal submissions
        if (interaction.customId.startsWith('apikey_')) {
          const apikeyCommand = client.commands.get('apikey');
          if (apikeyCommand && apikeyCommand.handleModal) {
            try {
              await apikeyCommand.handleModal(interaction, client);
            } catch (error) {
              logError('Error handling API key modal:', error);
            }
          }
        }
        // Handle bank modal submissions
        else if (interaction.customId.startsWith('bank_')) {
          const bankCommand = client.commands.get('bank');
          if (bankCommand && bankCommand.handleModal) {
            try {
              await bankCommand.handleModal(interaction, client);
            } catch (error) {
              logError('Error handling bank modal:', error);
            }
          }
        }
      } catch (error) {
        logError('Error handling modal submission:', error);
      }
    }
  });

  // Add error handlers for uncaught exceptions
  process.on('uncaughtException', (error) => {
    logError('Uncaught exception:', error);
  });
  
  process.on('unhandledRejection', (error) => {
    logError('Unhandled promise rejection:', error);
  });

  // Connect to Discord
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    logError('Missing Discord token in environment variables');
    return;
  }
  
  log('Attempting to connect to Discord...');
  
  // Robust login with heartbeat and reconnect mechanism
  let loginAttempts = 0;
  const maxLoginAttempts = 5; // Increased for resilience
  const loginDelay = 5000; // 5 seconds
  
  // Add a heartbeat function to keep the connection alive
  const heartbeat = () => {
    // Update presence status occasionally to send data over connection
    client.user?.setPresence({
      activities: [{ name: `Torn Factions | ${BOT_CONFIG.name}`, type: ActivityType.Watching }],
      status: 'online',
    });
  };
  
  // Set up reconnection handler for disconnects
  client.on('disconnect', (event) => {
    logError(`Bot disconnected from Discord! Code: ${event?.code}, Reason: ${event?.reason}`);
    log('Attempting to reconnect in 10 seconds...');
    setTimeout(attemptLogin, 10000);
  });
  
  client.on('error', (error) => {
    logError('Discord client error:', error);
    // Only attempt reconnection if we're actually disconnected
    if (!client.ws?.ready) {
      log('Connection error detected, attempting to reconnect in 15 seconds...');
      setTimeout(attemptLogin, 15000);
    }
  });
  
  // Setup periodic heartbeats to maintain connection
  setInterval(() => {
    if (client.ws?.ready) {
      heartbeat();
      log('Sent heartbeat to Discord - connection active');
    } else {
      logError('Connection to Discord appears down, attempting to reconnect...');
      attemptLogin();
    }
  }, 30000); // Every 30 seconds
  
  const attemptLogin = () => {
    // Only attempt login if we're not already connected
    if (client.ws?.ready) {
      log('Already connected to Discord, skipping login attempt');
      return;
    }
    
    loginAttempts++;
    log(`Login attempt ${loginAttempts}/${maxLoginAttempts}`);
    
    client.login(token).then(() => {
      log('Successfully logged in to Discord');
      loginAttempts = 0; // Reset counter on success
      
      // Start heartbeat on successful connection
      heartbeat();
    }).catch(error => {
      logError(`Failed to login to Discord (attempt ${loginAttempts}/${maxLoginAttempts}):`, error);
      
      if (loginAttempts < maxLoginAttempts) {
        const nextDelay = loginDelay * Math.pow(1.5, loginAttempts-1); // Exponential backoff
        log(`Retrying login in ${nextDelay/1000} seconds...`);
        setTimeout(attemptLogin, nextDelay);
      } else {
        logError('Maximum login attempts reached. Entering recovery mode...');
        
        // Reset counter and retry after longer delay
        loginAttempts = 0;
        setTimeout(attemptLogin, 60000); // 1 minute
      }
    });
  };
  
  attemptLogin();
}

// Export functions for use in other modules
module.exports = {
  startBot,
  client
};