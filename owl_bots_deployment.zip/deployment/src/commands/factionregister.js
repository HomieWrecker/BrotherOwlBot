const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { log, logError } = require('../utils/logger');
const { BOT_CONFIG } = require('../config');
const keyStorageService = require('../services/key-storage-service');
const statTrackerService = require('../services/stat-tracker-service');

const factionRegisterCommand = {
  data: new SlashCommandBuilder()
    .setName('factionregister')
    .setDescription('Register your faction with Brother Owl')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(option =>
      option
        .setName('faction_id')
        .setDescription('Your faction ID in Torn (leave empty to auto-detect)')
        .setRequired(false)
    )
    .addStringOption(option =>
      option
        .setName('faction_name')
        .setDescription('Your faction name (leave empty to auto-detect)')
        .setRequired(false)
    ),

  /**
   * Execute command
   * @param {CommandInteraction} interaction - Discord interaction object
   * @param {Client} client - Discord client
   */
  async execute(interaction, client) {
    try {
      // Get user's API key first
      const adminMember = interaction.member;
      const apiKey = await keyStorageService.getApiKey(adminMember.id, 'torn');
      
      if (!apiKey) {
        return interaction.reply({
          content: '❌ You need to set your API key first with `/apikey` to use this command.',
          ephemeral: true
        });
      }
      
      // Check if manually provided or auto-detect
      let factionId = interaction.options.getString('faction_id');
      let factionName = interaction.options.getString('faction_name');
      const autoDetect = !factionId && !factionName;
      
      if (autoDetect) {
        // Defer reply while we fetch data
        await interaction.deferReply();
        
        try {
          // Fetch user data to get faction information
          const userResponse = await fetch(`https://api.torn.com/user/?selections=basic,profile&key=${apiKey}`);
          const userData = await userResponse.json();
          
          if (userData.error) {
            return interaction.editReply(`❌ Error fetching your user data: ${userData.error.error}`);
          }
          
          if (!userData.faction || !userData.faction.faction_id) {
            return interaction.editReply('❌ You do not appear to be in a faction. Please provide faction information manually.');
          }
          
          // Set faction details from user data
          factionId = userData.faction.faction_id.toString();
          factionName = userData.faction.faction_name;
          
          // Fetch more detailed faction data
          const factionResponse = await fetch(`https://api.torn.com/faction/${factionId}?selections=basic&key=${apiKey}`);
          const factionData = await factionResponse.json();
          
          if (!factionData.error) {
            // Check if user is a faction leader or co-leader
            if (userData.player_id != factionData.leader && userData.player_id != factionData.co_leader) {
              await interaction.editReply({
                content: `⚠️ **Note:** You are not the faction leader or co-leader of ${factionName}. Are you sure you want to configure this server for this faction?`,
                components: [
                  new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                      .setCustomId('confirm_faction_register')
                      .setLabel('Yes, Continue Setup')
                      .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                      .setCustomId('cancel_faction_register')
                      .setLabel('Cancel Setup')
                      .setStyle(ButtonStyle.Secondary)
                  )
                ]
              });
              
              // Wait for button response (handled in handleButton function)
              return;
            }
          }
        } catch (error) {
          logError('Error auto-detecting faction:', error);
          return interaction.editReply('❌ Error auto-detecting your faction. Please try again or provide faction information manually.');
        }
      }
      
      // If we got here without faction ID or name, something went wrong with auto-detection
      if (!factionId || !factionName) {
        return interaction.reply({
          content: '❌ Please provide both faction ID and name, or leave both empty to auto-detect.',
          ephemeral: true
        });
      }
      
      // Validate faction ID format (numeric)
      if (!/^\d+$/.test(factionId)) {
        return interaction.reply({
          content: '❌ Faction ID must be a numeric value.',
          ephemeral: true
        });
      }
      
      // If we used deferReply for auto-detection, we need to use editReply, otherwise use reply
      const replyMethod = interaction.deferred ? 'editReply' : 'reply';
      
      // Register the faction
      await registerFaction(interaction, factionId, factionName, apiKey, replyMethod);
      
    } catch (error) {
      logError('Error in faction registration command:', error);
      const replyMethod = interaction.deferred ? 'editReply' : 'reply';
      await interaction[replyMethod]({
        content: '❌ An error occurred while registering your faction. Please try again later.'
      });
    }
  },

  /**
   * Handle button interactions
   * @param {ButtonInteraction} interaction 
   * @param {Client} client 
   */
  async handleButton(interaction, client) {
    const { customId } = interaction;
    
    if (customId === 'confirm_faction_register') {
      await completeFactionRegistration(interaction);
    } else if (customId === 'cancel_faction_register') {
      await interaction.update({
        content: '❌ Faction registration cancelled.',
        components: []
      });
    }
  }
};

/**
 * Register a faction with the bot
 * @param {CommandInteraction} interaction - Command interaction
 * @param {string} factionId - Faction ID
 * @param {string} factionName - Faction name
 * @param {string} apiKey - User's API key
 * @param {string} replyMethod - Method to use for replying
 */
async function registerFaction(interaction, factionId, factionName, apiKey, replyMethod) {
  // Save faction info to database
  const factionData = {
    id: factionId,
    name: factionName,
    server_id: interaction.guildId
  };

  const success = await statTrackerService.storeFactionInfo(factionId, factionData);

  if (!success) {
    return interaction[replyMethod]({
      content: '❌ Failed to save faction information. Please try again later.'
    });
  }

  // Fetch more detailed faction data from API
  try {
    // Fetch faction info from Torn API
    const response = await fetch(`https://api.torn.com/faction/${factionId}?selections=basic&key=${apiKey}`);
    const data = await response.json();

    if (!data.error) {
      // Update with real faction data
      const updatedFactionData = {
        ...factionData,
        name: data.name || factionName,
        tag: data.tag || null,
        leader_id: data.leader || null,
        leader_name: data.leader_name || null,
        co_leader_id: data.co_leader || null,
        co_leader_name: data.co_leader_name || null,
        member_count: data.members ? Object.keys(data.members).length : 0
      };

      await statTrackerService.storeFactionInfo(factionId, updatedFactionData);
    }
  } catch (apiError) {
    // Continue anyway, we already have the basic info
    logError('Error fetching faction data from API:', apiError);
  }

  // Send success message
  const embed = new EmbedBuilder()
    .setTitle('Faction Registration Complete')
    .setColor(BOT_CONFIG.color)
    .addFields(
      { name: 'Faction ID', value: factionId },
      { name: 'Faction Name', value: factionName }
    )
    .setDescription('Your faction has been registered with Brother Owl. All faction-specific commands are now available.')
    .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` });

  await interaction[replyMethod]({
    embeds: [embed]
  });
}

/**
 * Complete faction registration after confirmation
 * @param {ButtonInteraction} interaction - Button interaction
 */
async function completeFactionRegistration(interaction) {
  try {
    // Get message content to extract faction name
    const message = interaction.message;
    const content = message.content;
    
    // Extract faction name from the message
    const factionNameMatch = content.match(/You are not the faction leader or co-leader of ([^.]+)/);
    if (!factionNameMatch) {
      return interaction.update({
        content: '❌ Error processing faction registration. Please try again with the /factionregister command.',
        components: []
      });
    }
    
    const factionName = factionNameMatch[1].trim();
    
    // Get user's API key
    const apiKey = await keyStorageService.getApiKey(interaction.user.id, 'torn');
    if (!apiKey) {
      return interaction.update({
        content: '❌ Your API key could not be found. Please set it up again with /apikey before continuing.',
        components: []
      });
    }
    
    // Fetch user data to get faction ID
    const userResponse = await fetch(`https://api.torn.com/user/?selections=basic,profile&key=${apiKey}`);
    const userData = await userResponse.json();
    
    if (userData.error) {
      return interaction.update({
        content: `❌ Error fetching your user data: ${userData.error.error}`,
        components: []
      });
    }
    
    if (!userData.faction || !userData.faction.faction_id) {
      return interaction.update({
        content: '❌ Could not determine your faction ID. Please use /factionregister and provide it manually.',
        components: []
      });
    }
    
    const factionId = userData.faction.faction_id.toString();
    
    // Save faction info to database
    const factionData = {
      id: factionId,
      name: factionName,
      server_id: interaction.guildId
    };
    
    const success = await statTrackerService.storeFactionInfo(factionId, factionData);
    
    if (!success) {
      return interaction.update({
        content: '❌ Failed to save faction information. Please try again later.',
        components: []
      });
    }
    
    // Fetch more detailed faction data
    try {
      const response = await fetch(`https://api.torn.com/faction/${factionId}?selections=basic&key=${apiKey}`);
      const data = await response.json();
      
      if (!data.error) {
        // Update with real faction data
        const updatedFactionData = {
          ...factionData,
          name: data.name || factionName,
          tag: data.tag || null,
          leader_id: data.leader || null,
          leader_name: data.leader_name || null,
          co_leader_id: data.co_leader || null,
          co_leader_name: data.co_leader_name || null,
          member_count: data.members ? Object.keys(data.members).length : 0
        };
        
        await statTrackerService.storeFactionInfo(factionId, updatedFactionData);
      }
    } catch (apiError) {
      // Continue anyway, we already have the basic info
      logError('Error fetching faction data from API:', apiError);
    }
    
    // Send success message
    const embed = new EmbedBuilder()
      .setTitle('Faction Registration Complete')
      .setColor(BOT_CONFIG.color)
      .addFields(
        { name: 'Faction ID', value: factionId },
        { name: 'Faction Name', value: factionName }
      )
      .setDescription('Your faction has been registered with Brother Owl. All faction-specific commands are now available.')
      .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` });
    
    await interaction.update({
      content: null,
      embeds: [embed],
      components: []
    });
    
  } catch (error) {
    logError('Error completing faction registration:', error);
    await interaction.update({
      content: '❌ An error occurred while registering your faction. Please try again later.',
      components: []
    });
  }
}

module.exports = factionRegisterCommand;