const { REST, Routes } = require('discord.js');
const { log, logError } = require('../utils/logger');
const fs = require('fs');
const path = require('path');

// Get all command files
const commandsPath = path.join(__dirname);
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js') && file !== 'index.js');

// Collection of commands to register
const commands = [];
log(`Found ${commandFiles.length} command files in directory`);

// Load each command from its file
for (const file of commandFiles) {
  try {
    const commandPath = path.join(commandsPath, file);
    const command = require(commandPath);
    
    // Check that command has the required structure
    if (command && command.data) {
      commands.push(command);
      log(`Loaded ${command.data.name} command`);
    } else {
      logError(`Command file ${file} is missing required properties`);
    }
  } catch (error) {
    logError(`Error loading command file ${file}:`, error);
  }
}

/**
 * Registers all slash commands with Discord API
 * @param {Client} client - Discord client instance
 */
async function registerCommands(client) {
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
  
  // Clear client commands collection first
  client.commands.clear();
  
  // Add commands to client collection
  for (const command of commands) {
    log(`Adding command to collection: ${command.data.name}`);
    client.commands.set(command.data.name, command);
  }
  
  // Format commands for REST API
  const commandsData = commands.map(command => command.data.toJSON());

  try {
    log(`Registering ${commands.length} application (/) commands globally`);
    
    // Global command registration
    const data = await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commandsData }
    );
    
    log(`Successfully registered ${data.length} application commands`);
    
    // Log the names of registered commands
    const registeredCommands = Array.isArray(data) ? data.map(cmd => cmd.name).join(', ') : 'Unknown';
    log(`Registered commands: ${registeredCommands}`);
    
    // Check for the test command specifically
    if (client.commands.has('test')) {
      log('Test command is available in the client collection');
    } else {
      logError('Test command is missing from the client collection!');
    }
    
    // Check for the ping command specifically
    if (client.commands.has('ping')) {
      log('Ping command is available in the client collection');
    } else {
      logError('Ping command is missing from the client collection!');
    }
  } catch (error) {
    logError('Error registering commands:', error);
    throw error;
  }
}

module.exports = { registerCommands };
