const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { log, logError } = require('../utils/logger');
const { BOT_CONFIG } = require('../config');
const keyStorageService = require('../services/key-storage-service');
const { setBankConfig } = require('../services/bank-service');
const statTrackerService = require('../services/stat-tracker-service');

const factionSetupCommand = {
  data: new SlashCommandBuilder()
    .setName('factionsetup')
    .setDescription('Set up faction configuration for this server')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(subcommand =>
      subcommand
        .setName('bank')
        .setDescription('Configure the faction bank system')
        .addChannelOption(option =>
          option
            .setName('notifications')
            .setDescription('Channel for bank notifications')
            .setRequired(true)
            .addChannelTypes(ChannelType.GuildText)
        )
        .addRoleOption(option =>
          option
            .setName('banker')
            .setDescription('Role for faction bankers')
            .setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('info')
        .setDescription('Set the faction info for this server')
        .addStringOption(option =>
          option
            .setName('faction_id')
            .setDescription('Your faction ID in Torn (leave empty to auto-detect)')
            .setRequired(false)
        )
        .addStringOption(option =>
          option
            .setName('faction_name')
            .setDescription('Your faction name (leave empty to auto-detect)')
            .setRequired(false)
        )
        .addBooleanOption(option =>
          option
            .setName('autodetect')
            .setDescription('Automatically detect your faction info from your API key')
            .setRequired(false)
        )
    ),

  /**
   * Execute command
   * @param {CommandInteraction} interaction - Discord interaction object
   * @param {Client} client - Discord client
   */
  async execute(interaction, client) {
    const subcommand = interaction.options.getSubcommand();
    const { guildId } = interaction;

    if (subcommand === 'bank') {
      await setupBankSystem(interaction);
    } else if (subcommand === 'info') {
      await setupFactionInfo(interaction);
    }
  },

  /**
   * Handle button interactions
   * @param {ButtonInteraction} interaction 
   * @param {Client} client 
   */
  async handleButton(interaction, client) {
    const { customId } = interaction;
    
    if (customId === 'confirm_faction_setup') {
      await completeFactionSetup(interaction);
    } else if (customId === 'cancel_faction_setup') {
      await interaction.update({
        content: '❌ Faction setup cancelled.',
        components: []
      });
    } else if (customId === 'setup_bank_suggestion') {
      // Suggest using the bank setup command
      await interaction.update({
        content: 'To set up the bank system, use `/factionsetup bank`',
        components: []
      });
    } else if (customId === 'setup_apikey_suggestion') {
      // Suggest using the apikey command
      await interaction.update({
        content: 'To set your API key, use `/apikey`',
        components: []
      });
    }
  }
};

/**
 * Complete faction setup after confirmation
 * @param {ButtonInteraction} interaction - Button interaction
 */
async function completeFactionSetup(interaction) {
  try {
    // Get message content to extract faction ID and name
    const message = interaction.message;
    const content = message.content;
    
    // Extract faction name from the message
    const factionNameMatch = content.match(/You are not the faction leader or co-leader of ([^.]+)/);
    if (!factionNameMatch) {
      return interaction.update({
        content: '❌ Error processing faction setup. Please try again with the /factionsetup info command.',
        components: []
      });
    }
    
    const factionName = factionNameMatch[1].trim();
    
    // Get user's API key
    const apiKey = await keyStorageService.getApiKey(interaction.user.id, 'torn');
    if (!apiKey) {
      return interaction.update({
        content: '❌ Your API key could not be found. Please set it up again with /apikey before continuing.',
        components: []
      });
    }
    
    // Fetch user data to get faction ID
    const userResponse = await fetch(`https://api.torn.com/user/?selections=basic,profile&key=${apiKey}`);
    const userData = await userResponse.json();
    
    if (userData.error) {
      return interaction.update({
        content: `❌ Error fetching your user data: ${userData.error.error}`,
        components: []
      });
    }
    
    if (!userData.faction || !userData.faction.faction_id) {
      return interaction.update({
        content: '❌ Could not determine your faction ID. Please use /factionsetup info and provide it manually.',
        components: []
      });
    }
    
    const factionId = userData.faction.faction_id.toString();
    
    // Save faction info to database
    const factionData = {
      id: factionId,
      name: factionName,
      server_id: interaction.guildId
    };
    
    const success = await statTrackerService.storeFactionInfo(factionId, factionData);
    
    if (!success) {
      return interaction.update({
        content: '❌ Failed to save faction information. Please try again later.',
        components: []
      });
    }
    
    // Fetch more detailed faction data
    try {
      const response = await fetch(`https://api.torn.com/faction/${factionId}?selections=basic&key=${apiKey}`);
      const data = await response.json();
      
      if (!data.error) {
        // Update with real faction data
        const updatedFactionData = {
          ...factionData,
          name: data.name || factionName,
          tag: data.tag || null,
          leader_id: data.leader || null,
          leader_name: data.leader_name || null,
          co_leader_id: data.co_leader || null,
          co_leader_name: data.co_leader_name || null,
          member_count: data.members ? Object.keys(data.members).length : 0
        };
        
        await statTrackerService.storeFactionInfo(factionId, updatedFactionData);
      }
    } catch (apiError) {
      // Continue anyway, we already have the basic info
      logError('Error fetching faction data from API:', apiError);
    }
    
    // Send success message
    const embed = new EmbedBuilder()
      .setTitle('Faction Information Configured')
      .setColor(BOT_CONFIG.color)
      .addFields(
        { name: 'Faction ID', value: factionId },
        { name: 'Faction Name', value: factionName }
      )
      .setDescription('This server has been configured for your faction. Commands that require faction information will now work properly.')
      .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` });
    
    // Suggest next steps
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('setup_bank_suggestion')
          .setLabel('Set Up Bank System')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('setup_apikey_suggestion')
          .setLabel('Set Your API Key')
          .setStyle(ButtonStyle.Secondary)
      );
    
    await interaction.update({
      content: null,
      embeds: [embed],
      components: [row]
    });
    
  } catch (error) {
    logError('Error completing faction setup:', error);
    await interaction.update({
      content: '❌ An error occurred while setting up faction information. Please try again later.',
      components: []
    });
  }
}

/**
 * Set up the bank system
 * @param {CommandInteraction} interaction - Discord interaction
 */
async function setupBankSystem(interaction) {
  try {
    // Get selected channel and role
    const notificationsChannel = interaction.options.getChannel('notifications');
    const bankerRole = interaction.options.getRole('banker');

    // Save bank configuration
    const success = await setBankConfig(
      interaction.guildId,
      notificationsChannel.id,
      bankerRole.id
    );

    if (!success) {
      return interaction.reply({
        content: '❌ Failed to save bank configuration. Please try again later.',
        ephemeral: true
      });
    }

    // Send success message
    const embed = new EmbedBuilder()
      .setTitle('Faction Bank System Configured')
      .setColor(BOT_CONFIG.color)
      .addFields(
        { name: 'Notifications Channel', value: `<#${notificationsChannel.id}>` },
        { name: 'Banker Role', value: `<@&${bankerRole.id}>` }
      )
      .setDescription('The faction bank system has been set up successfully. Members can now use the `/bank` command to request withdrawals.')
      .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` });

    await interaction.reply({ embeds: [embed] });

  } catch (error) {
    logError('Error setting up bank system:', error);
    await interaction.reply({
      content: '❌ An error occurred while setting up the bank system. Please try again later.',
      ephemeral: true
    });
  }
}

/**
 * Set up faction info
 * @param {CommandInteraction} interaction - Discord interaction
 */
async function setupFactionInfo(interaction) {
  try {
    // Get user's API key first
    const adminMember = interaction.member;
    const apiKey = await keyStorageService.getApiKey(adminMember.id, 'torn');
    
    if (!apiKey) {
      return interaction.reply({
        content: '❌ You need to set your API key first with `/apikey` to use this command.',
        ephemeral: true
      });
    }
    
    // Check if auto-detect is enabled or no faction ID provided
    let factionId = interaction.options.getString('faction_id');
    let factionName = interaction.options.getString('faction_name');
    const autoDetect = interaction.options.getBoolean('autodetect') || (!factionId && !factionName);
    
    if (autoDetect) {
      // Defer reply while we fetch data
      await interaction.deferReply();
      
      try {
        // Fetch user data to get faction information
        const userResponse = await fetch(`https://api.torn.com/user/?selections=basic,profile&key=${apiKey}`);
        const userData = await userResponse.json();
        
        if (userData.error) {
          return interaction.editReply(`❌ Error fetching your user data: ${userData.error.error}`);
        }
        
        if (!userData.faction || !userData.faction.faction_id) {
          return interaction.editReply('❌ You do not appear to be in a faction. Please provide faction information manually.');
        }
        
        // Set faction details from user data
        factionId = userData.faction.faction_id.toString();
        factionName = userData.faction.faction_name;
        
        // Fetch more detailed faction data
        const factionResponse = await fetch(`https://api.torn.com/faction/${factionId}?selections=basic&key=${apiKey}`);
        const factionData = await factionResponse.json();
        
        if (!factionData.error) {
          // Check if user is a faction leader or co-leader
          if (userData.player_id != factionData.leader && userData.player_id != factionData.co_leader) {
            await interaction.editReply({
              content: `⚠️ **Note:** You are not the faction leader or co-leader of ${factionName}. Are you sure you want to configure this server for this faction?`,
              components: [
                new ActionRowBuilder().addComponents(
                  new ButtonBuilder()
                    .setCustomId('confirm_faction_setup')
                    .setLabel('Yes, Continue Setup')
                    .setStyle(ButtonStyle.Primary),
                  new ButtonBuilder()
                    .setCustomId('cancel_faction_setup')
                    .setLabel('Cancel Setup')
                    .setStyle(ButtonStyle.Secondary)
                )
              ]
            });
            
            // Wait for button response (handled in handleButton function)
            return;
          }
        }
      } catch (error) {
        logError('Error auto-detecting faction:', error);
        return interaction.editReply('❌ Error auto-detecting your faction. Please try again or provide faction information manually.');
      }
    }
    
    // If we got here without faction ID or name, something went wrong with auto-detection
    if (!factionId || !factionName) {
      return interaction.reply({
        content: '❌ Please provide both faction ID and name, or enable auto-detection.',
        ephemeral: true
      });
    }
    
    // Validate faction ID format (numeric)
    if (!/^\d+$/.test(factionId)) {
      return interaction.reply({
        content: '❌ Faction ID must be a numeric value.',
        ephemeral: true
      });
    }
    
    // If we used deferReply for auto-detection, we need to use editReply, otherwise use reply
    const replyMethod = interaction.deferred ? 'editReply' : 'reply';

    // Save faction info to database
    const factionData = {
      id: factionId,
      name: factionName,
      server_id: interaction.guildId
    };

    const success = await statTrackerService.storeFactionInfo(factionId, factionData);

    if (!success) {
      return interaction[replyMethod]({
        content: '❌ Failed to save faction information. Please try again later.'
      });
    }

    // Fetch more detailed faction data from API
    try {
      // Fetch faction info from Torn API
      const response = await fetch(`https://api.torn.com/faction/${factionId}?selections=basic&key=${apiKey}`);
      const data = await response.json();

      if (!data.error) {
        // Update with real faction data
        const updatedFactionData = {
          ...factionData,
          name: data.name || factionName,
          tag: data.tag || null,
          leader_id: data.leader || null,
          leader_name: data.leader_name || null,
          co_leader_id: data.co_leader || null,
          co_leader_name: data.co_leader_name || null,
          member_count: data.members ? Object.keys(data.members).length : 0
        };

        await statTrackerService.storeFactionInfo(factionId, updatedFactionData);
      }
    } catch (apiError) {
      // Continue anyway, we already have the basic info
      logError('Error fetching faction data from API:', apiError);
    }

    // Send success message
    const embed = new EmbedBuilder()
      .setTitle('Faction Information Configured')
      .setColor(BOT_CONFIG.color)
      .addFields(
        { name: 'Faction ID', value: factionId },
        { name: 'Faction Name', value: factionName }
      )
      .setDescription('This server has been configured for your faction. Commands that require faction information will now work properly.')
      .setFooter({ text: `${BOT_CONFIG.name} v${BOT_CONFIG.version}` });

    // Suggest next steps
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('setup_bank_suggestion')
          .setLabel('Set Up Bank System')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('setup_apikey_suggestion')
          .setLabel('Set Your API Key')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction[replyMethod]({
      embeds: [embed],
      components: [row]
    });
  } catch (error) {
    logError('Error setting up faction info:', error);
    const replyMethod = interaction.deferred ? 'editReply' : 'reply';
    await interaction[replyMethod]({
      content: '❌ An error occurred while setting up faction information. Please try again later.'
    });
  }
}

module.exports = factionSetupCommand;